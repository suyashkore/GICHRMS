<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>
<div class="modal-header">
   <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
   <h4 class="modal-title">
      <?php if(isset($lead)){
         if(!empty($lead->name)){
           $name = $lead->name;
         } else if(!empty($lead->company)){
           $name = $lead->company;
         } else {
           $name = _l('lead');
         }
         echo '#'.$lead->id . ' - ' .  $name;
         } else {
         echo _l('add_new',_l('lead_lowercase'));
         }
         ?>
   </h4>
</div>
<div class="modal-body">
   <?php
      if(isset($lead)){
           if($lead->lost == 1){
              echo '<div class="ribbon danger"><span>'._l('lead_lost').'</span></div>';
           } else if($lead->junk == 1){
              echo '<div class="ribbon warning"><span>'._l('lead_junk').'</span></div>';
           } else {
              if (total_rows(db_prefix().'clients', array(
                'leadid' => $lead->id))) {
                echo '<div class="ribbon success"><span>'._l('lead_is_client').'</span></div>';
             }
          }
      }
      ?>
   <div class="row">
      <div class="col-md-12">
         <?php if(isset($lead)){
            echo form_hidden('leadid',$lead->id);
            } ?>
         <div class="top-lead-menu">
            <div class="horizontal-scrollable-tabs preview-tabs-top">
               <div class="scroller arrow-left"><i class="fa fa-angle-left"></i></div>
               <div class="scroller arrow-right"><i class="fa fa-angle-right"></i></div>
               <div class="horizontal-tabs">
                  <ul class="nav-tabs-horizontal nav nav-tabs<?php if(!isset($lead)){echo ' lead-new';} ?>" role="tablist">
                     <li role="presentation" class="active" >
                        <a href="#tab_lead_profile" aria-controls="tab_lead_profile" role="tab" data-toggle="tab">
                        <?php echo _l('lead_profile'); ?>
                        </a>
                     </li>
                     <?php if(isset($lead)){ ?>
                     <?php if(count($mail_activity) > 0 || isset($show_email_activity) && $show_email_activity){ ?>
                     <li role="presentation">
                        <a href="#tab_email_activity" aria-controls="tab_email_activity" role="tab" data-toggle="tab">
                        <?php echo hooks()->apply_filters('lead_email_activity_subject', _l('lead_email_activity')); ?>
                        </a>
                     </li>
                     <?php } ?>
                    <!-- <li role="presentation">
              <a href="#tab_lead_profile1" aria-controls="tab_lead_profile1" role="tab" data-toggle="tab">
                Send Email
              </a>
           </li>-->
           <li role="presentation">
              <a href="#tab_lead_profile111" aria-controls="tab_lead_profile111" role="tab" data-toggle="tab">Send GIC Profile
              </a>
           </li>
                     <li role="presentation">
                        <a href="#tab_proposals_leads" onclick="initDataTable('.table-proposals-lead', admin_url + 'proposals/proposal_relations/' + <?php echo $lead->id; ?> + '/lead','undefined', 'undefined','undefined',[6,'desc']);" aria-controls="tab_proposals_leads" role="tab" data-toggle="tab">
                        <?php echo _l('proposals'); 
                        if($total_proposals > 0){
                           echo ' <span class="badge">'.$total_proposals.'</span>';
                        }
                        ?>
                        </a>
                     </li>
                     <li role="presentation">
                        <a href="#tab_tasks_leads" onclick="init_rel_tasks_table(<?php echo $lead->id; ?>,'lead','.table-rel-tasks-leads');" aria-controls="tab_tasks_leads" role="tab" data-toggle="tab">
                        <?php echo _l('tasks');
                        if($total_tasks > 0){
                           echo ' <span class="badge">'.$total_tasks.'</span>';
                        }
                        ?>
                        </a>
                     </li>
                     <li role="presentation">
                        <a href="#attachments" aria-controls="attachments" role="tab" data-toggle="tab">
                        <?php echo _l('lead_attachments'); 
                        if($total_attachments > 0){
                           echo ' <span class="badge">'.$total_attachments.'</span>';
                        }
                        ?>
                        </a>
                     </li>
                     <li role="presentation">
                        <a href="#lead_reminders" onclick="initDataTable('.table-reminders-leads', admin_url + 'misc/get_reminders/' + <?php echo $lead->id; ?> + '/' + 'lead', undefined, undefined,undefined,[1, 'asc']);" aria-controls="lead_reminders" role="tab" data-toggle="tab">
                        <?php echo _l('leads_reminders_tab');
                           if($total_reminders > 0){
                              echo ' <span class="badge">'.$total_reminders.'</span>';
                           }
                           ?>
                        </a>
                     </li>
                     <li role="presentation">
                        <a href="#lead_notes" aria-controls="lead_notes" role="tab" data-toggle="tab">
                        <?php echo _l('lead_add_edit_notes'); 
                        if($total_notes > 0){
                           echo ' <span class="badge">'.$total_notes.'</span>';
                        }
                        ?>
                        </a>
                     </li>
                     <li role="presentation">
                        <a href="#lead_activity" aria-controls="lead_activity" role="tab" data-toggle="tab">
                        <?php echo _l('lead_add_edit_activity'); ?>
                        </a>
                     </li>
                     <?php if(is_gdpr() && (get_option('gdpr_enable_lead_public_form') == '1' || get_option('gdpr_enable_consent_for_leads') == '1')) { ?>
                     <li role="presentation">
                        <a href="#gdpr" aria-controls="gdpr" role="tab" data-toggle="tab">
                        <?php echo _l('gdpr_short'); ?>
                        </a>
                     </li>
                     <?php } ?>
                     <?php } ?>
                     <?php hooks()->do_action('after_lead_lead_tabs', $lead ?? null); ?>
                  </ul>
               </div>
            </div>
         </div>
         <!-- Tab panes -->
         <div class="tab-content mtop20">
            <!-- from leads modal -->
            <div role="tabpanel" class="tab-pane active" id="tab_lead_profile">
               <?php $this->load->view('admin/leads/profile'); ?>
            </div>
            <!-- custom code start -->
            
            <div role="tabpanel" class="tab-pane" id="tab_lead_profile1">
            <div class="row">
      <div class="col-md-12 col-lg-12">
      <?php echo form_open_multipart('admin/emails/send_mail_for_lead'); ?>
        <?php //print_r($project);
        
$login_email = get_staff_full_name1();
//echo $login_email;
$pos1 = strpos($login_email,"(");
$email = substr($login_email,$pos1+1,-1);
//echo $email;
?>
                  <div class="col-xs-6 col-sm-6 col-md-6">
                    <label>Email From</label>
                    <div class="form-group">
                      <input type="text" name="email_from" id="email_from" class="form-control input-sm" value="<?php echo $email; ?>" readonly>
                    </div>
                  </div>
                  
                  <div class="col-xs-6 col-sm-6 col-md-6">
                    <label>Email To</label>
                    
                    <div class="form-group">
                      <input type="text" name="email_to" id="email_to" class="form-control input-sm" value="<?php echo $lead->email; ?>">
                    </div>
                  
                  </div>
                  <div class="col-xs-6 col-sm-6 col-md-6">
                    <label>Subject</label>
                    <div class="form-group">
                      <input type="text" name="Subject" id="Subject" class="form-control input-sm" placeholder="Subject" value="<?php echo $lead->name; ?>">
                    </div>
                  </div>
                  <div class="col-xs-6 col-sm-6 col-md-6">
                    <label>Cc</label>
                    <div class="form-group">
                      <textarea name="cc" id="cc" class="form-control input-sm" placeholder="Cc"><?php foreach($secondery_user as $key => $value) { echo $value.',';} ?></textarea>
                      <!-- <span>CC To: <?php foreach($secondery_user as $key => $value) { echo $value.', ';} ?></span> -->
                      <input type="hidden" name="hiddencc" id="hiddencc" value="<?php foreach($secondery_user as $key => $value) { echo $value.',';} ?>">
                    </div>
                  </div>
                  <div class="col-xs-6 col-sm-6 col-md-6">
                    <label>Bcc</label>
                    <div class="form-group">
                      <input type="text" name="bcc" id="bcc" class="form-control input-sm" value="gic.crm1@gmail.com" readonly="">
                    </div>
                  </div>
                  
                  
                  
                  <div class="col-xs-12 col-sm-12 col-md-12">
                    <label>Message Body</label>
                    
                    <div class="form-group">
                      <!-- <textarea rows="6" cols="150" class="form-control" id="Message" class="Message" placeholder="Message..">
                    </textarea> -->
                    
                    <?php echo render_textarea('message','','',array(),array(),'','tinymce'); ?>
                    
                    </div>
                  </div>
 
                    
        
                  <div class="panel-footer attachments_area">
            <div class="row attachments">
               <div class="attachment">
                  <div class="col-md-6 col-md-offset-3"> 
                     <div class="form-group">
                        <label for="attachment" class="control-label"><?php echo _l('clients_ticket_attachments'); ?></label>
                        <div class="input-group">
                           <input type="file" extension="<?php echo str_replace('.','',get_option('ticket_attachments_file_extensions')); ?>" filesize="<?php echo file_upload_max_size(); ?>" class="form-control" name="attachments[0]" accept="<?php echo get_ticket_form_accepted_mimes(); ?>">
                           <span class="input-group-btn">
                           <button class="btn btn-success add_more_attachments p8-half" data-ticket="true" type="button"><i class="fa fa-plus"></i></button>
                           </span>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
                  <!--<input type="text" name="hidden_feild" value="<?php echo $lead->id; ?>">-->
                  <input type="hidden" name="Comment_mail" id="Comment_mail" class="form-control input-sm">
                  <button class="btn btn-warning send" type="submit" id="send">Send</button>
                <?php echo form_close(); ?>
        
      </div>
      
    </div>
      </div>
            
            
         <div role="tabpanel" class="tab-pane" id="tab_lead_profile111">
            
      
      <?php echo form_open('admin/emails/company_profile_mail',array('id'=>'lead_form')); ?>
        <?php //print_r($project);
        

$login_email = get_staff_full_name1();
//echo $login_email;
$pos1 = strpos($login_email,"(");
$email = substr($login_email,$pos1+1,-1);
//echo $email;
?>
                  <div class="col-xs-6 col-sm-6 col-md-6">
                    <label>Email From</label>
                    <div class="form-group">
                      <input type="text" name="email_from" id="email_from" class="form-control input-sm" value="<?php echo $email; ?>" readonly>
                    </div>
                  </div>
                  <input type="hidden" name="lead_id" value="<?php echo $lead->id; ?>">
                  <div class="col-xs-6 col-sm-6 col-md-6">
                    <label>Email To</label>
                    
                    <div class="form-group">
                      <input type="text" name="email_to" id="email_to" class="form-control input-sm" value="<?php echo $lead->email; ?>">
                    </div>
                  
                  </div>

                  <div class="clearfix"></div>

                  <div class="col-xs-6 col-sm-6 col-md-6">
                    <label>Subject</label>
                    <div class="form-group">
                      <input type="text" name="Subject" id="Subject" class="form-control input-sm" placeholder="Subject" value="Company Profile">
                    </div>
                  </div>

                  <div class="col-xs-6 col-sm-6 col-md-6">
                    <label>Cc</label>
                    <div class="form-group">
                      <input type="text" name="cc" id="cc" value="<?php echo $email; ?>" readonly class="form-control input-sm" placeholder="Cc">
                      
                    </div>
                  </div>
                   <div class="clearfix"></div>
                  <div class="col-xs-6 col-sm-6 col-md-6">
                    <label>Bcc</label>
                    <div class="form-group">
                      <input type="text" name="bcc" id="bcc" class="form-control input-sm" value="sales.globalinfocloud@gmail.com" readonly="">
                    </div>
                  </div>
                  
                  <div class="col-xs-6 col-sm-6 col-md-6">
                      <label>&nbsp;</label>
                      <div class="form-group">
                          <button class="btn btn-warning send" type="submit" id="send">Send Email</button>
                      </div>
                  </div>
                  
                  <div class="clearfix"></div>
                  
                  <div class="col-xs-12 col-sm-12 col-md-12">
                    <label><strong>Message Body</strong></label>
                    <br>
                    <div class="form-group">
                     <?php
                     $body1 = '<p>Dear '.$name.',</p>
<p>Greetings of the day!</p>
<p class="whowe" style="text-align: justify;">Global Infocloud Pvt Ltd is seasoned and talented team of IT, Marketing &amp; Design, who works on the principle of Discover, Learn &amp; Evolve. We discover the new horizons for each of our client so that they can become a great leader and shift to the best from better. We offer comprehensive, cost-effective and efficient Digital Business Automation, Marketing &amp; Design Solutions. We believe in working closely with our clients and we&rsquo;re willing to adapt &nbsp;services to respond to the shifting priorities of each engagement.</p>
<p style="text-align: justify;" class="whowe">We understand that each and every business has its own individual outlook and culture, thus we help out client in conceptualize, design, maintain &amp; develop all their business needs. Our services help you to simplify your business complexity and maximize the value. We build a trusted advisor relationship, based on experiences and best practices.</p>
<p style="text-align: justify;">We are an integrated company performing as a workhorse for the complete business ecosystem. We join hands with startups, SME'.'s and fortune companies to benefit them with our elite solutions. As a Group,&nbsp;we are serving our clients throughout the Globe with a combined team of 250+ members. Our Corporate office is based out of Gurugram with provincial offices in Pune and Toronto. We are attaching Our IT profile for your easy understanding. Enclosed is the company profile, listing all of our different services in details.</p>


<p style="text-align: justify;">We would love to meet you in person to take the discussion further, kindly let us know your availability so that we can align our meeting.</p>


<p style="text-align: justify;"><b>For more information about the company, kindly click on the web link: </b><b>&nbsp;<a href="https://www.globalinfocloud.com/" target="_blank">http://www.globalinfocloud.com/</a>&nbsp;</b></p>

<p style="text-align: justify;"><b>Please have a look to our </b><a href="https://shorturl.at/ctKZ9" target="_blank"><b>Company Profile Here</b></a></p>

<p>Anticipating for great business together!</p>

<p>Thanks!</p>
<p>Best,</p>';
if($email=="vaibhav@globalinfocloud.com") {
    $body1.= '<img src="https://support.globalinfocloud.com/uploads/e_sign/new_vaibhav_sir.jpg" style="width: auto; height: 240px;">';
}  
if($email=="chetan.chaudhari@globalinfocloud.com"){
$body1.= '<img src="https://support.globalinfocloud.com/uploads/chetan.png" style="width: auto; height: 240px;">';
}
if($email=="alhad.walhekar@globalinfocloud.com"){
$body1.= '<img src="https://support.globalinfocloud.com/uploads/alhad.png" style="width: auto; height: 240px;">';
}
if($email=="shradha.salunke@globalinfocloud.com"){
$body1.= '<img src="https://support.globalinfocloud.com/uploads/shradha.png" style="width: auto; height: 240px;">';
}
/*if($email=="ajinkya.bhalerao@globalinfocloud.com"){
$body1.= '<img src="https://support.globalinfocloud.com/uploads/e_sign/new_vaibhav_sir.jpg" style="width: auto; height: 240px;">';
}*/
if($email=="abhishek.yadav@globalinfocloud.com"){
$body1.= '<img src="https://support.globalinfocloud.com/uploads/e_sign/gkp_abhishek.jpg" style="width: auto; height: 240px;">';
}
if($email=="amarnath.paswan@globalinfocloud.com"){
$body1.= '<img src="https://support.globalinfocloud.com/uploads/e_sign/gkp_amar.jpg" style="width: auto; height: 240px;">';
}
if($email=="ankesh.gupta@globalinfocloud.com"){
$body1.= '<img src="https://support.globalinfocloud.com/uploads/e_sign/gkp_ankesh.jpg" style="width: auto; height: 240px;">';
}
$body1 .='<p>&nbsp;</p>
<p>&nbsp;</p>
<p text-align="justify" style="color: #018697; text-align: justify;"><strong> CONFIDENTIALITY NOTICE:</strong> The contents of this email message and any attachments are intended solely for the addressee(s) and may contain confidential and/or privileged information and may be legally protected from disclosure. If you are not the intended recipient of this message or their agent, or if this message has been addressed to you in error, please immediately alert the sender by reply email and then delete this message and any attachments. If you are not the intended recipient, you are hereby notified that any use, dissemination, copying, or storage of this message or its attachments is strictly prohibited.</p>';
                     ?>
                    <?php //echo render_textarea('message','',$body1,array(),array(),'','tinymce'); ?>
                    <textarea name="message" style="display:none;"><?php echo $body1; ?></textarea>
                    <?php echo $body1; ?>
                   <!-- <textarea name="message"></textarea>-->
                    
                    </div>
                  </div>
 
                    <div class="clearfix"></div>
        
          
                  <input type="hidden" name="mobno" id="mobno" value="<?php echo $lead->phonenumber; ?>" class="form-control input-sm">
                  
                <?php echo form_close(); ?>
        
      </div>    
            <!-- custom code end -->
            <?php if(isset($lead)){ ?>
            <?php if(count($mail_activity) > 0 || isset($show_email_activity) && $show_email_activity){ ?>
            <div role="tabpanel" class="tab-pane" id="tab_email_activity">
               <?php hooks()->do_action('before_lead_email_activity', array('lead'=>$lead, 'email_activity'=>$mail_activity)); ?>
               <?php foreach($mail_activity as $_mail_activity){ ?>
               <div class="lead-email-activity">
                  <div class="media-left">
                     <i class="fa fa-envelope"></i>
                  </div>
                  <div class="media-body">
                     <h4 class="bold no-margin lead-mail-activity-subject">
                        <?php echo $_mail_activity['subject']; ?>
                        <br />
                        <small class="text-muted display-block mtop5 font-medium-xs"><?php echo _dt($_mail_activity['dateadded']); ?></small>
                     </h4>
                     <div class="lead-mail-activity-body">
                        <hr />
                        <?php echo $_mail_activity['body']; ?>
                     </div>
                     <hr />
                  </div>
               </div>
               <div class="clearfix"></div>
               <?php } ?>
               <?php hooks()->do_action('after_lead_email_activity', array('lead_id'=>$lead->id, 'emails'=>$mail_activity)); ?>
            </div>
            <?php } ?>
            <?php if(is_gdpr() && (get_option('gdpr_enable_lead_public_form') == '1' || get_option('gdpr_enable_consent_for_leads') == '1' || (get_option('gdpr_data_portability_leads') == '1') && is_admin())) { ?>
            <div role="tabpanel" class="tab-pane" id="gdpr">
               <?php if(get_option('gdpr_enable_lead_public_form') == '1') { ?>
               <a href="<?php echo $lead->public_url; ?>" target="_blank" class="mtop5">
               <?php echo _l('view_public_form'); ?>
               </a>
               <?php } ?>
               <?php if(get_option('gdpr_data_portability_leads') == '1' && is_admin()){ ?>
               <?php
                  if(get_option('gdpr_enable_lead_public_form') == '1') {
                     echo ' | ';
                  }
                  ?>
               <a href="<?php echo admin_url('leads/export/'.$lead->id); ?>">
               <?php echo _l('dt_button_export'); ?>
               </a>
               <?php } ?>
               <?php if(get_option('gdpr_enable_lead_public_form') == '1' || (get_option('gdpr_data_portability_leads') == '1' && is_admin())) { ?>
               <hr class="hr-margin-n-15" />
               <?php } ?>
               <?php if(get_option('gdpr_enable_consent_for_leads') == '1') { ?>
               <h4 class="no-mbot">
                  <?php echo _l('gdpr_consent'); ?>
               </h4>
               <?php $this->load->view('admin/gdpr/lead_consent'); ?>
               <hr />
               <?php } ?>
            </div>
            <?php } ?>
            <div role="tabpanel" class="tab-pane" id="lead_activity">
               <div class="panel_s no-shadow">
                  <div class="activity-feed">
                     <?php foreach($activity_log as $log){ ?>
                     <div class="feed-item">
                        <div class="date">
                           <span class="text-has-action" data-toggle="tooltip" data-title="<?php echo _dt($log['date']); ?>">
                           <?php echo time_ago($log['date']); ?>
                           </span>
                        </div>
                        <div class="text">
                           <?php if($log['staffid'] != 0){ ?>
                           <a href="<?php echo admin_url('profile/'.$log["staffid"]); ?>">
                           <?php echo staff_profile_image($log['staffid'],array('staff-profile-xs-image pull-left mright5'));
                              ?>
                           </a>
                           <?php
                              }
                              $additional_data = '';
                              if(!empty($log['additional_data'])){
                               $additional_data = unserialize($log['additional_data']);
                               echo ($log['staffid'] == 0) ? _l($log['description'],$additional_data) : $log['full_name'] .' - '._l($log['description'],$additional_data);
                              } else {
                                  echo $log['full_name'] . ' - ';
                                 if($log['custom_activity'] == 0){
                                    echo _l($log['description']);
                                 } else {
                                    echo _l($log['description'],'',false);
                                 }
                              }
                              ?>
                        </div>
                     </div>
                     <?php } ?>
                  </div>
                  <div class="col-md-12">
                     <?php echo render_textarea('lead_activity_textarea','','',array('placeholder'=>_l('enter_activity')),array(),'mtop15'); ?>
                     <div class="text-right">
                        <button id="lead_enter_activity" class="btn btn-info"><?php echo _l('submit'); ?></button>
                     </div>
                  </div>
                  <div class="clearfix"></div>
               </div>
            </div>
            <div role="tabpanel" class="tab-pane" id="tab_proposals_leads">
               <?php if(has_permission('proposals','','create')){ ?>
               <a href="<?php echo admin_url('proposals/proposal?rel_type=lead&rel_id='.$lead->id); ?>" class="btn btn-info mbot25"><?php echo _l('new_proposal'); ?></a>
               <?php } ?>
               <?php if(total_rows(db_prefix().'proposals',array('rel_type'=>'lead','rel_id'=>$lead->id))> 0 && (has_permission('proposals','','create') || has_permission('proposals','','edit'))){ ?>
               <a href="#" class="btn btn-info mbot25" data-toggle="modal" data-target="#sync_data_proposal_data"><?php echo _l('sync_data'); ?></a>
               <?php $this->load->view('admin/proposals/sync_data',array('related'=>$lead,'rel_id'=>$lead->id,'rel_type'=>'lead')); ?>
               <?php } ?>
               <?php
                  $table_data = array(
                   _l('proposal') . ' #',
                   _l('proposal_subject'),
                   _l('proposal_total'),
                   _l('proposal_date'),
                   _l('proposal_open_till'),
                   _l('tags'),
                   _l('proposal_date_created'),
                   _l('proposal_status'));
                  $custom_fields = get_custom_fields('proposal',array('show_on_table'=>1));
                  foreach($custom_fields as $field){
                   array_push($table_data,$field['name']);
                  }
                  $table_data = hooks()->apply_filters('proposals_relation_table_columns', $table_data);
                  render_datatable($table_data,'proposals-lead',[], [
                      'data-last-order-identifier' => 'proposals-relation',
                      'data-default-order'         => get_table_last_order('proposals-relation'),
                  ]);
                  ?>
            </div>
            <div role="tabpanel" class="tab-pane" id="tab_tasks_leads">
               <?php init_relation_tasks_table(array('data-new-rel-id'=>$lead->id,'data-new-rel-type'=>'lead')); ?>
            </div>
            <div role="tabpanel" class="tab-pane" id="lead_reminders">
               <a href="#" data-toggle="modal" class="btn btn-info" data-target=".reminder-modal-lead-<?php echo $lead->id; ?>"><i class="fa fa-bell-o"></i> <?php echo _l('lead_set_reminder_title'); ?></a>
               <hr />
               <?php render_datatable(array( _l( 'reminder_description'), _l( 'reminder_date'), _l( 'reminder_staff'), _l( 'reminder_is_notified')), 'reminders-leads'); ?>
            </div>
            <div role="tabpanel" class="tab-pane" id="attachments">
               <?php echo form_open('admin/leads/add_lead_attachment',array('class'=>'dropzone mtop15 mbot15','id'=>'lead-attachment-upload')); ?>
               <?php echo form_close(); ?>
               <?php if(get_option('dropbox_app_key') != ''){ ?>
               <hr />
               <div class=" pull-left">
                  <?php if (count($lead->attachments) > 0) { ?>
                  <a href="<?php echo admin_url('leads/download_files/'.$lead->id); ?>" class="bold">
                  <?php echo _l('download_all'); ?> (.zip)
                  </a>
                  <?php } ?>
               </div>
               <div class="pull-right">
                  <button class="gpicker">
                  <i class="fa fa-google" aria-hidden="true"></i>
                  <?php echo _l('choose_from_google_drive'); ?>
                  </button>
                  <div id="dropbox-chooser-lead"></div>
               </div>
               <div class=" clearfix"></div>
               <?php } ?>
               <?php if(count($lead->attachments) > 0) { ?>
               <div class="mtop20" id="lead_attachments">
                  <?php $this->load->view('admin/leads/leads_attachments_template', array('attachments'=>$lead->attachments)); ?>
               </div>
               <?php } ?>
            </div>
            <div role="tabpanel" class="tab-pane" id="lead_notes">
               <?php echo form_open(admin_url('leads/add_note/'.$lead->id),array('id'=>'lead-notes')); ?>
               <div class="form-group">
                  <textarea id="lead_note_description" name="lead_note_description" class="form-control" rows="4"></textarea>
               </div>
               <div class="lead-select-date-contacted hide">
                  <?php echo render_datetime_input('custom_contact_date','lead_add_edit_datecontacted','',array('data-date-end-date'=>date('Y-m-d'))); ?>
               </div>
               <div class="radio radio-primary">
                  <input type="radio" name="contacted_indicator" id="contacted_indicator_yes" value="yes">
                  <label for="contacted_indicator_yes"><?php echo _l('lead_add_edit_contacted_this_lead'); ?></label>
               </div>
               <div class="radio radio-primary">
                  <input type="radio" name="contacted_indicator" id="contacted_indicator_no" value="no" checked>
                  <label for="contacted_indicator_no"><?php echo _l('lead_not_contacted'); ?></label>
               </div>
               <button type="submit" class="btn btn-info pull-right"><?php echo _l('lead_add_edit_add_note'); ?></button>
               <?php echo form_close(); ?>
               <div class="clearfix"></div>
               <hr />
               <div class="panel_s no-shadow">
                  <?php
                     $len = count($notes);
                     $i = 0;
                     foreach($notes as $note){ ?>
                  <div class="media lead-note">
                     <a href="<?php echo admin_url('profile/'.$note["addedfrom"]); ?>" target="_blank">
                     <?php echo staff_profile_image($note['addedfrom'],array('staff-profile-image-small','pull-left mright10')); ?>
                     </a>
                     <div class="media-body">
                        <?php if($note['addedfrom'] == get_staff_user_id() || is_admin()){ ?>
                        <a href="#" class="pull-right text-danger" onclick="delete_lead_note(this,<?php echo $note['id']; ?>, <?php echo $lead->id; ?>);return false;"><i class="fa fa fa-times"></i></a>
                        <a href="#" class="pull-right mright5" onclick="toggle_edit_note(<?php echo $note['id']; ?>);return false;"><i class="fa fa-pencil-square-o"></i></a>
                        <?php } ?>
                        <?php if(!empty($note['date_contacted'])){ ?>
                        <span data-toggle="tooltip" data-title="<?php echo _dt($note['date_contacted']); ?>">
                        <i class="fa fa-phone-square text-success font-medium valign" aria-hidden="true"></i>
                        </span>
                        <?php } ?>
                        <small><?php echo _l('lead_note_date_added',_dt($note['dateadded'])); ?></small>
                        <a href="<?php echo admin_url('profile/'.$note["addedfrom"]); ?>" target="_blank">
                           <h5 class="media-heading bold"><?php echo get_staff_full_name($note['addedfrom']); ?></h5>
                        </a>
                        <div data-note-description="<?php echo $note['id']; ?>" class="text-muted">
                           <?php echo check_for_links(app_happy_text($note['description'])); ?>
                        </div>
                        <div data-note-edit-textarea="<?php echo $note['id']; ?>" class="hide mtop15">
                           <?php echo render_textarea('note','',$note['description']); ?>
                           <div class="text-right">
                              <button type="button" class="btn btn-default" onclick="toggle_edit_note(<?php echo $note['id']; ?>);return false;"><?php echo _l('cancel'); ?></button>
                              <button type="button" class="btn btn-info" onclick="edit_note(<?php echo $note['id']; ?>);"><?php echo _l('update_note'); ?></button>
                           </div>
                        </div>
                     </div>
                     <?php if ($i >= 0 && $i != $len - 1) {
                        echo '<hr />';
                        }
                        ?>
                  </div>
                  <?php $i++; } ?>
               </div>
            </div>
            <?php } ?>
            <?php hooks()->do_action('after_lead_tabs_content', $lead ?? null); ?>
         </div>
      </div>
   </div>
</div>
<?php hooks()->do_action('lead_modal_profile_bottom',(isset($lead) ? $lead->id : '')); ?>
