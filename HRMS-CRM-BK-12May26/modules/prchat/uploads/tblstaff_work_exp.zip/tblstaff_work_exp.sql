-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Aug 31, 2023 at 01:17 PM
-- Server version: 5.7.43
-- PHP Version: 8.1.16

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `t5e3s4tgi_gic_crm_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `tblstaff_work_exp`
--

CREATE TABLE `tblstaff_work_exp` (
  `id` int(11) NOT NULL,
  `staffid` int(11) NOT NULL,
  `organization_name` varchar(255) NOT NULL,
  `date_of_joining` datetime NOT NULL,
  `last_working_day` datetime NOT NULL,
  `comp_add1` varchar(150) NOT NULL,
  `comp_add2` varchar(150) DEFAULT NULL,
  `comp_add3` varchar(150) DEFAULT NULL,
  `report_manager_name` varchar(200) NOT NULL,
  `report_manager_number` varchar(15) NOT NULL,
  `report_manager_email` varchar(100) NOT NULL,
  `relieving_letter` varchar(200) NOT NULL,
  `exp_certificate` varchar(200) NOT NULL,
  `offer_letter` varchar(200) NOT NULL,
  `payslip1` varchar(200) DEFAULT NULL,
  `payslip2` varchar(200) DEFAULT NULL,
  `payslip3` varchar(200) DEFAULT NULL,
  `user_id` int(11) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_by` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tblstaff_work_exp`
--
ALTER TABLE `tblstaff_work_exp`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tblstaff_work_exp`
--
ALTER TABLE `tblstaff_work_exp`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
