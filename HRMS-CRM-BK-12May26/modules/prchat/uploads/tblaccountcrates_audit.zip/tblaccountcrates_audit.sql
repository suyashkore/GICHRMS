-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Aug 29, 2023 at 04:57 PM
-- Server version: 5.7.43
-- PHP Version: 8.1.16

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `t5e3s4tgi_demo_erp`
--

-- --------------------------------------------------------

--
-- Table structure for table `tblaccountcrates_audit`
--

CREATE TABLE `tblaccountcrates_audit` (
  `id` int(11) NOT NULL,
  `PlantID` int(11) NOT NULL,
  `FY` varchar(2) NOT NULL,
  `VoucherID` varchar(11) NOT NULL,
  `Transdate` datetime(6) NOT NULL,
  `TransDate2` datetime(6) DEFAULT NULL,
  `ChallanID` varchar(11) DEFAULT NULL,
  `AccountID` varchar(50) NOT NULL,
  `TType` varchar(1) NOT NULL,
  `Qty` bigint(20) NOT NULL,
  `PassedFrom` varchar(50) NOT NULL,
  `Narration` varchar(254) DEFAULT NULL,
  `Ordinalno` int(11) DEFAULT NULL,
  `UserID` varchar(50) NOT NULL,
  `UserID2` varchar(50) DEFAULT NULL,
  `Lupdate` varchar(50) DEFAULT NULL,
  `created_by` varchar(10) DEFAULT NULL,
  `created_at` datetime(6) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tblaccountcrates_audit`
--
ALTER TABLE `tblaccountcrates_audit`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tblaccountcrates_audit`
--
ALTER TABLE `tblaccountcrates_audit`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
