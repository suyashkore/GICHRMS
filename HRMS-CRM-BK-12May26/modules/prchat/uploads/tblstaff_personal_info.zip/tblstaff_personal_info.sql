-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Aug 31, 2023 at 04:04 PM
-- Server version: 5.7.43
-- PHP Version: 8.1.16

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `t5e3s4tgi_gic_crm_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `tblstaff_personal_info`
--

CREATE TABLE `tblstaff_personal_info` (
  `id` int(11) NOT NULL,
  `staffid` int(11) NOT NULL,
  `address1` varchar(150) DEFAULT NULL,
  `address2` varchar(150) DEFAULT NULL,
  `address3` varchar(150) DEFAULT NULL,
  `state` varchar(10) NOT NULL,
  `city` varchar(10) NOT NULL,
  `pincode` int(10) DEFAULT NULL,
  `e_contact_name1` varchar(200) DEFAULT NULL,
  `e_contact1_relation` varchar(150) DEFAULT NULL,
  `e_contact1_number` varchar(15) DEFAULT NULL,
  `e_contact_name2` varchar(200) DEFAULT NULL,
  `e_contact2_relation` varchar(150) DEFAULT NULL,
  `e_contact2_number` varchar(15) DEFAULT NULL,
  `ifsc_code` varchar(15) DEFAULT NULL,
  `bank_name` varchar(250) DEFAULT NULL,
  `bank_acc_number` varchar(20) DEFAULT NULL,
  `bank_acc_name` varchar(150) DEFAULT NULL,
  `aadhaar_card` varchar(250) DEFAULT NULL,
  `pan_card` varchar(250) DEFAULT NULL,
  `driving_licence` varchar(250) DEFAULT NULL,
  `voter_card` varchar(250) DEFAULT NULL,
  `user_id` int(11) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tblstaff_personal_info`
--
ALTER TABLE `tblstaff_personal_info`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tblstaff_personal_info`
--
ALTER TABLE `tblstaff_personal_info`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
