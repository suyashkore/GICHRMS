-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Aug 29, 2023 at 05:01 PM
-- Server version: 5.7.43
-- PHP Version: 8.1.16

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `t5e3s4tgi_demo_erp`
--

-- --------------------------------------------------------

--
-- Table structure for table `tblhistory_Audit`
--

CREATE TABLE `tblhistory_Audit` (
  `id` int(11) NOT NULL,
  `PlantID` int(11) NOT NULL,
  `FY` varchar(2) NOT NULL,
  `OrderID` varchar(11) NOT NULL,
  `BillID` varchar(11) DEFAULT NULL,
  `TransID` varchar(11) DEFAULT NULL,
  `IsSchemeYN` varchar(10) NOT NULL DEFAULT 'N',
  `TransDate` datetime(6) NOT NULL,
  `TransDate2` datetime(6) DEFAULT NULL,
  `TType` varchar(1) NOT NULL,
  `TType2` varchar(50) DEFAULT NULL,
  `AccountID` varchar(50) NOT NULL,
  `ItemID` varchar(50) NOT NULL,
  `GodownID` varchar(100) DEFAULT NULL,
  `PurchRate` decimal(16,2) DEFAULT NULL,
  `Mrp` decimal(16,2) DEFAULT NULL,
  `SaleRate` decimal(16,2) DEFAULT NULL,
  `BasicRate` decimal(16,3) DEFAULT NULL,
  `SuppliedIn` varchar(2) NOT NULL,
  `OrderQty` decimal(16,3) DEFAULT NULL,
  `eOrderQty` decimal(16,2) DEFAULT NULL,
  `ereason` text,
  `BilledQty` decimal(16,3) DEFAULT NULL,
  `DiscPerc` decimal(6,2) DEFAULT NULL,
  `DiscAmt` decimal(14,6) DEFAULT NULL,
  `gst` decimal(6,2) DEFAULT NULL,
  `gstamt` decimal(16,4) DEFAULT NULL,
  `cgst` decimal(6,2) DEFAULT NULL,
  `cgstamt` decimal(16,2) DEFAULT NULL,
  `sgst` decimal(6,2) DEFAULT NULL,
  `sgstamt` decimal(16,2) DEFAULT NULL,
  `igst` decimal(6,2) DEFAULT NULL,
  `igstamt` decimal(16,2) DEFAULT NULL,
  `CaseQty` bigint(20) DEFAULT NULL,
  `Cases` decimal(16,3) DEFAULT NULL,
  `OrderAmt` decimal(16,2) DEFAULT NULL,
  `ChallanAmt` decimal(16,2) DEFAULT NULL,
  `NetOrderAmt` decimal(16,2) DEFAULT NULL,
  `NetChallanAmt` decimal(16,2) DEFAULT NULL,
  `Ordinalno` int(11) NOT NULL,
  `rowid` int(11) NOT NULL,
  `UserID` varchar(50) NOT NULL,
  `cnfid` varchar(50) NOT NULL,
  `UserID2` varchar(50) DEFAULT NULL,
  `Lupdate` varchar(50) DEFAULT NULL,
  `created_by` varchar(10) DEFAULT NULL,
  `created_at` datetime(6) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tblhistory_Audit`
--
ALTER TABLE `tblhistory_Audit`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tblhistory_Audit`
--
ALTER TABLE `tblhistory_Audit`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
