-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Feb 20, 2024 at 01:35 PM
-- Server version: 5.7.44
-- PHP Version: 8.1.27

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `hmssoft7_testdb`
--

-- --------------------------------------------------------

--
-- Table structure for table `item_stock`
--

CREATE TABLE `item_stock` (
  `id` int(11) NOT NULL,
  `item_id` int(11) DEFAULT NULL,
  `category_id` int(11) NOT NULL,
  `supplier_id` int(11) DEFAULT NULL,
  `symbol` varchar(10) NOT NULL DEFAULT '+',
  `store_id` int(11) DEFAULT NULL,
  `batch_number` varchar(50) DEFAULT NULL,
  `exp_date` date DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL,
  `purchase_price` float(10,2) DEFAULT '0.00',
  `date` date DEFAULT NULL,
  `attachment` varchar(250) DEFAULT NULL,
  `description` text,
  `is_active` varchar(10) DEFAULT 'yes',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `item_stock`
--

INSERT INTO `item_stock` (`id`, `item_id`, `category_id`, `supplier_id`, `symbol`, `store_id`, `batch_number`, `exp_date`, `quantity`, `purchase_price`, `date`, `attachment`, `description`, `is_active`, `created_at`) VALUES
(1, 989, 7, NULL, '+', NULL, NULL, NULL, 0, 10000.00, '2022-11-09', NULL, '', 'yes', '2022-11-09 07:49:12'),
(2, 1, 5, NULL, '+', NULL, NULL, NULL, 5, 16500.00, '2023-02-01', NULL, '', 'yes', '2023-02-01 11:57:35'),
(3, 683, 1, NULL, '+', NULL, NULL, NULL, 1100, 10000.00, '2023-10-13', NULL, 'bfdhgfjgfj', 'yes', '2023-10-13 10:21:51'),
(4, 247, 2, NULL, '+', NULL, NULL, NULL, 10, 20.00, '2024-02-06', NULL, 'nvnb', 'yes', '2024-02-06 05:09:09'),
(5, 252, 2, NULL, '+', NULL, NULL, NULL, 15, 100.00, '2024-02-06', NULL, '', 'yes', '2024-02-06 05:11:41'),
(6, 677, 1, NULL, '+', NULL, NULL, NULL, 46, 3456.00, '2024-02-12', NULL, '', 'yes', '2024-02-15 09:40:49'),
(7, 206, 7, NULL, '+', NULL, NULL, NULL, 34, 5689.00, '2024-02-12', NULL, '', 'yes', '2024-02-12 09:22:43'),
(8, 681, 1, NULL, '+', NULL, NULL, NULL, 5, 699.00, '2024-02-13', NULL, 'hklnk', 'yes', '2024-02-15 09:40:34'),
(9, 139, 6, NULL, '+', NULL, NULL, NULL, 1, 90000.00, '2024-02-13', NULL, 'hkbkbnl', 'yes', '2024-02-13 10:46:40'),
(10, 677, 1, 3, '+', 1, NULL, NULL, 4, 34.00, '2024-02-15', NULL, '', 'yes', '2024-02-15 12:00:05'),
(11, 690, 1, 3, '+', 2, NULL, NULL, 2, 30000.00, '2024-02-15', NULL, '', 'yes', '2024-02-15 12:01:14'),
(12, 2, 5, 3, '+', 2, NULL, NULL, 10, 10000.00, '2024-02-15', NULL, '', 'yes', '2024-02-15 13:02:39'),
(13, 2, 5, 3, '+', 2, NULL, NULL, 12, 123.00, '2024-02-15', NULL, '', 'yes', '2024-02-15 13:16:15'),
(14, 6, 5, 4, '+', 1, NULL, NULL, 1, 25000.00, '2024-02-16', NULL, '', 'yes', '2024-02-16 06:44:46'),
(16, 299, 14, 5, '+', 8, NULL, NULL, 9, 500.00, '2024-02-17', NULL, 'njkn', 'yes', '2024-02-17 05:58:06');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `item_stock`
--
ALTER TABLE `item_stock`
  ADD PRIMARY KEY (`id`),
  ADD KEY `item_id` (`item_id`),
  ADD KEY `supplier_id` (`supplier_id`),
  ADD KEY `store_id` (`store_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `item_stock`
--
ALTER TABLE `item_stock`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `item_stock`
--
ALTER TABLE `item_stock`
  ADD CONSTRAINT `item_stock_ibfk_1` FOREIGN KEY (`item_id`) REFERENCES `item` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
