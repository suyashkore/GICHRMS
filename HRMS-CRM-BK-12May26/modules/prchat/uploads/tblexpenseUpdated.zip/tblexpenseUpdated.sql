-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Nov 09, 2023 at 11:43 AM
-- Server version: 5.7.44
-- PHP Version: 8.1.16

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `k14irtidev7_New_dev_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `tblexpenseUpdated`
--

CREATE TABLE `tblexpenseUpdated` (
  `id` int(11) NOT NULL,
  `Category` varchar(10) NOT NULL,
  `expense_date` datetime(6) NOT NULL,
  `travel_distance` decimal(15,2) DEFAULT NULL,
  `Amount` decimal(15,2) DEFAULT NULL,
  `address` longtext,
  `remark` longtext,
  `file_upload` varchar(200) DEFAULT NULL,
  `UserID` varchar(20) DEFAULT NULL,
  `created_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `UserID2` varchar(100) DEFAULT NULL,
  `Lupdate` datetime(6) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tblexpenseUpdated`
--
ALTER TABLE `tblexpenseUpdated`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tblexpenseUpdated`
--
ALTER TABLE `tblexpenseUpdated`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
