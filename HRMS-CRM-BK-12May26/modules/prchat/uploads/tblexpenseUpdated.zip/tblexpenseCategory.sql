-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Nov 09, 2023 at 11:46 AM
-- Server version: 5.7.44
-- PHP Version: 8.1.16

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `k14irtidev7_New_dev_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `tblexpenseCategory`
--

CREATE TABLE `tblexpenseCategory` (
  `id` int(11) NOT NULL,
  `CategoryName` varchar(200) NOT NULL,
  `UserID` varchar(10) DEFAULT NULL,
  `Transdate` datetime(6) DEFAULT NULL,
  `UserID2` varchar(10) DEFAULT NULL,
  `Lupdate` datetime(6) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblexpenseCategory`
--

INSERT INTO `tblexpenseCategory` (`id`, `CategoryName`, `UserID`, `Transdate`, `UserID2`, `Lupdate`) VALUES
(1, 'Travel Expense', 'GIC7', '2023-11-09 11:43:42.000000', NULL, NULL),
(2, 'Accommodation ', 'GIC7', '2023-11-09 11:43:42.000000', NULL, NULL),
(3, 'Food', 'GIC7', '2023-11-09 11:45:46.000000', NULL, NULL),
(4, 'Other', 'GIC7', '2023-11-09 11:45:46.000000', NULL, NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tblexpenseCategory`
--
ALTER TABLE `tblexpenseCategory`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tblexpenseCategory`
--
ALTER TABLE `tblexpenseCategory`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
