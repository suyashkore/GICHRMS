-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Sep 05, 2023 at 05:45 PM
-- Server version: 5.7.43
-- PHP Version: 8.1.16

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `kirti2ginf9_erp_db_k`
--

-- --------------------------------------------------------

--
-- Table structure for table `tblxx_statelist`
--

CREATE TABLE `tblxx_statelist` (
  `id` int(10) NOT NULL,
  `country_id` int(10) NOT NULL DEFAULT '1',
  `state_name` varchar(200) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `short_name` varchar(10) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblxx_statelist`
--

INSERT INTO `tblxx_statelist` (`id`, `country_id`, `state_name`, `status`, `short_name`) VALUES
(1, 1, 'JAMMU AND KASHMIR', 1, 'JK'),
(2, 1, 'HIMACHAL PRADESH', 1, 'HP'),
(3, 1, 'PUNJAB', 1, 'PU'),
(4, 1, 'CHANDIGARH', 1, 'CH'),
(5, 1, 'UTTARAKHAND', 1, 'UK'),
(6, 1, 'HARYANA', 1, 'HAR'),
(7, 1, 'DELHI', 1, 'DEL'),
(8, 1, 'RAJASTHAN', 1, 'RAJ'),
(9, 1, 'UTTAR PRADESH', 1, 'UP'),
(10, 1, 'BIHAR', 1, 'B'),
(11, 1, 'SIKKIM', 1, 'S'),
(12, 1, 'ARUNACHAL PRADESH', 1, 'ARP'),
(13, 1, 'NAGALAND', 1, 'N'),
(14, 1, 'MANIPUR', 1, 'MPUR'),
(15, 1, 'MIZORAM', 1, 'MIZ'),
(16, 1, 'TRIPURA', 1, 'TR'),
(17, 1, 'MEGHALAYA', 1, 'ML'),
(18, 1, 'ASSAM', 1, 'AS'),
(19, 1, 'WEST BENGAL', 1, 'WB'),
(20, 1, 'JHARKHAND', 1, 'JH'),
(21, 1, 'ODISHA', 1, 'OR'),
(22, 1, 'CHHATTISGARH', 1, 'C'),
(23, 1, 'MADHYA PRADESH', 1, 'MP'),
(24, 1, 'GUJARAT', 1, 'GUJ'),
(25, 1, 'DAMAN AND DIU', 1, 'DD'),
(26, 1, 'DADRA AND NAGAR HAVELI', 1, 'DNH'),
(27, 1, 'MAHARASHTRA', 1, 'MH'),
(28, 1, 'ANDHRA PRADESH', 1, 'AP'),
(29, 1, 'KARNATAKA', 1, 'KR'),
(30, 1, 'GOA', 1, 'G'),
(31, 1, 'LAKSHADWEEP', 1, 'LD'),
(32, 1, 'KERALA', 1, 'KE'),
(33, 1, 'TAMIL NADU', 1, 'TN'),
(34, 1, 'PUDUCHERRY', 1, 'PC'),
(35, 1, 'ANDAMAN AND NICOBAR ISLANDS', 1, 'ANI'),
(36, 1, 'TELANGANA', 1, 'TG'),
(37, 1, 'LADAKH', 1, 'LA');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tblxx_statelist`
--
ALTER TABLE `tblxx_statelist`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tblxx_statelist`
--
ALTER TABLE `tblxx_statelist`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=38;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
