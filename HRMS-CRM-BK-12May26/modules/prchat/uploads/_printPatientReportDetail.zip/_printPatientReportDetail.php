<link rel="stylesheet" href="<?php echo base_url(); ?>backend/dist/css/sh-print.css"> 
 <style> 
 @media print { *{
       font-size: 9pt;
    }
    .print_text{
       font-size: 9pt;
    }
    
    }
    </style>
<div class="print-area">
<div class="row" style="margin-left:20px;margin-right:20px;">
        <div class="col-12">
           <?php //if (!empty($print_details[0]['print_header'])) { ?>
                        <div class="pprinta4">
                            <img src="<?php echo base_url() . 'uploads/printing/4.png'; ?>" class="img-responsive">
                        </div>
                    <?php //} ?>
                    <hr style="height: 0px; clear: both;"> 
            <div class="card">
                <div class="card-body">  
                    <div class="row" style="margin-left:20px;margin-right:20px;">
                        <div class="col-md-8">                          
                            <p><span class="font-bold"><?php echo 'Report #'; ?>: </span> <?php echo $this->customlib->getSessionPrefixByType('pathology_billing').$result->bill_no; ?></p>
                            <p><span class="font-bold"><?php echo $this->lang->line('patient'); ?>:</span> <?php echo composePatientName($result->patient_name,$result->patient_id).' ('.$result->patient_id.')'; ?></p>
                            <!--<p><span class="font-bold"><?php echo $this->lang->line('case_id'); ?> :</span> <?php echo $result->case_reference_id; ?></p>-->
                            <!--<p><span class="font-bold"><?php echo $this->lang->line('age'); ?> :</span> <?php echo $this->customlib->getPatientAge($result->age,$result->month,$result->day); ?></p>-->
                             <p><span class="font-bold"><?php echo 'Age / Gender'; ?> :</span> <?php echo $result->age . ' / '. $result->gender; ?></p>
                            
                            <!--<p><span class="text-muted font-bold"><?php echo $this->lang->line('expected_date'); ?>: </span> <?php echo $this->customlib->YYYYMMDDTodateFormat($result->reporting_date); ?></p>                                            -->
                            <p><span class="font-bold">Ref By :</span> <?php echo $result->doctor_name; ?></p>
                            <!--<p><span class="font-bold"><?php echo $this->lang->line('gender'); ?> :</span> <?php echo $result->gender; ?></p>-->
                             
                            <!--<p><span class="font-bold"><?php echo $this->lang->line('collection_by'); ?> :</span> <?php echo composeStaffNameByString($result->collection_specialist_staff_name,$result->collection_specialist_staff_surname,$result->collection_specialist_staff_employee_id); ?></p>-->
                            <!--<p><span class="font-bold"><?php echo $this->lang->line('pathology_center'); ?> :</span> <?php echo $result->pathology_center ?></p>                             -->
                        </div>
                        <div class="col-md-4 text-left"> 
                            <p><span class="font-bold"><?php echo 'Collection DateTime'; ?>: </span> <?php echo $this->customlib->YYYYMMDDHisTodateFormat($result->LabReceivedDate, $this->customlib->getHospitalTimeFormat()); ?></p>
                             <p><span class="font-bold"><?php echo $this->lang->line('collection_by'); ?> :</span><?php echo $result->pathology_center; ?> </p>
                             <p><span class="text-muted font-bold"><?php echo "Reporting DateTime"; ?>: </span> <?php echo $this->customlib->YYYYMMDDHisTodateFormat($result->printDate, $this->customlib->getHospitalTimeFormat()); ?></p> 
                            
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-12">
                           <h4 class="text-center" style="margin-top:0px; margin-buttom:0px;">
                               <?php $testname = explode('#',$result->test_name); ?>
      <strong><?php echo $testname[0]; ?></strong> <?php echo "(".$result->short_name.")"; ?>
</h4>
                               <table class="noborder_table" style="margin-left:10px; margin-top:0px; margin-buttom:0px; padding:0px; height:auto;">
                             <!--<thead>-->
                                <tr class="">
                                   <!--<td><strong>#</strong></td>-->
                                   <td class="text-left"><strong><?php echo $this->lang->line('test_parameter_name'); ?></strong></td>
                                   <td class="text-center"><strong><?php echo 'Value'; ?></strong></td>
                                   <td class="text-center"><strong><?php echo $this->lang->line('reference_range'); ?></strong></td>
                                   
                                </tr>
                             <!--</thead>-->
                             </table>
                                <table id="" class="noborder_table" style="margin-left:10px; border:1px solid #000; ">
                                <?php
                      $row_counter=1;
                        foreach ($result->pathology_parameter as $parameter_key=> $parameter_value) {
                              $row_cls="";
                  
                            ?>     
                            <?php
                                $paraname = explode('#',$parameter_value->parameter_name);
                                ?>
                         <tr>
                            <!--<td><?php //echo $row_counter; ?></td>-->
                            <td class="text-left" width="50%"><?php echo strtoupper($paraname[0]); ?></td>
                              <!--<div class="bill_item_footer text-muted"><label><?php if($parameter_value->description !=''){ echo $this->lang->line('description').': ';} ?></label> <?php echo $parameter_value->description; ?></div> </td> -->
                            <td class="text-center" >
                                <?php //echo $parameter_value->pathology_report_value; ?>
                                <?php //echo $parameter_value->reference_range." ".$parameter_value->unit_name; ?>
                                <?php 
    if(!$parameter_value->pathology_report_value){
        echo $parameter_value->pathology_report_value;
    }
    else
    {
        
    
    if(strpos($parameter_value->reference_range,',') !== false){
        $seprange = explode(',',$parameter_value->reference_range);
        
        if($result->gender == 'Male'){
            $refrange = explode(':',$seprange[0]);
            $refrange = explode('-',$refrange[1]);
            //echo $refrange[0];
            if($refrange[0]){
                
            if(( (float) $parameter_value->pathology_report_value < (float) $refrange[0]) || ((float) $parameter_value->pathology_report_value > (float) $refrange[1])){
             echo '<b>'.$parameter_value->pathology_report_value.'</b>';
             } 
             else {
                echo $parameter_value->pathology_report_value;
                }
            }
            else
            {
                echo $parameter_value->pathology_report_value;
            }
        }
        
        if($result->gender == 'Female'){
            $refrange = explode(':',$seprange[1]);
            $refrange = explode('-',$refrange[1]);
            //echo $refrange[0];
            
            if($refrange[0]){
                
            if(( (float) $parameter_value->pathology_report_value < (float) $refrange[0]) || ((float) $parameter_value->pathology_report_value > (float) $refrange[1])){
             echo '<b>'.$parameter_value->pathology_report_value.'</b>';
             } 
             else {
                echo $parameter_value->pathology_report_value;
                }
            }
            else
            {
                echo $parameter_value->pathology_report_value;
            }
        }
        
    }
    
   else if(strpos($parameter_value->reference_range,'<') !== false){
        $seprange = explode('<',$parameter_value->reference_range);
        
        if(( (float) $parameter_value->pathology_report_value >= (float) $seprange[1])){
         echo '<b>'.$parameter_value->pathology_report_value.'</b>';
         } 
         else { 
            echo $parameter_value->pathology_report_value;
            }
    }
    
    else if(strpos($parameter_value->reference_range,'>') !== false){
         $seprange = explode('>',$parameter_value->reference_range);
        
        if(( (float) $parameter_value->pathology_report_value <= (float) $seprange[1])){
         echo '<b>'.$parameter_value->pathology_report_value.'</b>';
         } 
         else { 
            echo $parameter_value->pathology_report_value;
            }
    }
    
    else if((substr_count($parameter_value->reference_range, '-')) == 1){
        $refrange = explode('-',$parameter_value->reference_range);
            
        if(( (float) $parameter_value->pathology_report_value < (float) $refrange[0]) || ((float) $parameter_value->pathology_report_value > (float) $refrange[1])){
         echo '<b>'.$parameter_value->pathology_report_value.'</b>';
         } 
         else {
            echo $parameter_value->pathology_report_value;
            }
        
    }else{
      echo $parameter_value->pathology_report_value;
}
    
    }
    ?>
                                </td>
                            <td class="text-center"><?php echo $parameter_value->reference_range." ".$parameter_value->unit_name; ?></td>
                        </tr>                               
                        <?php
                    //$row_counter++;
                        }
                        ?>
                                <?php //echo $result->field_value;
                                //echo '<pre>';
                                //print_r($result);
                                ?>
                              </table>
                           
                         
                          
                          <table class="printablea4"  width="97%" style="margin-right:20px;margin-left:20px;margin-top:0px; margin-buttom:0px; padding:0px; height:auto; ">
                     
                            <tr>
                                <td  style="text-align:justify;"><?php
                              if($result->field_value)
                              {
                                echo '<h5>Notes:</h5>'.$result->field_value;
                              }
                              ?></td>
                            </tr>
                     
                    </table>
                       
                          
                          <!--<hr style="height: 1px; clear: both;"> -->
                          <!--<hr class="border_bottom" style="height: 1px; clear: both;margin-bottom: 15px; margin-top: 15px">-->
                    <table class="printablea4" width="100%" style="width:25%; float: right; margin-right:10px;margin-left:15px; margin-bottom:0px; padding:0px; height:auto;">
                     <tr>
                              <td style="padding:0px 0px 0px 60px;"><img src="<?php  echo base_url() . 'uploads/printing/sign2.jpeg';  ?>" style="height:45px;"> </td>
                           </tr>
                            <tr>
                                <!--<td><?php //echo '<b>Dr. Abhishek Malviya <br>MBBS, MD (Pathology)</b>'; ?></td>-->
                                <td style="text-align:center;"><?php echo '<b>Dr Santosh Chaurasia</b>'; ?></td>
                            </tr>
                            <tr>
                                <!--<td><?php //echo '<b>Dr. Abhishek Malviya <br>MBBS, MD (Pathology)</b>'; ?></td>-->
                                <td style="text-align:center;"><?php echo '<b>M.B.B.S, M.D. (Pathology)</b>'; ?></td>
                            </tr>
                     
                    </table>
                   <!--<hr style="height: 1px; clear: both;margin-bottom: 10px; margin-top: 10px"> -->
                
                        </div>
                    </div>
                </div>
            </div>
          <div style="clear:both"></div>
             <p>
                        <?php
                        if (!empty($print_details[0]['print_footer'])) {
                            echo $print_details[0]['print_footer'];
                        }
                        ?>                          
                        </p>
        </div>
    </div>
</div>
