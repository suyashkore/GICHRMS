-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Aug 31, 2023 at 12:01 PM
-- Server version: 5.7.43
-- PHP Version: 8.1.16

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `t5e3s4tgi_demo_erp`
--

-- --------------------------------------------------------

--
-- Table structure for table `tblsalesreturn_audit`
--

CREATE TABLE `tblsalesreturn_audit` (
  `PlantID` int(11) NOT NULL,
  `FY` varchar(2) NOT NULL,
  `BT` varchar(1) NOT NULL,
  `SalesRtnID` varchar(11) NOT NULL,
  `Transdate` datetime(6) NOT NULL,
  `AccountID` varchar(50) NOT NULL,
  `PayType` varchar(1) NOT NULL,
  `SaleAmt` decimal(16,2) NOT NULL,
  `DiscAmt` decimal(16,2) DEFAULT NULL,
  `VATAmt` decimal(14,2) DEFAULT NULL,
  `SATAmt` decimal(14,2) DEFAULT NULL,
  `CSTAmt` decimal(14,2) DEFAULT NULL,
  `BillAmt` decimal(16,2) NOT NULL,
  `RndAmt` bigint(20) NOT NULL,
  `ItCount` int(11) NOT NULL,
  `UserID` varchar(50) NOT NULL,
  `SalesRtnTypeID` varchar(11) DEFAULT NULL,
  `cgstamt` decimal(16,2) DEFAULT NULL,
  `sgstamt` decimal(16,2) DEFAULT NULL,
  `igstamt` decimal(16,2) DEFAULT NULL,
  `passedfrom` varchar(50) NOT NULL,
  `UserID2` varchar(50) DEFAULT NULL,
  `Lupdate` varchar(50) DEFAULT NULL,
  `created_by` varchar(20) DEFAULT NULL,
  `created_at` datetime(6) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tblsalesreturn_audit`
--
ALTER TABLE `tblsalesreturn_audit`
  ADD PRIMARY KEY (`SalesRtnID`) USING BTREE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
