<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/userguide3/general/urls.html
	 */
	 
	 public function __construct()
	 {
		parent::__construct();
		$this->load->helper('url');
		
	}
	public function index()
	{
		$this->load->view('welcome_message');
		
	}
	
	public function about()
	{
		$this->load->view('about');
	}
	
	public function service()
	{
		$this->load->view('service');
	}
	
	public function projects()
	{
		$this->load->view('projects');
	}
	
	public function blog()
	{
		$this->load->view('blog');
	}
	
	public function serviceDetails()
	{
		$this->load->view('service_details');
	}
	
	public function blogDetails()
	{
		$this->load->view('blog_details');
	}
	
	public function projectDetails()
	{
		$this->load->view('project_details');
	}
	
	public function contact()
	{
		$this->load->view('contact');
	}
	
	public function vision()
	{
		$this->load->view('vision');
	}
	
	public function leadership()
	{
		$this->load->view('leadership');
	}
	
	public function milestone()
	{
		$this->load->view('milestone');
	}
	
	public function principle()
	{
		$this->load->view('principle');
	}
	
	public function business()
	{
		$this->load->view('bussiness');
	}
	
	public function technology()
	{
		$this->load->view('technology');
	}
	
	public function career()
	{
		$this->load->view('career');
	}
}
