<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Mikro Innotech Pvt. Ltd. - Vision/Mission</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="assets/img/favicon.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link
    href="https://fonts.googleapis.com/css2?family=Open+Sans:ital,wght@0,300;0,400;0,500;0,600;0,700;1,300;1,400;1,600;1,700&family=Roboto:ital,wght@0,300;0,400;0,500;0,600;0,700;1,300;1,400;1,500;1,600;1,700&family=Work+Sans:ital,wght@0,300;0,400;0,500;0,600;0,700;1,300;1,400;1,500;1,600;1,700&display=swap"
    rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="<?php echo base_url(); ?>/assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="<?php echo base_url(); ?>/assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="<?php echo base_url(); ?>/assets/vendor/fontawesome-free/css/all.min.css" rel="stylesheet">
  <link href="<?php echo base_url(); ?>/assets/vendor/aos/aos.css" rel="stylesheet">
  <link href="<?php echo base_url(); ?>/assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="<?php echo base_url(); ?>/assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="<?php echo base_url(); ?>/assets/css/main.css" rel="stylesheet">

  <!-- =======================================================
  * Template Name: UpConstruction - v1.3.0
  * Template URL: https://bootstrapmade.com/upconstruction-bootstrap-construction-website-template/
  * Author: BootstrapMade.com
  * License: https://bootstrapmade.com/license/
  ======================================================== -->
</head>

<body>

  <!-- ======= Header ======= -->
  <header id="header" class="header d-flex align-items-center">
    <div class="container-fluid container-xl d-flex align-items-center justify-content-between">

      <a href="<?php echo base_url(); ?>welcome/" class="logo d-flex align-items-center">
        <!-- Uncomment the line below if you also wish to use an image logo -->
        <img src="<?php echo base_url(); ?>/assets/img/mikrologo2.png" alt=""> 
        <!--<h1>UpConstruction<span>.</span></h1>-->
      </a>

      <i class="mobile-nav-toggle mobile-nav-show bi bi-list"></i>
      <i class="mobile-nav-toggle mobile-nav-hide d-none bi bi-x"></i>
      <nav id="navbar" class="navbar">
        <ul>
          <li><a href="<?php echo base_url(); ?>welcome/">Home</a></li>
          <li class="dropdown"><a href="<?php echo base_url(); ?>welcome/about"><span>About</span> <i
                class="bi bi-chevron-down dropdown-indicator"></i></a>
            <ul>
              <li><a href="<?php echo base_url(); ?>welcome/vision">Vision/Mission</a></li>
              <!--<li class="dropdown"><a href="#"><span>Deep Dropdown</span> <i
                    class="bi bi-chevron-down dropdown-indicator"></i></a>
                <ul>
                  <li><a href="#">Deep Dropdown 1</a></li>
                  <li><a href="#">Deep Dropdown 2</a></li>
                  <li><a href="#">Deep Dropdown 3</a></li>
                  <li><a href="#">Deep Dropdown 4</a></li>
                  <li><a href="#">Deep Dropdown 5</a></li>
                </ul>
              </li>-->
              <li><a href="<?php echo base_url(); ?>welcome/milestone">Milestone</a></li>
              <li><a href="<?php echo base_url(); ?>welcome/leadership">Leadership</a></li>
              <li><a href="#">News</a></li>
            </ul>
          </li>
          <li><a href="<?php echo base_url(); ?>welcome/business">Business</a></li>
          <li><a href="<?php echo base_url(); ?>welcome/technology">Technology</a></li>
		  <li><a href="<?php echo base_url(); ?>welcome/principle">Principle</a></li>
		  <li><a href="<?php echo base_url(); ?>welcome/career">Career</a></li>
          <li><a href="<?php echo base_url(); ?>welcome/blog">Blog</a></li>
          <li><a href="<?php echo base_url(); ?>welcome/contact">Contact</a></li>
        </ul>
      </nav><!-- .navbar -->

    </div>
  </header><!-- End Header -->

  <main id="main">

    <!-- ======= Breadcrumbs ======= -->
    <div class="breadcrumbs d-flex align-items-center" style="background-image: url('<?php echo base_url(); ?>/assets/img/breadcrumbs-bg.jpg');">
      <div class="container position-relative d-flex flex-column align-items-center" data-aos="fade">

        <h2>Milestone</h2>
        <ol>
          <li><a href="<?php echo base_url(); ?>welcome/">Home</a></li>
		  <li><a href="<?php echo base_url(); ?>welcome/about">About</a></li>
          <li>Milestone</li>
        </ol>

      </div>
    </div><!-- End Breadcrumbs -->
	
	<!-- ======= Servie Cards Section ======= -->
    <section id="services-cards" class="services-cards">
      <div class="container" data-aos="fade-up">

        <div class="row gy-4">

          <div class="col-lg-12 col-md-6" data-aos="zoom-in" data-aos-delay="100">
            <h3 style="font-size:31px">Milestones</h3>
            <p></p>
            <ul class="list-unstyled" >
              <li style="font-size:15px"><i class="bi bi-check2"></i> <span>Started in the year 2006, Mikro was known as "Mikro Technic" - a trading house selling standard products like Leak Testers, Eddy Current Testers, Measuring Station etc. Our incredible journey since then has witnessed revolutionary milestones. Mikro is putting its best foot forward in reimagining the Industrial Automation future. With state-of-art technologies & innovative solutions, we aim to reinforce competitive advantages & achieve greater summits year after year!</span></li>
              <li style="font-size:15px"><i class="bi bi-check2"></i> <span>Mikro has now diversified supplying Indian and Global industries with SPM, Assembly Line Automation in Car body, Engine & Transmission for automotive domain. Mikro is providing complete Robotic Automation solution for industrial needs. Feather on cap in Mikro's incredible journey is providing complete solution for Laser applications in Automotive, Pharma, Medical equipment industry.</span></li>
              <li style="font-size:15px"><i class="bi bi-check2"></i> <span>With next step forward, Mikro joined in Atmanirbhar Bharat initiative. On 26th Jan 2021, Mikro became First Private Sector Company In India to offer " State of Art Technology on the Republic day event through Mikro Technology Center (MTC). It is equipped with Robotics Laser technology for performing Laser Welding/Cladding/Brazing/Cleaning/ Hardening / Marking etc. It is enabling platform for the industry to try their requirements with minimum cost for development for pilots and proto typing.</span></li>
			  <li style="font-size:15px"><i class="bi bi-check2"></i> <span>As one stop solution in automation, Mikro in collaboration with Yaskawa 6 Axis Robot can provide Laser Welding, Spot Welding, Sealant Dispensing, Material Handling solutions. Further in collaboration with SCARA Delta Robot, Mikro provide smart factory solution by Industry 4.0 approach. The SCARA robots shall be used in fast moving application like 3-4 Second Cycle time and 4 Mtr/sec speed for Sealant Dispensing, Pick and Place, Screwing, Machine Tending ,Inspection used for different segments of industry like Automotive, Electronics, Pharma and FMCG.</span></li>
			  <li style="font-size:15px"><i class="bi bi-check2"></i> <span>Mikro is delivering value added product & services to customers which includes OEMs', TIER-1 and TIER-2 companies. Our vision entails worldwide expansion with innovation backed by a team of experts making a mark on the Industrial automation.</span></li>
			  <li style="font-size:15px"><i class="bi bi-check2"></i> <span>Mikro has put the best steps forward to make India आत्मनिर्भर in our chosen field of expertise. We are excited to serve the industry with our newest offering. With our quality, diversified products and with the support of good, talented team, Mikro is Looking forward to expand its business world-wide and be a part in our customer's success!!

</span></li>
			</ul>
          </div><!-- End feature item-->
        </div>
      </div>
    </section><!-- End Servie Cards Section -->

 <section id="get-started" class="get-started section-bg">
	<div class="container">

        <div class="row justify-content-between gy-4">

          <!--<div class="col-lg-6 d-flex align-items-center" data-aos="fade-up">
            <div class="content">
              <h3>About Us</h3>
              <p>MIKRO was established in 2008 to deliver world class automation solutions customized to Indian/International markets.
              <p>MIKRO has experienced business growth exceeding 50 percent year-over-year through innovation and a focus on customer success. We enjoy the challenge of reshaping industrial challenges and converting them into more productive and unique high-performance systems.We leverage on our in-depth knowledge and proven design & implementation experiences to meet the complex automation systems needs of multinational customers in industries such as healthcare, Automobiles, electrical / electronics and consumer products. We deliver custom solutions and provide consulting grounded in reality.</p>
			  <a href="<?php echo base_url(); ?>welcome/about" class="readmore stretched-link">Read more <i
                  class="bi bi-arrow-right"></i></a>
			</div>
          </div>-->

          <div class="col-lg-12" data-aos="fade">
		  
                <img src="<?php echo base_url(); ?>/assets/img/milestone-new1.jpg" alt="" class="img-fluid" style="padding-left:125px;height: 350px;">
				
            <!--<form action="forms/quote.php" method="post" class="php-email-form">
              <h3>Get a quote</h3>
              <p>Vel nobis odio laboriosam et hic voluptatem. Inventore vitae totam. Rerum repellendus enim linead sero
                park flows.</p>
              <div class="row gy-3">

                <div class="col-md-12">
                  <input type="text" name="name" class="form-control" placeholder="Name" required>
                </div>

                <div class="col-md-12 ">
                  <input type="email" class="form-control" name="email" placeholder="Email" required>
                </div>

                <div class="col-md-12">
                  <input type="text" class="form-control" name="phone" placeholder="Phone" required>
                </div>

                <div class="col-md-12">
                  <textarea class="form-control" name="message" rows="6" placeholder="Message" required></textarea>
                </div>

                <div class="col-md-12 text-center">
                  <div class="loading">Loading</div>
                  <div class="error-message"></div>
                  <div class="sent-message">Your quote request has been sent successfully. Thank you!</div>

                  <button type="submit">Get a quote</button>
                </div>

              </div>
            </form>-->
          </div><!-- End Quote Form -->

        </div>

      </div>
    </section><!-- End Get Started Section -->
	

  </main><!-- End #main -->

  <!-- ======= Footer ======= -->
  <footer id="footer" class="footer">
    <div class="footer-content position-relative">
      <div class="container">
        <div class="row">

          <div class="col-lg-4 col-md-6">
            <div class="footer-info">
              <h3 style="font-size:23px">Mikro Innotech Pvt. Ltd.</h3>
              <p>
				225, Sasewadi, Taluka Bhor,
				Off Pune Bangalore Expressway,
				Pune - 412205<br><br>
                <strong>Phone:</strong> +91-20-20240556 / +91 8308802300<br>
                <strong>Email:</strong> mikroinnotech@gmail.com<br><span class="padding_left" style="padding-left:50px">sales@mikroindia.com</span>
              </p>
              <div class="social-links d-flex mt-3">
				<!--<a href="#" class="d-flex align-items-center justify-content-center"><i class="bi bi-twitter"></i></a>-->
				<a href="https://www.facebook.com/mikroindia" class="d-flex align-items-center justify-content-center"><i class="bi bi-facebook"></i></a>
                <a href="https://instagram.com/mikro_india?igshid=t88sx3gzi8g0" class="d-flex align-items-center justify-content-center"><i class="bi bi-instagram"></i></a>
                <a href="https://www.linkedin.com/company/mikro-innotech-india" class="d-flex align-items-center justify-content-center"><i class="bi bi-linkedin"></i></a>
              </div>
            </div>
          </div><!-- End footer info column-->

          <div class="col-lg-4 col-md-3 footer-links">
            <h4 style="padding-left:70px">Useful Links</h4>
			<div class="row">
				<div class="col-lg-6" >
					<ul>
					  <li><a href="#">Home</a></li>
					  <li><a href="#">About us</a></li>
					  <li><a href="#">Project</a></li>
					  <li><a href="#">Gallery</a></li>
					  <li><a href="#">Principle</a></li>
					</ul>
				</div>
				<div class="col-lg-6">
					<ul>
					  <li><a href="#">Training</a></li>
					  <li><a href="#">Career</a></li>
					  <li><a href="#">Blog</a></li>
					  <li><a href="#">Contact</a></li>
					  <li><a href="#">Site Map</a></li>
					</ul>
				</div>
			</div>
          </div><!-- End footer links column-->
		  
		  <div class="col-lg-4 col-md-3 footer-links">
                   
						  <h4 style="padding-left:100px">Get In Touch</h4>
						  
						<form action="forms/contact.php" method="post" role="form" class="php-email-form">
						  <div class="row gy-4" style="margin-bottom:4%">
							<div class="col-lg-6 form-group">
							  <input type="text" name="name" class="form-control" id="name" placeholder="Your Name" required>
							</div>
							<div class="col-lg-6 form-group">
							  <input type="email" class="form-control" name="email" id="email" placeholder="Your Email" required>
							</div>
						  </div>
						  <div class="form-group" style="margin-bottom:4%">
							<input type="text" class="form-control" name="subject" id="subject" placeholder="Subject" required>
						  </div>
						  <div class="form-group" style="margin-bottom:4%">
							<textarea class="form-control" name="message" rows="4" placeholder="Message" required></textarea>
						  </div>
						   <div class="text-center" ><button type="submit" style="border-radius:10px"><div class="send_text" style="color:#feb900">Send Message</div></button></div>
						</form>
          </div>
         </div>
       
        </div>
      </div>
    

    <div class="footer-legal text-center position-relative">
      <div class="container">
        <div class="copyright">
          &copy; Copyright <strong><span>MIKRO 2018</span></strong>. All Rights Reserved
        </div>
        <div class="credits">
          <!-- All the links in the footer should remain intact. -->
          <!-- You can delete the links only if you purchased the pro version. -->
          <!-- Licensing information: https://bootstrapmade.com/license/ -->
          <!-- Purchase the pro version with working PHP/AJAX contact form: https://bootstrapmade.com/upconstruction-bootstrap-construction-website-template/ -->
          Designed & Developed by <a href="https://globalinfocloud.com/"> Global InfoCloud Pvt.Ltd.</a> 
        </div>
      </div>
    </div>

  </footer>
  <!-- End Footer -->

  <a href="#" class="scroll-top d-flex align-items-center justify-content-center"><i
      class="bi bi-arrow-up-short"></i></a>

  <div id="preloader"></div>

  <!-- Vendor JS Files -->
  <script src="<?php echo base_url(); ?>/assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="<?php echo base_url(); ?>/assets/vendor/aos/aos.js"></script>
  <script src="<?php echo base_url(); ?>/assets/vendor/glightbox/js/glightbox.min.js"></script>
  <script src="<?php echo base_url(); ?>/assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
  <script src="<?php echo base_url(); ?>/assets/vendor/swiper/swiper-bundle.min.js"></script>
  <script src="<?php echo base_url(); ?>/assets/vendor/purecounter/purecounter_vanilla.js"></script>
  <script src="<?php echo base_url(); ?>/assets/vendor/php-email-form/validate.js"></script>

  <!-- Template Main JS File -->
  <script src="<?php echo base_url(); ?>/assets/js/main.js"></script>

</body>

</html>