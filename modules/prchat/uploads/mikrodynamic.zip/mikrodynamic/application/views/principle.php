<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Mikro Innotech Pvt. Ltd. - Principle</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="assets/img/favicon.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link
    href="https://fonts.googleapis.com/css2?family=Open+Sans:ital,wght@0,300;0,400;0,500;0,600;0,700;1,300;1,400;1,600;1,700&family=Roboto:ital,wght@0,300;0,400;0,500;0,600;0,700;1,300;1,400;1,500;1,600;1,700&family=Work+Sans:ital,wght@0,300;0,400;0,500;0,600;0,700;1,300;1,400;1,500;1,600;1,700&display=swap"
    rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="<?php echo base_url(); ?>/assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="<?php echo base_url(); ?>/assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="<?php echo base_url(); ?>/assets/vendor/fontawesome-free/css/all.min.css" rel="stylesheet">
  <link href="<?php echo base_url(); ?>/assets/vendor/aos/aos.css" rel="stylesheet">
  <link href="<?php echo base_url(); ?>/assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="<?php echo base_url(); ?>/assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="<?php echo base_url(); ?>/assets/css/main.css" rel="stylesheet">

  <!-- =======================================================
  * Template Name: UpConstruction - v1.3.0
  * Template URL: https://bootstrapmade.com/upconstruction-bootstrap-construction-website-template/
  * Author: BootstrapMade.com
  * License: https://bootstrapmade.com/license/
  ======================================================== -->
</head>

<body>

  <!-- ======= Header ======= -->
  <header id="header" class="header d-flex align-items-center">
    <div class="container-fluid container-xl d-flex align-items-center justify-content-between">

      <a href="<?php echo base_url(); ?>welcome" class="logo d-flex align-items-center">
        <!-- Uncomment the line below if you also wish to use an image logo -->
        <img src="<?php echo base_url(); ?>/assets/img/mikrologo2.png" alt=""> 
        <!--<h1>UpConstruction<span>.</span></h1>-->
      </a>

      <i class="mobile-nav-toggle mobile-nav-show bi bi-list"></i>
      <i class="mobile-nav-toggle mobile-nav-hide d-none bi bi-x"></i>
      <nav id="navbar" class="navbar">
        <ul>
          <li><a href="<?php echo base_url(); ?>welcome/">Home</a></li>
          <li class="dropdown"><a href="<?php echo base_url(); ?>welcome/about"><span>About</span> <i
                class="bi bi-chevron-down dropdown-indicator"></i></a>
            <ul>
              <li><a href="<?php echo base_url(); ?>welcome/vision">Vision/Mission</a></li>
              <!--<li class="dropdown"><a href="#"><span>Deep Dropdown</span> <i
                    class="bi bi-chevron-down dropdown-indicator"></i></a>
                <ul>
                  <li><a href="#">Deep Dropdown 1</a></li>
                  <li><a href="#">Deep Dropdown 2</a></li>
                  <li><a href="#">Deep Dropdown 3</a></li>
                  <li><a href="#">Deep Dropdown 4</a></li>
                  <li><a href="#">Deep Dropdown 5</a></li>
                </ul>
              </li>-->
              <li><a href="<?php echo base_url(); ?>welcome/milestone">Milestone</a></li>
              <li><a href="<?php echo base_url(); ?>welcome/leadership">Leadership</a></li>
              <li><a href="#">News</a></li>
            </ul>
          </li>
          <li><a href="<?php echo base_url(); ?>welcome/business">Business</a></li>
          <li><a href="<?php echo base_url(); ?>welcome/technology">Technology</a></li>
		  <li><a href="<?php echo base_url(); ?>welcome/principle">Principle</a></li>
		  <li><a href="<?php echo base_url(); ?>welcome/career">Career</a></li>
          <li><a href="<?php echo base_url(); ?>welcome/blog">Blog</a></li>
          <li><a href="<?php echo base_url(); ?>welcome/contact">Contact</a></li>
        </ul>
      </nav><!-- .navbar -->

    </div>
  </header><!-- End Header -->

  <main id="main">

    <!-- ======= Breadcrumbs ======= -->
    <div class="breadcrumbs d-flex align-items-center" style="background-image: url('<?php echo base_url(); ?>/assets/img/breadcrumbs-bg.jpg');">
      <div class="container position-relative d-flex flex-column align-items-center" data-aos="fade">

        <h2>Principle</h2>
        <ol>
          <li><a href="<?php echo base_url(); ?>welcome/">Home</a></li>
          <li>Principle</li>
        </ol>

      </div>
    </div><!-- End Breadcrumbs -->
	
	 <!-- ======= principle companies Section ======= -->
    <section id="features" class="features section-bg">
      <div class="container" data-aos="fade-up">

		<div class="section-header">
          <h2>Principle Companies</h2>
        </div>

        <ul class="nav nav-tabs row  g-2 d-flex">

          <li class="nav-item col-2">
            <a class="nav-link active show" data-bs-toggle="tab" data-bs-target="#tab-1">
              <h4>Delta</h4>
            </a>
          </li><!-- End tab nav item -->

		  <li class="nav-item col-1">
            <a class="nav-link" data-bs-toggle="tab" data-bs-target="#tab-2">
              <h4 style="font-size:17px">YASKAWA</h4>
            </a>
			</li><!-- End tab nav item -->

          <li class="nav-item col-2">
            <a class="nav-link" data-bs-toggle="tab" data-bs-target="#tab-3">
              <h4 style="font-size:17px">USON L.P</h4>
            </a>
          </li><!-- End tab nav item -->

		 <li class="nav-item col-1">
            <a class="nav-link" data-bs-toggle="tab" data-bs-target="#tab-4">
              <h4 style="font-size:17px">Takikawa</h4>
            </a>
          </li><!-- End tab nav item -->

          <li class="nav-item col-2">
            <a class="nav-link" data-bs-toggle="tab" data-bs-target="#tab-5">
              <h4 style="font-size:17px">Mikro EZcam INC</h4>
            </a>
          </li><!-- End tab nav item -->
		  
		  <li class="nav-item col-2">
            <a class="nav-link" data-bs-toggle="tab" data-bs-target="#tab-6">
              <h4 style="font-size:16px">Pfeiffer Vaccum Pvt.Ltd.</h4>
            </a>
          </li><!-- End tab nav item -->
		  
		  
		  
		  <li class="nav-item col-2">
            <a class="nav-link" data-bs-toggle="tab" data-bs-target="#tab-7">
              <h4 style="font-size:17px">Spi/Trump/Laser</h4>
            </a>
          </li><!-- End tab nav item -->

        </ul>

        <div class="tab-content">

          <div class="tab-pane active show" id="tab-1">
            <div class="row">
              <div class="col-lg-6 order-2 order-lg-1 mt-3 mt-lg-0 d-flex flex-column justify-content-center"
                data-aos="fade-up" data-aos-delay="100" style="padding-left:80px">
                <h3>Delta</h3>
                <p class="fst-italic">
                  Plot No. 43, Sector-35, HSIIDC, Gurugram 122001, Haryana, India. <a target="_blank" href="https://www.deltaww.com/">https://www.deltaww.com/ </a>
                </p>
              </div>
              <div class="col-lg-6 order-1 order-lg-2 text-center" data-aos="fade-up" data-aos-delay="200" style="padding-right:80px">
                <img src="<?php echo base_url(); ?>/assets/img/companies/delta.jpg" alt="" class="img-fluid">
              </div>
            </div>
          </div><!-- End tab content item -->

          <div class="tab-pane" id="tab-2">
            <div class="row">
              <div class="col-lg-6 order-2 order-lg-1 mt-3 mt-lg-0 d-flex flex-column justify-content-center"
                data-aos="fade-up" data-aos-delay="100" style="padding-left:80px">
                <h3>YASKAWA</h3>
                <p class="fst-italic">
                  Plot No 426, Phase IV, Udyog Vihar, Gurugram - 122016.<br> <a target="_blank" href="https://www.yaskawa.com/">https://www.yaskawa.com/</a>
                </p>
              </div>
              <div class="col-lg-6 order-1 order-lg-2 text-center" data-aos="fade-up" data-aos-delay="200" style="padding-right:80px">
                <img src="<?php echo base_url(); ?>/assets/img/companies/YASKAWA.jpg" alt="" class="img-fluid">
              </div>
            </div>
          </div><!-- End tab content item -->

          <div class="tab-pane" id="tab-3">
            <div class="row">
              <div class="col-lg-6 order-2 order-lg-1 mt-3 mt-lg-0 d-flex flex-column justify-content-center"
                data-aos="fade-up" data-aos-delay="100" style="padding-left:80px">
                <h3>USON L.P</h3>
                <p class="fst-italic">
                  Leak Testing, 8640 N. Eldridge Parkway Houston,TX77041 USA<br><a target="_blank" href="http://www.uson.com/">www.uson.com </a>
                </p>
              </div>
              <div class="col-lg-6 order-1 order-lg-2 text-center" data-aos="fade-up" data-aos-delay="200" style="padding-right:80px">
                <img src="<?php echo base_url(); ?>/assets/img/companies/USON-new.jpg" alt="" class="img-fluid">
              </div>
            </div>
          </div><!-- End tab content item -->

		  <div class="tab-pane" id="tab-4">
            <div class="row">
              <div class="col-lg-6 order-2 order-lg-1 mt-3 mt-lg-0 d-flex flex-column justify-content-center"
                data-aos="fade-up" data-aos-delay="100" style="padding-left:80px">
                <h3>Takikawa</h3>
                <p class="fst-italic">
                  Laser Micrometer, Koyasu-cho Hachioji-city, Tokyo 192-0904 JAPAN<br> <a target="_blank" href="http://www.takikawa-eng.co.jp/tehp/index_j.html">www.takikawa-eng.co.jp</a>
                </p>
              </div>
              <div class="col-lg-6 order-1 order-lg-2 text-center" data-aos="fade-up" data-aos-delay="200" style="padding-right:80px">
                <img src="<?php echo base_url(); ?>/assets/img/companies/Takikawa-new.jpg" alt="" class="img-fluid">
              </div>
            </div>
          </div><!-- End tab content item -->
		  

          <div class="tab-pane" id="tab-5">
            <div class="row">
              <div class="col-lg-6 order-2 order-lg-1 mt-3 mt-lg-0 d-flex flex-column justify-content-center"
                data-aos="fade-up" data-aos-delay="100" style="padding-left:80px">
                <h3>Mikro EZcam INC</h3>
                <p class="fst-italic">
                  Automotive Camshafts, 431 Kingston Ct., Mount Prospec IL 60056<br> <!--<a target="_blank"
										href="http://www.andrewsproducts.com/">www.andrewsproducts.com</a>-->
                </p>
              </div>
              <div class="col-lg-6 order-1 order-lg-2 text-center" data-aos="fade-up" data-aos-delay="200" style="padding-right:80px">
                <img src="<?php echo base_url(); ?>/assets/img/companies/Mikro-EZcam.jpg" alt="" class="img-fluid">
              </div>
            </div>
          </div><!-- End tab content item -->
		  
		  
		  <div class="tab-pane" id="tab-6">
            <div class="row">
              <div class="col-lg-6 order-2 order-lg-1 mt-3 mt-lg-0 d-flex flex-column justify-content-center"
                data-aos="fade-up" data-aos-delay="100" style="padding-left:80px">
                <h3>Pfeiffer Vaccum Pvt.Ltd.</h3>
                <p class="fst-italic">
                  25/5 Nicholson Road, Tarbund Secunderaba, India-500009.<br> <a target="_blank" href="www.pfeiffer-vacuum.com">www.pfeiffer-vacuum.com/ </a>
                </p>
              </div>
              <div class="col-lg-6 order-1 order-lg-2 text-center" data-aos="fade-up" data-aos-delay="200" style="padding-right:80px">
                <img src="<?php echo base_url(); ?>/assets/img/companies/vacuum.jpg" alt="" class="img-fluid">
              </div>
            </div>
          </div><!-- End tab content item -->
		  
		  <div class="tab-pane" id="tab-7">
            <div class="row">
              <div class="col-lg-6 order-2 order-lg-1 mt-3 mt-lg-0 d-flex flex-column justify-content-center"
                data-aos="fade-up" data-aos-delay="100" style="padding-left:80px">
                <h3>Spi/Trump/Laser</h3>
                <p class="fst-italic">
                  Fiber Laser Technology, 6 Wellington Park, Tallbar Way, Southampton, SO30, 2QU, UK <br> <a target="_blank" href="http://www.spilasers.com/">http://www.spilasers.com/</a>
                </p>
              </div>
              <div class="col-lg-6 order-1 order-lg-2 text-center" data-aos="fade-up" data-aos-delay="200" style="padding-right:80px">
                <img src="<?php echo base_url(); ?>/assets/img/companies/trumpf.jpg" alt="" class="img-fluid">
              </div>
            </div>
          </div><!-- End tab content item -->
		
        </div>

      </div>
    </section><!-- End principle companies Section -->

	
	
	

  </main><!-- End #main -->

  <!-- ======= Footer ======= -->
  <footer id="footer" class="footer">

        <div class="footer-content position-relative">
      <div class="container">
        <div class="row">

          <div class="col-lg-4 col-md-6">
            <div class="footer-info">
              <h3 style="font-size:23px">Mikro Innotech Pvt. Ltd.</h3>
              <p>
				225, Sasewadi, Taluka Bhor,
				Off Pune Bangalore Expressway,<br>
				Pune - 412205<br><br>
                <strong>Phone:</strong> +91-20-20240556 / +91 8308802300<br>
                <strong>Email:</strong> mikroinnotech@gmail.com<br><span class="padding_left" style="padding-left:50px">sales@mikroindia.com</span>
              </p>
              <div class="social-links d-flex mt-3">
				<!--<a href="#" class="d-flex align-items-center justify-content-center"><i class="bi bi-twitter"></i></a>-->
				<a href="https://www.facebook.com/mikroindia" class="d-flex align-items-center justify-content-center"><i class="bi bi-facebook"></i></a>
                <a href="https://instagram.com/mikro_india?igshid=t88sx3gzi8g0" class="d-flex align-items-center justify-content-center"><i class="bi bi-instagram"></i></a>
                <a href="https://www.linkedin.com/company/mikro-innotech-india" class="d-flex align-items-center justify-content-center"><i class="bi bi-linkedin"></i></a>
              </div>
            </div>
          </div><!-- End footer info column-->

          <div class="col-lg-4 col-md-3 footer-links">
            <h4 style="padding-left:70px">Useful Links</h4>
			<div class="row">
				<div class="col-lg-6" >
					<ul>
					  <li><a href="#">Home</a></li>
					  <li><a href="#">About us</a></li>
					  <li><a href="#">Project</a></li>
					  <li><a href="#">Gallery</a></li>
					  <li><a href="#">Principle</a></li>
					</ul>
				</div>
				<div class="col-lg-6">
					<ul>
					  <li><a href="#">Training</a></li>
					  <li><a href="#">Career</a></li>
					  <li><a href="#">Blog</a></li>
					  <li><a href="#">Contact</a></li>
					  <li><a href="#">Site Map</a></li>
					</ul>
				</div>
			</div>
          </div><!-- End footer links column-->
		  
		  <div class="col-lg-4 col-md-3 footer-links">
                   
						  <h4 style="padding-left:100px">Get In Touch</h4>
						  
						<form action="forms/contact.php" method="post" role="form" class="php-email-form">
						  <div class="row gy-4" style="margin-bottom:4%">
							<div class="col-lg-6 form-group">
							  <input type="text" name="name" class="form-control" id="name" placeholder="Your Name" required>
							</div>
							<div class="col-lg-6 form-group">
							  <input type="email" class="form-control" name="email" id="email" placeholder="Your Email" required>
							</div>
						  </div>
						  <div class="form-group" style="margin-bottom:4%">
							<input type="text" class="form-control" name="subject" id="subject" placeholder="Subject" required>
						  </div>
						  <div class="form-group" style="margin-bottom:4%">
							<textarea class="form-control" name="message" rows="4" placeholder="Message" required></textarea>
						  </div>
						  <div class="text-center" ><button type="submit" style="border-radius:10px"><div class="send_text" style="color:#feb900">Send Message</div></button></div>
						</form>
	               </div>
                </div>
        </div>
      </div>
    

    <div class="footer-legal text-center position-relative">
      <div class="container">
        <div class="copyright">
          &copy; Copyright <strong><span>MIKRO 2018</span></strong>. All Rights Reserved
        </div>
        <div class="credits">
          <!-- All the links in the footer should remain intact. -->
          <!-- You can delete the links only if you purchased the pro version. -->
          <!-- Licensing information: https://bootstrapmade.com/license/ -->
          <!-- Purchase the pro version with working PHP/AJAX contact form: https://bootstrapmade.com/upconstruction-bootstrap-construction-website-template/ -->
          Designed & Developed by <a href="https://globalinfocloud.com/"> Global InfoCloud Pvt.Ltd.</a> 
        </div>
      </div>
    </div>

  </footer>
  <!-- End Footer -->

  <a href="#" class="scroll-top d-flex align-items-center justify-content-center"><i
      class="bi bi-arrow-up-short"></i></a>

  <div id="preloader"></div>

  <!-- Vendor JS Files -->
  <script src="<?php echo base_url(); ?>/assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="<?php echo base_url(); ?>/assets/vendor/aos/aos.js"></script>
  <script src="<?php echo base_url(); ?>/assets/vendor/glightbox/js/glightbox.min.js"></script>
  <script src="<?php echo base_url(); ?>/assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
  <script src="<?php echo base_url(); ?>/assets/vendor/swiper/swiper-bundle.min.js"></script>
  <script src="<?php echo base_url(); ?>/assets/vendor/purecounter/purecounter_vanilla.js"></script>
  <script src="<?php echo base_url(); ?>/assets/vendor/php-email-form/validate.js"></script>

  <!-- Template Main JS File -->
  <script src="<?php echo base_url(); ?>/assets/js/main.js"></script>

</body>

</html>