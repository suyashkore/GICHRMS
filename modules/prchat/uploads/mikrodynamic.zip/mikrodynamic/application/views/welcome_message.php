<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Mikro Innotech Pvt. Ltd.</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="assets/img/favicon.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link
    href="https://fonts.googleapis.com/css2?family=Open+Sans:ital,wght@0,300;0,400;0,500;0,600;0,700;1,300;1,400;1,600;1,700&family=Roboto:ital,wght@0,300;0,400;0,500;0,600;0,700;1,300;1,400;1,500;1,600;1,700&family=Work+Sans:ital,wght@0,300;0,400;0,500;0,600;0,700;1,300;1,400;1,500;1,600;1,700&display=swap"
    rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="<?php echo base_url(); ?>/assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="<?php echo base_url(); ?>/assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="<?php echo base_url(); ?>/assets/vendor/fontawesome-free/css/all.min.css" rel="stylesheet">
  <link href="<?php echo base_url(); ?>/assets/vendor/aos/aos.css" rel="stylesheet">
  <link href="<?php echo base_url(); ?>/assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="<?php echo base_url(); ?>/assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="<?php echo base_url(); ?>/assets/css/main.css" rel="stylesheet">

  <!-- =======================================================
  * Template Name: UpConstruction - v1.3.0
  * Template URL: https://bootstrapmade.com/upconstruction-bootstrap-construction-website-template/
  * Author: BootstrapMade.com
  * License: https://bootstrapmade.com/license/
  ======================================================== -->
</head>

<body>

  <!-- ======= Header ======= -->
  <header id="header" class="header d-flex align-items-center">
    <div class="container-fluid container-xl d-flex align-items-center justify-content-between">

      <a href="<?php echo base_url(); ?>" class="logo d-flex align-items-center">
        <!-- Uncomment the line below if you also wish to use an image logo -->
         <img src="<?php echo base_url(); ?>/assets/img/mikrologo2.png" alt=""> 
        <!--<h1>UpConstruction<span>.</span></h1>-->
      </a>

      <i class="mobile-nav-toggle mobile-nav-show bi bi-list"></i>
      <i class="mobile-nav-toggle mobile-nav-hide d-none bi bi-x"></i>
      <nav id="navbar" class="navbar">
        <ul>
          <li><a href="<?php echo base_url(); ?>welcome" class="active">Home</a></li>
          <li class="dropdown"><a href="<?php echo base_url(); ?>welcome/about"><span>About</span> <i
                class="bi bi-chevron-down dropdown-indicator"></i></a>
            <ul>
              <li><a href="<?php echo base_url(); ?>welcome/vision">Vision/Mission</a></li>
              <!--<li class="dropdown"><a href="#"><span>Deep Dropdown</span> <i
                    class="bi bi-chevron-down dropdown-indicator"></i></a>
                <ul>
                  <li><a href="#">Deep Dropdown 1</a></li>
                  <li><a href="#">Deep Dropdown 2</a></li>
                  <li><a href="#">Deep Dropdown 3</a></li>
                  <li><a href="#">Deep Dropdown 4</a></li>
                  <li><a href="#">Deep Dropdown 5</a></li>
                </ul>
              </li>-->
              <li><a href="<?php echo base_url(); ?>welcome/milestone">Milestone</a></li>
              <li><a href="<?php echo base_url(); ?>welcome/leadership">Leadership</a></li>
              <li><a href="#">News</a></li>
            </ul>
          </li>
          <li><a href="<?php echo base_url(); ?>welcome/business">Business</a></li>
          <li><a href="<?php echo base_url(); ?>welcome/technology">Technology</a></li>
		  <li><a href="<?php echo base_url(); ?>welcome/principle">Principle</a></li>
		  <li><a href="<?php echo base_url(); ?>welcome/career">Career</a></li>
          <li><a href="<?php echo base_url(); ?>welcome/blog">Blog</a></li>
          <li><a href="<?php echo base_url(); ?>welcome/contact">Contact</a></li>
        </ul>
      </nav><!-- .navbar -->

    </div>
  </header><!-- End Header -->

  <!-- ======= Hero Section ======= -->
  <section id="hero" class="hero">

    <div class="info d-flex align-items-center">
      <div class="container">
        <div class="row justify-content-center">
          <div class="col-lg-6 text-center">
            <h2 data-aos="fade-down">Welcome to <span>Mikro</span></h2>
            <p data-aos="fade-up">MIKRO delivers world class automation solutions customized to Indian and International markets.</p>
            <!--<a data-aos="fade-up" data-aos-delay="200" href="#get-started" class="btn-get-started">Get Started</a>-->
          </div>
        </div>
      </div>
    </div>

    <div id="hero-carousel" class="carousel slide" data-bs-ride="carousel" data-bs-interval="5000">

      <div class="carousel-item active" style="background-image: url(<?php echo base_url(); ?>/assets/img/hero-carousel/banner-assembly.jpg)">
      </div>
      <div class="carousel-item" style="background-image: url(<?php echo base_url(); ?>/assets/img/hero-carousel/ROBOTIC-welding.png)"></div>
      <div class="carousel-item" style="background-image: url(<?php echo base_url(); ?>/assets/img/hero-carousel/manufacturing-Facility-updated-new.jpg)"></div>
      <div class="carousel-item" style="background-image: url(<?php echo base_url(); ?>/assets/img/hero-carousel/Car-home-banner-updated-new11.jpg)"></div>
      <div class="carousel-item" style="background-image: url(<?php echo base_url(); ?>/assets/img/hero-carousel/Hl-Tl-assemble-line-updated.jpg)"></div>

      <a class="carousel-control-prev" href="#hero-carousel" role="button" data-bs-slide="prev">
        <span class="carousel-control-prev-icon bi bi-chevron-left" aria-hidden="true"></span>
      </a>

      <a class="carousel-control-next" href="#hero-carousel" role="button" data-bs-slide="next">
        <span class="carousel-control-next-icon bi bi-chevron-right" aria-hidden="true"></span>
      </a>

    </div>
	
	<!-- Top Feature Start -->
    <div class="container-fluid top-feature pt-lg-0" style="padding-bottom:0px;margin-top:-50px">
        <div class="container py-5 pt-lg-0" style="">
            <div class="row gx-0">
                <div class="col-lg-4 wow fadeIn" data-wow-delay="0.1s">
                    <div class="bg-white shadow d-flex align-items-center h-100 px-5" style="min-height: 90px;">
                        <div class="d-flex">
                            <div class="flex-shrink-0 btn-lg-square rounded-circle bg-light">
                                <img src="<?php echo base_url(); ?>/assets/img/flag/india.png" alt="" style="width: 67px;">
                            </div>
                            <div class="ps-3">
                                <h4 style="margin-bottom: 0px;line-height: 22px;font-size: 18px;">Mikro</h4>
                                <span>India</span>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 wow fadeIn" data-wow-delay="0.3s">
                    <div class="bg-white shadow d-flex align-items-center h-100 px-5" style="min-height: 90px;">
                        <div class="d-flex">
                            <div class="flex-shrink-0 btn-lg-square rounded-circle bg-light">
                                <img src="<?php echo base_url(); ?>/assets/img/flag/thai.png" alt="" style="width: 67px;">
                            </div>
                            <div class="ps-3">
                                <h4 style="margin-bottom: 0px;line-height: 22px;font-size: 18px;">Mikro</h4>
                                <span>Thai</span>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 wow fadeIn" data-wow-delay="0.5s">
                    <div class="bg-white shadow d-flex align-items-center h-100 px-5" style="min-height: 90px;">
                        <div class="d-flex">
                            <div class="flex-shrink-0 btn-lg-square rounded-circle bg-light">
                                <img src="<?php echo base_url(); ?>/assets/img/flag/usa.jfif" alt="" style="width: 67px;">
                            </div>
                            <div class="ps-3">
                                <h4 style="margin-bottom: 0px;line-height: 22px;font-size: 18px;">Mikro</h4>
                                <span>USA</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Top Feature End -->

  </section><!-- End Hero Section -->

  <main id="main">

    <!-- ======= Get Started Section ======= -->
    <section id="get-started" class="get-started section-bg">
      <div class="container">

        <div class="row justify-content-between gy-4">

          <div class="col-lg-6 d-flex align-items-center" data-aos="fade-up">
            <div class="content">
              <h3>About Us</h3>
              <p>MIKRO was established in 2008 to deliver world class automation solutions customized to Indian/International markets.
              <p>MIKRO has experienced business growth exceeding 50 percent year-over-year through innovation and a focus on customer success. We enjoy the challenge of reshaping industrial challenges and converting them into more productive and unique high-performance systems.We leverage on our in-depth knowledge and proven design & implementation experiences to meet the complex automation systems needs of multinational customers in industries such as healthcare, Automobiles, electrical / electronics and consumer products. We deliver custom solutions and provide consulting grounded in reality.</p>
			  <a href="<?php echo base_url(); ?>welcome/about" class="readmore stretched-link">Read more <i
                  class="bi bi-arrow-right"></i></a>
			</div>
          </div>

          <div class="col-lg-6" data-aos="fade">
		  
                <img src="<?php echo base_url(); ?>/assets/img/Mikro-home-new.jpg" alt="" class="img-fluid" style="height: 350px;">
				
            <!--<form action="forms/quote.php" method="post" class="php-email-form">
              <h3>Get a quote</h3>
              <p>Vel nobis odio laboriosam et hic voluptatem. Inventore vitae totam. Rerum repellendus enim linead sero
                park flows.</p>
              <div class="row gy-3">

                <div class="col-md-12">
                  <input type="text" name="name" class="form-control" placeholder="Name" required>
                </div>

                <div class="col-md-12 ">
                  <input type="email" class="form-control" name="email" placeholder="Email" required>
                </div>

                <div class="col-md-12">
                  <input type="text" class="form-control" name="phone" placeholder="Phone" required>
                </div>

                <div class="col-md-12">
                  <textarea class="form-control" name="message" rows="6" placeholder="Message" required></textarea>
                </div>

                <div class="col-md-12 text-center">
                  <div class="loading">Loading</div>
                  <div class="error-message"></div>
                  <div class="sent-message">Your quote request has been sent successfully. Thank you!</div>

                  <button type="submit">Get a quote</button>
                </div>

              </div>
            </form>-->
          </div><!-- End Quote Form -->

        </div>

      </div>
    </section><!-- End Get Started Section -->
	
	

    <!-- ======= Industries we work for Section ======= -->
    <section id="constructions" class="constructions">
      <div class="container" data-aos="fade-up">

        <div class="section-header">
          <h2>Industries</h2>
          <p>We work for</p>
        </div>

        <div class="row gy-4">

          <div class="col-lg-6" data-aos="fade-up" data-aos-delay="100">
            <div class="card-item">
              <div class="row">
                <div class="col-xl-6">
                  <div class="card-bg" style="background-image: url(<?php echo base_url(); ?>/assets/img/automotive.jpg);"></div>
                </div>
                <div class="col-xl-6 d-flex align-items-center">
                  <div class="card-body">
                    <h4 class="card-title">Automotive</h4>
                    <p>We help the automotive industries to grow by supplying assembly automation robotics & leak testing.</p>
                  </div>
                </div>
              </div>
            </div>
          </div><!-- End Card Item -->

          <div class="col-lg-6" data-aos="fade-up" data-aos-delay="200">
            <div class="card-item">
              <div class="row">
                <div class="col-xl-6">
                  <div class="card-bg" style="background-image: url(<?php echo base_url(); ?>/assets/img/pharma.jpg);"></div>
                </div>
                <div class="col-xl-6 d-flex align-items-center">
                  <div class="card-body">
                    <h4 class="card-title">Pharma</h4>
                    <p>We help Pharma Companies by supplying Leak Testing Solutions & Manufacturing Automation.</p>
                  </div>
                </div>
              </div>
            </div>
          </div><!-- End Card Item -->

          <div class="col-lg-6" data-aos="fade-up" data-aos-delay="300">
            <div class="card-item">
              <div class="row">
                <div class="col-xl-6">
                  <div class="card-bg" style="background-image: url(<?php echo base_url(); ?>/assets/img/medical.jpg);"></div>
                </div>
                <div class="col-xl-6 d-flex align-items-center">
                  <div class="card-body">
                    <h4 class="card-title">Medical</h4>
                    <p>We help Medical Companies by providing Leak Testing solution & provide accurate results for products.</p>
                  </div>
                </div>
              </div>
            </div>
          </div><!-- End Card Item -->

          <div class="col-lg-6" data-aos="fade-up" data-aos-delay="400">
            <div class="card-item">
              <div class="row">
                <div class="col-xl-6">
                  <div class="card-bg" style="background-image: url(<?php echo base_url(); ?>/assets/img/manufacturing.jpg);"></div>
                </div>
                <div class="col-xl-6 d-flex align-items-center">
                  <div class="card-body">
                    <h4 class="card-title">Manifacturing</h4>
                    <p>We help Manufacturing Companies by providing SPM & Assembly Line Automation and Prototype Testing.</p>
                  </div>
                </div>
              </div>
            </div>
          </div><!-- End Card Item -->

        </div>

      </div>
    </section><!-- EndIndustries we work for Section -->

    <!-- ======= facilities Section ======= -->
    <section id="services" class="services section-bg">
      <div class="container" data-aos="fade-up">

        <div class="section-header">
          <h2>Facilities</h2>
          <p>Overview</p>
        </div>

        <div class="row gy-4">

          <div class="col-lg-3 col-md-6" data-aos="fade-up" data-aos-delay="100">
            <div class="service-item  position-relative" style="padding:0px">
              <div class="service-img" style="height:auto;width:100%">
				<img src="<?php echo base_url(); ?>/assets/img/facilities/assembly-shop.jpg" alt="">
			  </div>
			  <div class="facility-title" style="padding-top:10px;text-align:center">
				<h3>CMM</h3>
			  </div>
            </div>
          </div><!-- End Service Item -->

          <div class="col-lg-3 col-md-6" data-aos="fade-up" data-aos-delay="200">
            <div class="service-item position-relative" style="padding:0px">
              <div class="service-img" style="height:auto;width:100%">
				<img src="<?php echo base_url(); ?>/assets/img/facilities/assembly-area.jpg" alt="">
			  </div>
			  <div class="facility-title" style="padding-top:10px;text-align:center">
				<h3>Assembly Area</h3>
			  </div>
			</div>
          </div><!-- End Service Item -->

          <div class="col-lg-3 col-md-6" data-aos="fade-up" data-aos-delay="300">
            <div class="service-item position-relative" style="padding:0px">
				<div class="service-img" style="height:auto;width:100%">
				<img src="<?php echo base_url(); ?>/assets/img/facilities/FACILITY-OVERVIEW-new.jpg" alt="">
			  </div>
			  <div class="facility-title" style="padding-top:10px;text-align:center">
				<h3>Conference</h3>
			  </div>
            </div>
          </div><!-- End Service Item -->

          <div class="col-lg-3 col-md-6" data-aos="fade-up" data-aos-delay="400">
            <div class="service-item position-relative" style="padding:0px">
				<div class="service-img" style="height:auto;width:100%">
				<img src="<?php echo base_url(); ?>/assets/img/facilities/technology-center.jpg" alt="">
			  </div>
			  <div class="facility-title" style="padding-top:10px;text-align:center">
				<h3>Technology Center</h3>
			  </div>
            </div>
          </div><!-- End Service Item -->

          <div class="col-lg-3 col-md-6" data-aos="fade-up" data-aos-delay="500">
            <div class="service-item position-relative" style="padding:0px">
				<div class="service-img" style="height:auto;width:100%">
				<img src="<?php echo base_url(); ?>/assets/img/facilities/reception.jpg" alt="">
			  </div>
			  <div class="facility-title" style="padding-top:10px;text-align:center">
				<h3>Reception</h3>
			  </div>
            </div>
          </div><!-- End Service Item -->

          <div class="col-lg-3 col-md-6" data-aos="fade-up" data-aos-delay="600">
            <div class="service-item position-relative" style="padding:0px">
				<div class="service-img" style="height:auto;width:100%">
				<img src="<?php echo base_url(); ?>/assets/img/facilities/Design-dept.jpg" alt="">
			  </div>
			  <div class="facility-title" style="padding-top:10px;text-align:center">
				<h3>Design Department</h3>
			  </div>
            </div>
          </div><!-- End Service Item -->
		  
		  <div class="col-lg-3 col-md-6" data-aos="fade-up" data-aos-delay="600">
            <div class="service-item position-relative" style="padding:0px">
				<div class="service-img" style="height:auto;width:100%">
				<img src="<?php echo base_url(); ?>/assets/img/facilities/metrology-lab.png" alt="">
			  </div>
			  <div class="facility-title" style="padding-top:10px;text-align:center">
				<h3>Standard Room</h3>
			  </div>
            </div>
         </div><!-- End Service Item -->
		 
		  <div class="col-lg-3 col-md-6" data-aos="fade-up" data-aos-delay="600">
            <div class="service-item position-relative" style="padding:0px">
				<div class="service-img" style="height:auto;width:100%">
				<img src="<?php echo base_url(); ?>/assets/img/facilities/machine-shop-new.jpg" alt="">
			  </div>
			  <div class="facility-title" style="padding-top:10px;text-align:center">
				<h3>Machine Shop</h3>
			  </div>
            </div>
          </div><!-- End Service Item -->

        </div>

      </div>
    </section><!-- End facilities Section -->

    <!-- ======= Alt Services Section ======= -->
    <!--<section id="alt-services" class="alt-services">
      <div class="container" data-aos="fade-up">

        <div class="row justify-content-around gy-4">
          <div class="col-lg-6 img-bg" style="background-image: url(<?php echo base_url(); ?>/assets/img/alt-services.jpg);" data-aos="zoom-in"
            data-aos-delay="100"></div>

          <div class="col-lg-5 d-flex flex-column justify-content-center">
            <h3>Enim quis est voluptatibus aliquid consequatur fugiat</h3>
            <p>Esse voluptas cumque vel exercitationem. Reiciendis est hic accusamus. Non ipsam et sed minima temporibus
              laudantium. Soluta voluptate sed facere corporis dolores excepturi</p>

            <div class="icon-box d-flex position-relative" data-aos="fade-up" data-aos-delay="100">
              <i class="bi bi-easel flex-shrink-0"></i>
              <div>
                <h4><a href="" class="stretched-link">Lorem Ipsum</a></h4>
                <p>Voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate
                  non provident</p>
              </div>
            </div><!-- End Icon Box -->

            <!--<div class="icon-box d-flex position-relative" data-aos="fade-up" data-aos-delay="200">
              <i class="bi bi-patch-check flex-shrink-0"></i>
              <div>
                <h4><a href="" class="stretched-link">Nemo Enim</a></h4>
                <p>At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum
                  deleniti atque</p>
              </div>
            </div><!-- End Icon Box -->

            <!--<div class="icon-box d-flex position-relative" data-aos="fade-up" data-aos-delay="300">
              <i class="bi bi-brightness-high flex-shrink-0"></i>
              <div>
                <h4><a href="" class="stretched-link">Dine Pad</a></h4>
                <p>Explicabo est voluptatum asperiores consequatur magnam. Et veritatis odit. Sunt aut deserunt minus
                  aut eligendi omnis</p>
              </div>
            </div><!-- End Icon Box -->

            <!--<div class="icon-box d-flex position-relative" data-aos="fade-up" data-aos-delay="400">
              <i class="bi bi-brightness-high flex-shrink-0"></i>
              <div>
                <h4><a href="" class="stretched-link">Tride clov</a></h4>
                <p>Est voluptatem labore deleniti quis a delectus et. Saepe dolorem libero sit non aspernatur odit amet.
                  Et eligendi</p>
              </div>
            </div><!-- End Icon Box -->

          <!--</div>
        </div>

      </div>
    </section><!-- End Alt Services Section -->

    <!-- ======= principle companies Section ======= -->
    <section id="features" class="features section-bg">
      <div class="container" data-aos="fade-up">

		<div class="section-header">
          <h2>Principle Companies</h2>
        </div>

        <ul class="nav nav-tabs row  g-2 d-flex">

          <li class="nav-item col-2">
            <a class="nav-link active show" data-bs-toggle="tab" data-bs-target="#tab-1">
              <h4>Delta</h4>
            </a>
          </li><!-- End tab nav item -->

		  <li class="nav-item col-1">
            <a class="nav-link" data-bs-toggle="tab" data-bs-target="#tab-2">
              <h4 style="font-size:17px">YASKAWA</h4>
            </a>
			</li><!-- End tab nav item -->

          <li class="nav-item col-2">
            <a class="nav-link" data-bs-toggle="tab" data-bs-target="#tab-3">
              <h4 style="font-size:17px">USON L.P</h4>
            </a>
          </li><!-- End tab nav item -->

		 <li class="nav-item col-1">
            <a class="nav-link" data-bs-toggle="tab" data-bs-target="#tab-4">
              <h4 style="font-size:17px">Takikawa</h4>
            </a>
          </li><!-- End tab nav item -->

          <li class="nav-item col-2">
            <a class="nav-link" data-bs-toggle="tab" data-bs-target="#tab-5">
              <h4 style="font-size:17px">Mikro EZcam INC</h4>
            </a>
          </li><!-- End tab nav item -->
		  
		  <li class="nav-item col-2">
            <a class="nav-link" data-bs-toggle="tab" data-bs-target="#tab-6">
              <h4 style="font-size:16px">Pfeiffer Vaccum Pvt.Ltd.</h4>
            </a>
          </li><!-- End tab nav item -->
		  
		  
		  
		  <li class="nav-item col-2">
            <a class="nav-link" data-bs-toggle="tab" data-bs-target="#tab-7">
              <h4 style="font-size:17px">Spi/Trump/Laser</h4>
            </a>
          </li><!-- End tab nav item -->

        </ul>

        <div class="tab-content">

          <div class="tab-pane active show" id="tab-1">
            <div class="row">
              <div class="col-lg-6 order-2 order-lg-1 mt-3 mt-lg-0 d-flex flex-column justify-content-center"
                data-aos="fade-up" data-aos-delay="100" style="padding-left:80px">
                <h3>Delta</h3>
                <p class="fst-italic">
                  Plot No. 43, Sector-35, HSIIDC, Gurugram 122001, Haryana, India. <a target="_blank" href="https://www.deltaww.com/">https://www.deltaww.com/ </a>
                </p>
              </div>
              <div class="col-lg-6 order-1 order-lg-2 text-center" data-aos="fade-up" data-aos-delay="200" style="padding-right:80px">
                <img src="<?php echo base_url(); ?>/assets/img/companies/delta.jpg" alt="" class="img-fluid">
              </div>
            </div>
          </div><!-- End tab content item -->

          <div class="tab-pane" id="tab-2">
            <div class="row">
              <div class="col-lg-6 order-2 order-lg-1 mt-3 mt-lg-0 d-flex flex-column justify-content-center"
                data-aos="fade-up" data-aos-delay="100" style="padding-left:80px">
                <h3>YASKAWA</h3>
                <p class="fst-italic">
                  Plot No 426, Phase IV, Udyog Vihar, Gurugram - 122016.<br> <a target="_blank" href="https://www.yaskawa.com/">https://www.yaskawa.com/</a>
                </p>
              </div>
              <div class="col-lg-6 order-1 order-lg-2 text-center" data-aos="fade-up" data-aos-delay="200" style="padding-right:80px">
                <img src="<?php echo base_url(); ?>/assets/img/companies/YASKAWA.jpg" alt="" class="img-fluid">
              </div>
            </div>
          </div><!-- End tab content item -->

          <div class="tab-pane" id="tab-3">
            <div class="row">
              <div class="col-lg-6 order-2 order-lg-1 mt-3 mt-lg-0 d-flex flex-column justify-content-center"
                data-aos="fade-up" data-aos-delay="100" style="padding-left:80px">
                <h3>USON L.P</h3>
                <p class="fst-italic">
                  Leak Testing, 8640 N. Eldridge Parkway Houston,TX77041 USA<br><a target="_blank" href="http://www.uson.com/">www.uson.com </a>
                </p>
              </div>
              <div class="col-lg-6 order-1 order-lg-2 text-center" data-aos="fade-up" data-aos-delay="200" style="padding-right:80px">
                <img src="<?php echo base_url(); ?>/assets/img/companies/USON-new.jpg" alt="" class="img-fluid">
              </div>
            </div>
          </div><!-- End tab content item -->

		  <div class="tab-pane" id="tab-4">
            <div class="row">
              <div class="col-lg-6 order-2 order-lg-1 mt-3 mt-lg-0 d-flex flex-column justify-content-center"
                data-aos="fade-up" data-aos-delay="100" style="padding-left:80px">
                <h3>Takikawa</h3>
                <p class="fst-italic">
                  Laser Micrometer, Koyasu-cho Hachioji-city, Tokyo 192-0904 JAPAN<br> <a target="_blank" href="http://www.takikawa-eng.co.jp/tehp/index_j.html">www.takikawa-eng.co.jp</a>
                </p>
              </div>
              <div class="col-lg-6 order-1 order-lg-2 text-center" data-aos="fade-up" data-aos-delay="200" style="padding-right:80px">
                <img src="<?php echo base_url(); ?>/assets/img/companies/Takikawa-new.jpg" alt="" class="img-fluid">
              </div>
            </div>
          </div><!-- End tab content item -->
		  

          <div class="tab-pane" id="tab-5">
            <div class="row">
              <div class="col-lg-6 order-2 order-lg-1 mt-3 mt-lg-0 d-flex flex-column justify-content-center"
                data-aos="fade-up" data-aos-delay="100" style="padding-left:80px">
                <h3>Mikro EZcam INC</h3>
                <p class="fst-italic">
                  Automotive Camshafts, 431 Kingston Ct., Mount Prospec IL 60056<br> <!--<a target="_blank"
										href="http://www.andrewsproducts.com/">www.andrewsproducts.com</a>-->
                </p>
              </div>
              <div class="col-lg-6 order-1 order-lg-2 text-center" data-aos="fade-up" data-aos-delay="200" style="padding-right:80px">
                <img src="<?php echo base_url(); ?>/assets/img/companies/Mikro-EZcam.jpg" alt="" class="img-fluid">
              </div>
            </div>
          </div><!-- End tab content item -->
		  
		  
		  <div class="tab-pane" id="tab-6">
            <div class="row">
              <div class="col-lg-6 order-2 order-lg-1 mt-3 mt-lg-0 d-flex flex-column justify-content-center"
                data-aos="fade-up" data-aos-delay="100" style="padding-left:80px">
                <h3>Pfeiffer Vaccum Pvt.Ltd.</h3>
                <p class="fst-italic">
                  25/5 Nicholson Road, Tarbund Secunderaba, India-500009.<br> <a target="_blank" href="www.pfeiffer-vacuum.com">www.pfeiffer-vacuum.com/ </a>
                </p>
              </div>
              <div class="col-lg-6 order-1 order-lg-2 text-center" data-aos="fade-up" data-aos-delay="200" style="padding-right:80px">
                <img src="<?php echo base_url(); ?>/assets/img/companies/vacuum.jpg" alt="" class="img-fluid">
              </div>
            </div>
          </div><!-- End tab content item -->
		  
		  <div class="tab-pane" id="tab-7">
            <div class="row">
              <div class="col-lg-6 order-2 order-lg-1 mt-3 mt-lg-0 d-flex flex-column justify-content-center"
                data-aos="fade-up" data-aos-delay="100" style="padding-left:80px">
                <h3>Spi/Trump/Laser</h3>
                <p class="fst-italic">
                  Fiber Laser Technology, 6 Wellington Park, Tallbar Way, Southampton, SO30, 2QU, UK <br> <a target="_blank" href="http://www.spilasers.com/">http://www.spilasers.com/</a>
                </p>
              </div>
              <div class="col-lg-6 order-1 order-lg-2 text-center" data-aos="fade-up" data-aos-delay="200" style="padding-right:80px">
                <img src="<?php echo base_url(); ?>/assets/img/companies/trumpf.jpg" alt="" class="img-fluid">
              </div>
            </div>
          </div><!-- End tab content item -->
		
        </div>

      </div>
    </section><!-- End principle companies Section -->

    <!-- ======= Our Projects Section ======= -->
    <section id="projects" class="projects">
      <div class="container" data-aos="fade-up">

        <div class="section-header">
          <h2>Product</h2>
          <p></p>
        </div>

        <div class="portfolio-isotope" data-portfolio-filter="*" data-portfolio-layout="masonry"
          data-portfolio-sort="original-order">

          <ul class="portfolio-flters" data-aos="fade-up" data-aos-delay="100">
            <li data-filter="*" class="filter-active">All</li>
            <li data-filter=".filter-remodeling">Remodeling</li>
            <li data-filter=".filter-construction">Construction</li>
            <li data-filter=".filter-repairs">Repairs</li>
            <li data-filter=".filter-design">Design</li>
          </ul><!-- End Projects Filters -->

          <div class="row gy-4 portfolio-container" data-aos="fade-up" data-aos-delay="200">

            <div class="col-lg-4 col-md-6 portfolio-item filter-remodeling">
              <div class="portfolio-content h-100">
                <img src="<?php echo base_url(); ?>/assets/img/product/dummy1.jpg" class="img-fluid" alt="">
                <div class="portfolio-info">
                  <h4>Laser,Vision Multi Gaging System</h4>
                  <p>Unparalleled performance of the gauges with accurate measurements and long operational life along with cutting edge technology.</p>
                  <a href="<?php echo base_url(); ?>/assets/img/product/dummy1.jpg" title="Remodeling 1"
                    data-gallery="portfolio-gallery-remodeling" class="glightbox preview-link"><i
                      class="bi bi-zoom-in"></i></a>
                  <a href="<?php echo base_url(); ?>welcome/projectDetails" title="More Details" class="details-link"><i
                      class="bi bi-link-45deg"></i></a>
                </div>
              </div>
            </div><!-- End Projects Item -->

            <div class="col-lg-4 col-md-6 portfolio-item filter-construction">
              <div class="portfolio-content h-100">
                <img src="<?php echo base_url(); ?>/assets/img/product/dummy1.jpg" class="img-fluid" alt="">
                <div class="portfolio-info">
                  <h4>Assembly Line Automation &amp; SPM'S</h4>
                  <p>Our assembly line automation configurations and special purpose machines streamline various phases of production and assembly.</p>
                  <a href="<?php echo base_url(); ?>/assets/img/product/dummy1.jpg" title="Construction 1"
                    data-gallery="portfolio-gallery-construction" class="glightbox preview-link"><i
                      class="bi bi-zoom-in"></i></a>
                  <a href="<?php echo base_url(); ?>welcome/projectDetails" title="More Details" class="details-link"><i
                      class="bi bi-link-45deg"></i></a>
                </div>
              </div>
            </div><!-- End Projects Item -->

            <div class="col-lg-4 col-md-6 portfolio-item filter-repairs">
              <div class="portfolio-content h-100">
                <img src="<?php echo base_url(); ?>/assets/img/product/dummy1.jpg" class="img-fluid" alt="">
                <div class="portfolio-info">
                  <h4>Robotics & Automation</h4>
                  <p>On 26th Jan 2021, as part of Atmanirbhar Bharat Initiative, Mikro became First Private Sector Company In India  to offer " State of Art Technology Center on the Republic day 2021.</p>
                  <a href="<?php echo base_url(); ?>/assets/img/product/dummy1.jpg" title="Repairs 1" data-gallery="portfolio-gallery-repairs"
                    class="glightbox preview-link"><i class="bi bi-zoom-in"></i></a>
                  <a href="<?php echo base_url(); ?>welcome/projectDetails" title="More Details" class="details-link"><i
                      class="bi bi-link-45deg"></i></a>
                </div>
              </div>
            </div><!-- End Projects Item -->

            <div class="col-lg-4 col-md-6 portfolio-item filter-design">
              <div class="portfolio-content h-100">
                <img src="<?php echo base_url(); ?>/assets/img/product/dummy1.jpg" class="img-fluid" alt="">
                <div class="portfolio-info">
                  <h4>Leak & Functinal Testing Machines</h4>
                  <p>Effective and thorough leak testing of the machines. These are budget-friendly and highly accurate leak testers.</p>
                  <a href="<?php echo base_url(); ?>/assets/img/product/dummy1.jpg" title="Repairs 1" data-gallery="portfolio-gallery-book"
                    class="glightbox preview-link"><i class="bi bi-zoom-in"></i></a>
                  <a href="<?php echo base_url(); ?>welcome/projectDetails" title="More Details" class="details-link"><i
                      class="bi bi-link-45deg"></i></a>
                </div>
              </div>
            </div><!-- End Projects Item -->

            <div class="col-lg-4 col-md-6 portfolio-item filter-remodeling">
              <div class="portfolio-content h-100">
                <img src="<?php echo base_url(); ?>/assets/img/product/dummy1.jpg" class="img-fluid" alt="">
                <div class="portfolio-info">
                  <h4>Eddy Current Hardness & Crack Testers </h4>
                  <p>Prompt measurement with or without selection and valid voltage indicator provide precise current testing.</p>
                  <a href="<?php echo base_url(); ?>/assets/img/product/dummy1.jpg" title="Remodeling 2"
                    data-gallery="portfolio-gallery-remodeling" class="glightbox preview-link"><i
                      class="bi bi-zoom-in"></i></a>
                  <a href="<?php echo base_url(); ?>welcome/projectDetails" title="More Details" class="details-link"><i
                      class="bi bi-link-45deg"></i></a>
                </div>
              </div>
            </div><!-- End Projects Item -->

            <div class="col-lg-4 col-md-6 portfolio-item filter-construction">
              <div class="portfolio-content h-100">
                <img src="<?php echo base_url(); ?>/assets/img/product/dummy1.jpg" class="img-fluid" alt="">
                <div class="portfolio-info">
                  <h4>Camshaft & Crankshaft Testers</h4>
                  <p>Complete understanding of cam specifications and their effects will enable you to choose the best cam for boosting your engine performance.</p>
                  <a href="<?php echo base_url(); ?>/assets/img/product/dummy1.jpg" title="Construction 2"
                    data-gallery="portfolio-gallery-construction" class="glightbox preview-link"><i
                      class="bi bi-zoom-in"></i></a>
                  <a href="<?php echo base_url(); ?>welcome/projectDetails" title="More Details" class="details-link"><i
                      class="bi bi-link-45deg"></i></a>
                </div>
              </div>
            </div><!-- End Projects Item -->

            <!--<div class="col-lg-4 col-md-6 portfolio-item filter-repairs">
              <div class="portfolio-content h-100">
                <img src="<?php echo base_url(); ?>/assets/img/projects/repairs-2.jpg" class="img-fluid" alt="">
                <div class="portfolio-info">
                  <h4>Repairs 2</h4>
                  <p>Lorem ipsum, dolor sit amet consectetur</p>
                  <a href="<?php echo base_url(); ?>/assets/img/projects/repairs-2.jpg" title="Repairs 2" data-gallery="portfolio-gallery-repairs"
                    class="glightbox preview-link"><i class="bi bi-zoom-in"></i></a>
                  <a href="<?php echo base_url(); ?>welcome/projectDetails" title="More Details" class="details-link"><i
                      class="bi bi-link-45deg"></i></a>
                </div>
              </div>
            </div><!-- End Projects Item -->

            <!--<div class="col-lg-4 col-md-6 portfolio-item filter-design">
              <div class="portfolio-content h-100">
                <img src="<?php echo base_url(); ?>/assets/img/projects/design-2.jpg" class="img-fluid" alt="">
                <div class="portfolio-info">
                  <h4>Design 2</h4>
                  <p>Lorem ipsum, dolor sit amet consectetur</p>
                  <a href="<?php echo base_url(); ?>/assets/img/projects/design-2.jpg" title="Repairs 2" data-gallery="portfolio-gallery-book"
                    class="glightbox preview-link"><i class="bi bi-zoom-in"></i></a>
                  <a href="<?php echo base_url(); ?>welcome/projectDetails" title="More Details" class="details-link"><i
                      class="bi bi-link-45deg"></i></a>
                </div>
              </div>
            </div><!-- End Projects Item -->

            <!--<div class="col-lg-4 col-md-6 portfolio-item filter-remodeling">
              <div class="portfolio-content h-100">
                <img src="<?php echo base_url(); ?>/assets/img/projects/remodeling-3.jpg" class="img-fluid" alt="">
                <div class="portfolio-info">
                  <h4>Remodeling 3</h4>
                  <p>Lorem ipsum, dolor sit amet consectetur</p>
                  <a href="<?php echo base_url(); ?>/assets/img/projects/remodeling-3.jpg" title="Remodeling 3"
                    data-gallery="portfolio-gallery-remodeling" class="glightbox preview-link"><i
                      class="bi bi-zoom-in"></i></a>
                  <a href="<?php echo base_url(); ?>welcome/projectDetails" title="More Details" class="details-link"><i
                      class="bi bi-link-45deg"></i></a>
                </div>
              </div>
            </div><!-- End Projects Item -->

            <!--<div class="col-lg-4 col-md-6 portfolio-item filter-construction">
              <div class="portfolio-content h-100">
                <img src="<?php echo base_url(); ?>/assets/img/projects/construction-3.jpg" class="img-fluid" alt="">
                <div class="portfolio-info">
                  <h4>Construction 3</h4>
                  <p>Lorem ipsum, dolor sit amet consectetur</p>
                  <a href="<?php echo base_url(); ?>/assets/img/projects/construction-3.jpg" title="Construction 3"
                    data-gallery="portfolio-gallery-construction" class="glightbox preview-link"><i
                      class="bi bi-zoom-in"></i></a>
                  <a href="<?php echo base_url(); ?>welcome/projectDetails" title="More Details" class="details-link"><i
                      class="bi bi-link-45deg"></i></a>
                </div>
              </div>
            </div><!-- End Projects Item -->

            <!--<div class="col-lg-4 col-md-6 portfolio-item filter-repairs">
              <div class="portfolio-content h-100">
                <img src="<?php echo base_url(); ?>/assets/img/projects/repairs-3.jpg" class="img-fluid" alt="">
                <div class="portfolio-info">
                  <h4>Repairs 3</h4>
                  <p>Lorem ipsum, dolor sit amet consectetur</p>
                  <a href="<?php echo base_url(); ?>/assets/img/projects/repairs-3.jpg" title="Repairs 2" data-gallery="portfolio-gallery-repairs"
                    class="glightbox preview-link"><i class="bi bi-zoom-in"></i></a>
                  <a href="<?php echo base_url(); ?>welcome/projectDetails" title="More Details" class="details-link"><i
                      class="bi bi-link-45deg"></i></a>
                </div>
              </div>
            </div><!-- End Projects Item -->

            <!--<div class="col-lg-4 col-md-6 portfolio-item filter-design">
              <div class="portfolio-content h-100">
                <img src="<?php echo base_url(); ?>/assets/img/projects/design-3.jpg" class="img-fluid" alt="">
                <div class="portfolio-info">
                  <h4>Design 3</h4>
                  <p>Lorem ipsum, dolor sit amet consectetur</p>
                  <a href="<?php echo base_url(); ?>/assets/img/projects/design-3.jpg" title="Repairs 3" data-gallery="portfolio-gallery-book"
                    class="glightbox preview-link"><i class="bi bi-zoom-in"></i></a>
                  <a href="<?php echo base_url(); ?>welcome/projectDetails" title="More Details" class="details-link"><i
                      class="bi bi-link-45deg"></i></a>
                </div>
              </div>
            </div><!-- End Projects Item -->

          </div><!-- End Projects Container -->

        </div>

      </div>
    </section><!-- End Our Projects Section -->


    <!-- ======= Testimonials Section ======= -->
    <section id="testimonials" class="testimonials section-bg">
      <div class="container" data-aos="fade-up">

        <div class="section-header">
          <h2>Testimonials</h2>
          <p></p>
        </div>

        <div class="slides-2 swiper">
          <div class="swiper-wrapper">

            <div class="swiper-slide">
              <div class="testimonial-wrap">
                <div class="testimonial-item">
                  <img src="<?php echo base_url(); ?>/assets/img/testimonials/Rajgopal.jpeg" class="testimonial-img" alt="">
                  <h3>K. Rajgopal</h3>
                  <h4>DGM - Tata Motors CVBU Plant, Pune</h4>
                  <div class="stars">
                    <i class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i><i
                      class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i>
                  </div>
                  <p>
                    <i class="bi bi-quote quote-icon-left"></i>
                    "At our TATA motors, we required a Leak tester for Cyl block with through feed and automated features. Mikro Innotech was suggested since they had worked with us for a different plant. We are satisfied with the solution provided including all end users and connected stakeholders. We look forward to work with them for upcoming projects."
                    <i class="bi bi-quote quote-icon-right"></i>
                  </p>
                </div>
              </div>
            </div><!-- End testimonial item -->

            <div class="swiper-slide">
              <div class="testimonial-wrap">
                <div class="testimonial-item">
                  <img src="<?php echo base_url(); ?>/assets/img/testimonials/Ashwani-Vohra.jpg" class="testimonial-img" alt="">
                  <h3>Ashwani Vohra</h3>
                  <h4>Deputy General Manager, Hero Motocorp</h4>
                  <div class="stars">
                    <i class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i><i
                      class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i>
                  </div>
                  <p>
                    <i class="bi bi-quote quote-icon-left"></i>
                    "Mikro Innotech Pvt. Ltd has been a great supplier to our company. We had purchased a Leak testing machine from them last year. The machine's quality and workmanship are remarkable. After receiving the equipment, they have done a good job keeping up with our service needs and have been very responsive to all our inquires."
                    <i class="bi bi-quote quote-icon-right"></i>
                  </p>
                </div>
              </div>
            </div><!-- End testimonial item -->

            <div class="swiper-slide">
              <div class="testimonial-wrap">
                <div class="testimonial-item">
                  <img src="<?php echo base_url(); ?>/assets/img/testimonials/M.R.Sugumaran.jpg" class="testimonial-img" alt="">
                  <h3>Mr.M.R.Sugumaran</h3>
                  <h4>Manager, Production Engineering</h4>
                  <div class="stars">
                    <i class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i><i
                      class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i>
                  </div>
                  <p>
                    <i class="bi bi-quote quote-icon-left"></i>
                    "We required leak testers for our TVS Hosur &amp; Mysore plant. We found a superior range of all essential equipments for leak testing with Mikro Innotech India Pvt Ltd. I must say Mikro is a reliabale brand"
                    <i class="bi bi-quote quote-icon-right"></i>
                  </p>
                </div>
              </div>
            </div><!-- End testimonial item -->

            <div class="swiper-slide">
              <div class="testimonial-wrap">
                <div class="testimonial-item">
                  <img src="<?php echo base_url(); ?>/assets/img/testimonials/N.Y.Apte.jpg" class="testimonial-img" alt="">
                  <h3>N.Y.Apte</h3>
                  <h4></h4>
                  <div class="stars">
                    <i class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i><i
                      class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i>
                  </div>
                  <p>
                    <i class="bi bi-quote quote-icon-left"></i>
                    "We at Fleetgaurd industry are involved in filtration systems. We are amazed at the efficiency of the Mikro Innotech assembly machines and Electrical testing equipment. We will look out to Mikro Innotech when we expand our business."
                    <i class="bi bi-quote quote-icon-right"></i>
                  </p>
                </div>
              </div>
            </div><!-- End testimonial item -->

            <div class="swiper-slide">
              <div class="testimonial-wrap">
                <div class="testimonial-item">
                  <img src="<?php echo base_url(); ?>/assets/img/testimonials/Girish-Shetes.jpg" class="testimonial-img" alt="">
                  <h3>Girish Shete</h3>
                  <h4>Plant Head, Varroc Plant - VI & VPPL-I</h4>
                  <div class="stars">
                    <i class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i><i
                      class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i>
                  </div>
                  <p>
                    <i class="bi bi-quote quote-icon-left"></i>
                    "Mikro Innotech means Innovation, passion & dedication"
                    <i class="bi bi-quote quote-icon-right"></i>
                  </p>
                </div>
              </div>
            </div><!-- End testimonial item -->

          </div>
          <div class="swiper-pagination"></div>
        </div>

      </div>
    </section><!-- End Testimonials Section -->
	
	<!-- ======= our client Section ======= -->
    <section id="services" class="services section-bg">
      <div class="container" data-aos="fade-up">

        <div class="section-header">
          <h2>Our clients</h2>
          <p></p>
        </div>

        <div class="row gy-4">

          <div class="col-lg-2 col-md-6" data-aos="fade-up" data-aos-delay="100">
            <div class="service-item  position-relative" style="padding:0px">
              <div class="service-img" style="height:auto;width:100%">
				<img src="<?php echo base_url(); ?>/assets/img/clients/logo-1.png" alt="">
			  </div>
			  
            </div>
          </div><!-- End Service Item -->

          <div class="col-lg-2 col-md-6" data-aos="fade-up" data-aos-delay="200">
            <div class="service-item position-relative" style="padding:0px">
              <div class="service-img" style="height:auto;width:100%">
				<img src="<?php echo base_url(); ?>/assets/img/clients/logo-2.png" alt="">
			  </div>
			  
			</div>
          </div><!-- End Service Item -->

          <div class="col-lg-2 col-md-6" data-aos="fade-up" data-aos-delay="300">
            <div class="service-item position-relative" style="padding:0px">
				<div class="service-img" style="height:auto;width:100%">
				<img src="<?php echo base_url(); ?>/assets/img/clients/logo-3.png" alt="">
			  </div>
			  
            </div>
          </div><!-- End Service Item -->

          <div class="col-lg-2 col-md-6" data-aos="fade-up" data-aos-delay="400">
            <div class="service-item position-relative" style="padding:0px">
				<div class="service-img" style="height:auto;width:100%">
				<img src="<?php echo base_url(); ?>/assets/img/clients/logo-4.png" alt="">
			  </div>
			  
            </div>
          </div><!-- End Service Item -->

          <div class="col-lg-2 col-md-6" data-aos="fade-up" data-aos-delay="500">
            <div class="service-item position-relative" style="padding:0px">
				<div class="service-img" style="height:auto;width:100%">
				<img src="<?php echo base_url(); ?>/assets/img/clients/logo-6.png" alt="">
			  </div>
			  
            </div>
          </div><!-- End Service Item -->

          <div class="col-lg-2 col-md-6" data-aos="fade-up" data-aos-delay="600">
            <div class="service-item position-relative" style="padding:0px">
				<div class="service-img" style="height:auto;width:100%">
				<img src="<?php echo base_url(); ?>/assets/img/clients/logo-8.png" alt="">
			  </div>
			  
            </div>
          </div><!-- End Service Item -->
		  
		  <div class="col-lg-2 col-md-6" data-aos="fade-up" data-aos-delay="600">
            <div class="service-item position-relative" style="padding:0px">
				<div class="service-img" style="height:auto;width:100%">
				<img src="<?php echo base_url(); ?>/assets/img/clients/logo-9.png" alt="">
			  </div>
			  
            </div>
         </div><!-- End Service Item -->
		 
		  <div class="col-lg-2 col-md-6" data-aos="fade-up" data-aos-delay="600">
            <div class="service-item position-relative" style="padding:0px">
				<div class="service-img" style="height:auto;width:100%">
				<img src="<?php echo base_url(); ?>/assets/img/clients/logo-10.png" alt="">
			  </div>
			  
            </div>
          </div><!-- End Service Item -->
		  
		  <div class="col-lg-2 col-md-6" data-aos="fade-up" data-aos-delay="600">
            <div class="service-item position-relative" style="padding:0px">
				<div class="service-img" style="height:auto;width:100%">
				<img src="<?php echo base_url(); ?>/assets/img/clients/logo-13.png" alt="">
			  </div>
			  
            </div>
          </div><!-- End Service Item -->
		  
		  <div class="col-lg-2 col-md-6" data-aos="fade-up" data-aos-delay="600">
            <div class="service-item position-relative" style="padding:0px">
				<div class="service-img" style="height:auto;width:100%">
				<img src="<?php echo base_url(); ?>/assets/img/clients/logo-14.png" alt="">
			  </div>
			  
            </div>
          </div><!-- End Service Item -->
		  
		  <div class="col-lg-2 col-md-6" data-aos="fade-up" data-aos-delay="600">
            <div class="service-item position-relative" style="padding:0px">
				<div class="service-img" style="height:auto;width:100%">
				<img src="<?php echo base_url(); ?>/assets/img/clients/logo-15.png" alt="">
			  </div>
			  
            </div>
          </div><!-- End Service Item -->
		  
		  <div class="col-lg-2 col-md-6" data-aos="fade-up" data-aos-delay="600">
            <div class="service-item position-relative" style="padding:0px">
				<div class="service-img" style="height:auto;width:100%">
				<img src="<?php echo base_url(); ?>/assets/img/clients/logo-16.png" alt="">
			  </div>
			  
            </div>
          </div><!-- End Service Item -->
		  
		  <div class="col-lg-2 col-md-6" data-aos="fade-up" data-aos-delay="600">
            <div class="service-item position-relative" style="padding:0px">
				<div class="service-img" style="height:auto;width:100%">
				<img src="<?php echo base_url(); ?>/assets/img/clients/Honda1.jpg" alt="">
			  </div>
			  
            </div>
          </div><!-- End Service Item -->
		  
		  <div class="col-lg-2 col-md-6" data-aos="fade-up" data-aos-delay="600">
            <div class="service-item position-relative" style="padding:0px">
				<div class="service-img" style="height:auto;width:100%">
				<img src="<?php echo base_url(); ?>/assets/img/clients/fleetguard.jpg" alt="">
			  </div>
			  
            </div>
          </div><!-- End Service Item -->
		  
		  <div class="col-lg-2 col-md-6" data-aos="fade-up" data-aos-delay="600">
            <div class="service-item position-relative" style="padding:0px">
				<div class="service-img" style="height:auto;width:100%">
				<img src="<?php echo base_url(); ?>/assets/img/clients/Cummins.jpg" alt="">
			  </div>
			  
            </div>
          </div><!-- End Service Item -->
		  
		  <div class="col-lg-2 col-md-6" data-aos="fade-up" data-aos-delay="600">
            <div class="service-item position-relative" style="padding:0px">
				<div class="service-img" style="height:auto;width:100%">
				<img src="<?php echo base_url(); ?>/assets/img/clients/Comau.jpg" alt="">
			  </div>
			  
            </div>
          </div><!-- End Service Item -->
		  
		  <div class="col-lg-2 col-md-6" data-aos="fade-up" data-aos-delay="600">
            <div class="service-item position-relative" style="padding:0px">
				<div class="service-img" style="height:auto;width:100%">
				<img src="<?php echo base_url(); ?>/assets/img/clients/mark-exhaust.jpg" alt="">
			  </div>
			  
            </div>
          </div><!-- End Service Item -->
		  
		  <div class="col-lg-2 col-md-6" data-aos="fade-up" data-aos-delay="600">
            <div class="service-item position-relative" style="padding:0px">
				<div class="service-img" style="height:auto;width:100%">
				<img src="<?php echo base_url(); ?>/assets/img/clients/Perkins.jpg" alt="">
			  </div>
			  
            </div>
          </div><!-- End Service Item -->
		  
		  <div class="col-lg-2 col-md-6" data-aos="fade-up" data-aos-delay="600">
            <div class="service-item position-relative" style="padding:0px">
				<div class="service-img" style="height:auto;width:100%">
				<img src="<?php echo base_url(); ?>/assets/img/clients/tvs.jpg" alt="">
			  </div>
			  
            </div>
          </div><!-- End Service Item -->
		  
		  <div class="col-lg-2 col-md-6" data-aos="fade-up" data-aos-delay="600">
            <div class="service-item position-relative" style="padding:0px">
				<div class="service-img" style="height:auto;width:100%">
				<img src="<?php echo base_url(); ?>/assets/img/clients/varroc-logo.jpg" alt="">
			  </div>
			  
            </div>
          </div><!-- End Service Item -->
		  
		  <div class="col-lg-2 col-md-6" data-aos="fade-up" data-aos-delay="600">
            <div class="service-item position-relative" style="padding:0px">
				<div class="service-img" style="height:auto;width:100%">
				<img src="<?php echo base_url(); ?>/assets/img/clients/Yazaki.jpg" alt="">
			  </div>
			  
            </div>
          </div><!-- End Service Item -->

        </div>

      </div>
    </section><!-- End our client Section -->
	

    <!-- ======= Recent Blog Posts Section ======= -->
   <!-- <section id="recent-blog-posts" class="recent-blog-posts">
      <div class="container" data-aos="fade-up"">

    
    
  <div class=" section-header">
        <h2>Recent Blog Posts</h2>
        <p>In commodi voluptatem excepturi quaerat nihil error autem voluptate ut et officia consequuntu</p>
      </div>

      <div class="row gy-5">

        <div class="col-xl-4 col-md-6" data-aos="fade-up" data-aos-delay="100">
          <div class="post-item position-relative h-100">

            <div class="post-img position-relative overflow-hidden">
              <img src="<?php echo base_url(); ?>/assets/img/blog/blog-1.jpg" class="img-fluid" alt="">
              <span class="post-date">December 12</span>
            </div>

            <div class="post-content d-flex flex-column">

              <h3 class="post-title">Eum ad dolor et. Autem aut fugiat debitis</h3>

              <div class="meta d-flex align-items-center">
                <div class="d-flex align-items-center">
                  <i class="bi bi-person"></i> <span class="ps-2">Julia Parker</span>
                </div>
                <span class="px-3 text-black-50">/</span>
                <div class="d-flex align-items-center">
                  <i class="bi bi-folder2"></i> <span class="ps-2">Politics</span>
                </div>
              </div>

              <hr>

              <a href="<?php echo base_url(); ?>welcome/blogDetails" class="readmore stretched-link"><span>Read More</span><i
                  class="bi bi-arrow-right"></i></a>

            </div>

          </div>
        </div><!-- End post item -->

        <!--<div class="col-xl-4 col-md-6" data-aos="fade-up" data-aos-delay="200">
          <div class="post-item position-relative h-100">

            <div class="post-img position-relative overflow-hidden">
              <img src="<?php echo base_url(); ?>/assets/img/blog/blog-2.jpg" class="img-fluid" alt="">
              <span class="post-date">July 17</span>
            </div>

            <div class="post-content d-flex flex-column">

              <h3 class="post-title">Et repellendus molestiae qui est sed omnis</h3>

              <div class="meta d-flex align-items-center">
                <div class="d-flex align-items-center">
                  <i class="bi bi-person"></i> <span class="ps-2">Mario Douglas</span>
                </div>
                <span class="px-3 text-black-50">/</span>
                <div class="d-flex align-items-center">
                  <i class="bi bi-folder2"></i> <span class="ps-2">Sports</span>
                </div>
              </div>

              <hr>

              <a href="<?php echo base_url(); ?>welcome/blogDetails" class="readmore stretched-link"><span>Read More</span><i
                  class="bi bi-arrow-right"></i></a>

            </div>

          </div>
        </div><!-- End post item -->

        <!--<div class="col-xl-4 col-md-6">
          <div class="post-item position-relative h-100" data-aos="fade-up" data-aos-delay="300">

            <div class="post-img position-relative overflow-hidden">
              <img src="<?php echo base_url(); ?>/assets/img/blog/blog-3.jpg" class="img-fluid" alt="">
              <span class="post-date">September 05</span>
            </div>

            <div class="post-content d-flex flex-column">

              <h3 class="post-title">Quia assumenda est et veritati tirana ploder</h3>

              <div class="meta d-flex align-items-center">
                <div class="d-flex align-items-center">
                  <i class="bi bi-person"></i> <span class="ps-2">Lisa Hunter</span>
                </div>
                <span class="px-3 text-black-50">/</span>
                <div class="d-flex align-items-center">
                  <i class="bi bi-folder2"></i> <span class="ps-2">Economics</span>
                </div>
              </div>

              <hr>

              <a href="<?php echo base_url(); ?>welcome/blogDetails" class="readmore stretched-link"><span>Read More</span><i
                  class="bi bi-arrow-right"></i></a>

            </div>

          </div>
        </div><!-- End post item -->

      <!--</div>

      </div>
    </section>-->
    <!-- End Recent Blog Posts Section -->

  </main><!-- End #main -->

  <!-- ======= Footer ======= -->
  <footer id="footer" class="footer">

    <div class="footer-content position-relative">
      <div class="container">
        <div class="row">

          <div class="col-lg-4 col-md-6">
            <div class="footer-info">
              <h3 style="font-size:23px">Mikro Innotech Pvt. Ltd.</h3>
              <p>
				225, Sasewadi, Taluka Bhor,
				Off Pune Bangalore Expressway,
				Pune - 412205<br><br>
                <strong>Phone:</strong> +91-20-20240556 / +91 8308802300<br>
                <strong>Email:</strong> mikroinnotech@gmail.com<br><span class="padding_left" style="padding-left:50px">sales@mikroindia.com</span>
              </p>
              <div class="social-links d-flex mt-3">
				<!--<a href="#" class="d-flex align-items-center justify-content-center"><i class="bi bi-twitter"></i></a>-->
				<a href="https://www.facebook.com/mikroindia" class="d-flex align-items-center justify-content-center"><i class="bi bi-facebook"></i></a>
                <a href="https://instagram.com/mikro_india?igshid=t88sx3gzi8g0" class="d-flex align-items-center justify-content-center"><i class="bi bi-instagram"></i></a>
                <a href="https://www.linkedin.com/company/mikro-innotech-india" class="d-flex align-items-center justify-content-center"><i class="bi bi-linkedin"></i></a>
              </div>
            </div>
          </div><!-- End footer info column-->

          <div class="col-lg-4 col-md-3 footer-links">
            <h4 style="padding-left:70px">Useful Links</h4>
			<div class="row">
				<div class="col-lg-6" >
					<ul>
					  <li><a href="#">Home</a></li>
					  <li><a href="#">About us</a></li>
					  <li><a href="#">Project</a></li>
					  <li><a href="#">Gallery</a></li>
					  <li><a href="#">Principle</a></li>
					</ul>
				</div>
				<div class="col-lg-6">
					<ul>
					  <li><a href="#">Training</a></li>
					  <li><a href="#">Career</a></li>
					  <li><a href="#">Blog</a></li>
					  <li><a href="#">Contact</a></li>
					  <li><a href="#">Site Map</a></li>
					</ul>
				</div>
			</div>
          </div><!-- End footer links column-->
		  
		  <div class="col-lg-4 col-md-3 footer-links">
                   
						  <h4 style="padding-left:100px">Get In Touch</h4>
						  
						<form action="forms/contact.php" method="post" role="form" class="php-email-form">
              <div class="row gy-4" style="margin-bottom:4%">
                <div class="col-lg-6 form-group">
                  <input type="text" name="name" class="form-control" id="name" placeholder="Your Name" required>
                </div>
                <div class="col-lg-6 form-group">
                  <input type="email" class="form-control" name="email" id="email" placeholder="Your Email" required>
                </div>
              </div>
              <div class="form-group" style="margin-bottom:4%">
                <input type="text" class="form-control" name="subject" id="subject" placeholder="Subject" required>
              </div>
              <div class="form-group" style="margin-bottom:4%">
                <textarea class="form-control" name="message" rows="4" placeholder="Message" required></textarea>
              </div>
              
              <div class="text-center" ><button type="submit" style="border-radius:10px"><div class="send_text" style="color:#feb900">Send Message</div></button></div>
            </form>
		  </div>
        </div>
     </div>
      </div>
    

    <div class="footer-legal text-center position-relative">
      <div class="container">
        <div class="copyright">
          &copy; Copyright <strong><span>MIKRO 2018</span></strong>. All Rights Reserved
        </div>
        <div class="credits">
          <!-- All the links in the footer should remain intact. -->
          <!-- You can delete the links only if you purchased the pro version. -->
          <!-- Licensing information: https://bootstrapmade.com/license/ -->
          <!-- Purchase the pro version with working PHP/AJAX contact form: https://bootstrapmade.com/upconstruction-bootstrap-construction-website-template/ -->
          Designed & Developed by <a href="https://globalinfocloud.com/"> Global InfoCloud Pvt.Ltd.</a> 
        </div>
      </div>
    </div>

  </footer>
  <!-- End Footer -->

  <a href="#" class="scroll-top d-flex align-items-center justify-content-center"><i
      class="bi bi-arrow-up-short"></i></a>

  <div id="preloader"></div>

  <!-- Vendor JS Files -->
  <script src="<?php echo base_url(); ?>/assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="<?php echo base_url(); ?>/assets/vendor/aos/aos.js"></script>
  <script src="<?php echo base_url(); ?>/assets/vendor/glightbox/js/glightbox.min.js"></script>
  <script src="<?php echo base_url(); ?>/assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
  <script src="<?php echo base_url(); ?>/assets/vendor/swiper/swiper-bundle.min.js"></script>
  <script src="<?php echo base_url(); ?>/assets/vendor/purecounter/purecounter_vanilla.js"></script>
  <script src="<?php echo base_url(); ?>/assets/vendor/php-email-form/validate.js"></script>

  <!-- Template Main JS File -->
  <script src="<?php echo base_url(); ?>/assets/js/main.js"></script>

</body>

</html>