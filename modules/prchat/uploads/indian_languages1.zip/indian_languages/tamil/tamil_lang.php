<?php

# Version 1.0.0
#
# General
$lang['Akola']                   = 'அகோலா';
$lang['Nanded']                  = 'நான்டெட்';
$lang['Latur']                   = 'லதூர்';
$lang['Parbhani']                = 'பர்பானி';
$lang['Udgir']                   = 'உட்கிர்';
$lang['Barshi']                  = 'பார்ஷி';
$lang['Solapur']                 = 'சோலாப்பூர்';
$lang['Ausa']                    = 'அவுசா';
$lang['Ambejogai']               = 'அம்பேஜோகாய்';
$lang['Khamgaon']                = 'கம்கான்';
$lang['Hinganghat']              = 'ஹிங்காங்காட்';
$lang['Omerga']                  = 'ஓமர்கா';
$lang['Bijapur']                 = 'பிஜாப்பூர்';
$lang['Gulbarga']                = 'குல்பர்கா';
$lang['Bidar']                   = 'பிதார்';
$lang['Bailhongal']              = 'பெய்லாங்கல்';

$lang['Bajra']              = 'பஜ்ரா';
$lang['Channa']             = 'சன்னா';
$lang['Toor']               = 'டோர்';
$lang['Sunflower']          = 'சூரியகாந்தி';
$lang['Soybean']            = 'சோயாபீன்';
$lang['Massor']             = 'மாசோர்';
$lang['Moong']              = 'மூங்';
$lang['Safflower']          = 'குங்குமப்பூ';
$lang['Udad']               = 'உதாட்';
$lang['Maize']              = 'சோளம்';
