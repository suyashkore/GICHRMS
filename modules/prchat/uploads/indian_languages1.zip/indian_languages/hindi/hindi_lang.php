<?php

# Version 1.0.0
#
# General
$lang['Akola']                   = 'अकोला';
$lang['Nanded']                  = 'नांदेड़';
$lang['Latur']                   = 'लातूर';
$lang['Parbhani']                = 'परभनी';
$lang['Udgir']                   = 'उदगीर';
$lang['Barshi']                  = 'बरशी';
$lang['Solapur']                 = 'सोलापुर';
$lang['Ausa']                    = 'औसा';
$lang['Ambejogai']               = 'अम्बेजोगाई';
$lang['Khamgaon']                = 'खामगांव';
$lang['Hinganghat']              = 'हिंगणघाट';
$lang['Omerga']                  = 'ओमर्गा';
$lang['Bijapur']                 = 'बीजापुर';
$lang['Gulbarga']                = 'गुलबर्गा';
$lang['Bidar']                   = 'बीडर';
$lang['Bailhongal']              = 'बेलहोंगल';

$lang['Bajra']              = 'बाजरे';
$lang['Channa']             = 'चन्ना';
$lang['Toor']               = 'टूर';
$lang['Sunflower']          = 'सूरजमुखी';
$lang['Soybean']            = 'सोयाबीन';
$lang['Massor']             = 'द्रोही';
$lang['Moong']              = 'मूंग';
$lang['Safflower']          = 'कुसुम';
$lang['Udad']               = 'उदाद';
$lang['Maize']              = 'मक्का';
