<?php

# Version 1.0.0
#
# General
$lang['Akola']                   = 'అకోలా';
$lang['Nanded']                  = 'నాండెడ్';
$lang['Latur']                   = 'లోటుర్';
$lang['Parbhani']                = 'పర్భాని';
$lang['Udgir']                   = 'ఉద్గిర్';
$lang['Barshi']                  = 'బార్షి';
$lang['Solapur']                 = 'సోలాపూర్';
$lang['Ausa']                    = 'ఔసా';
$lang['Ambejogai']               = 'అంబెజోగై';
$lang['Khamgaon']                = 'ఖమ్‌గావ్';
$lang['Hinganghat']              = 'హింగాంగ్ఘాట్';
$lang['Omerga']                  = 'ఓమెర్గా';
$lang['Bijapur']                 = 'బిజాపూర్';
$lang['Gulbarga']                = 'గుల్బర్గా';
$lang['Bidar']                   = 'బీదార్';
$lang['Bailhongal']              = 'బైల్‌హోంగల్';

$lang['Bajra']              = 'బజ్రా';
$lang['Channa']             = 'చన్నా';
$lang['Toor']               = 'టూర్';
$lang['Sunflower']          = 'పొద్దుతిరుగుడు';
$lang['Soybean']            = 'సోయాబీన్';
$lang['Massor']             = 'మాసోర్';
$lang['Moong']              = 'మూంగ్';
$lang['Safflower']          = 'వాసు పిసుల';
$lang['Udad']               = 'ఉడాద్';
$lang['Maize']              = 'మొక్కజొన్న';
