<?php

# Version 1.0.0
#
# General
$lang['Akola']                   = 'നിഷേധിങ്ങനെ';
$lang['Nanded']                  = 'નકામું';
$lang['Latur']                   = 'അഗ്നി';
$lang['Parbhani']                = 'પરખર';
$lang['Udgir']                   = 'രീതി';
$lang['Barshi']                  = 'ક ബാർ';
$lang['Solapur']                 = 'માંદગી';
$lang['Ausa']                    = 'એ.એસ.એસ.એ.';
$lang['Ambejogai']               = 'અંબેજ';
$lang['Khamgaon']                = 'ടത്തറിയൽ';
$lang['Hinganghat']              = 'രീതി';
$lang['Omerga']                  = 'Om ો';
$lang['Bijapur']                 = 'തെൽക്കട്ട';
$lang['Gulbarga']                = 'പതിവ്';
$lang['Bidar']                   = 'രീതി';
$lang['Bailhongal']              = 'വിവേകമുള്ള અણીદાર';

$lang['Bajra']              = 'രീന്വേഷിക്കുക';
$lang['Channa']             = 'ത്വവൃദ്ധം';
$lang['Toor']               = 'പതിവു ઘેરો';
$lang['Sunflower']          = 'સૂર્યમુખી';
$lang['Soybean']            = 'ન';
$lang['Massor']             = 'શરાબ';
$lang['Moong']              = 'ഘചരാതമായ';
$lang['Safflower']          = 'કેસી';
$lang['Udad']               = 'ઉદાદ';
$lang['Maize']              = 'പതതം';
