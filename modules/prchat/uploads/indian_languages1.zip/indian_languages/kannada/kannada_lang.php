<?php

# Version 1.0.0
#
# General
$lang['Akola']                   = 'ಅಣಬಾ';
$lang['Nanded']                  = 'ನಸನ';
$lang['Latur']                   = 'ಲಕ್ಷ';
$lang['Parbhani']                = 'ಪೃಷ್ಠದವನು';
$lang['Udgir']                   = 'ಉಡ್ಗೀರ್';
$lang['Barshi']                  = 'ಬರ್ಶಿ';
$lang['Solapur']                 = 'ಸೋತ';
$lang['Ausa']                    = 'ಸೇನಾ';
$lang['Ambejogai']               = 'ಅಬ್ಬರ';
$lang['Khamgaon']                = 'ಖಮಗಾಂವ್';
$lang['Hinganghat']              = 'ಹಿಂಗಂಗಟ್';
$lang['Omerga']                  = 'ನುಗ್ಗು';
$lang['Bijapur']                 = 'ಬಿಜಾಪುರ';
$lang['Gulbarga']                = 'ಗುಲ್ಬಾರ್ಗ';
$lang['Bidar']                   = 'ದಾರ್ಷ್';
$lang['Bailhongal']              = 'ಕಾಸ';

$lang['Bajra']              = 'ದಳ';
$lang['Channa']             = 'ಚಿರತೆ';
$lang['Toor']               = 'ತಂಬ';
$lang['Sunflower']          = 'ಸೂರ್ಯಕಾಂತಿ';
$lang['Soybean']            = 'ಸೋಯಾಬೀನ್';
$lang['Massor']             = 'ಹಸುರು';
$lang['Moong']              = 'ಮೂಂಗ್';
$lang['Safflower']          = 'ಕುಸಿತ';
$lang['Udad']               = 'ನದಕ';
$lang['Maize']              = 'ಮೆಕ್ಕೆ ಜೋಳ';
