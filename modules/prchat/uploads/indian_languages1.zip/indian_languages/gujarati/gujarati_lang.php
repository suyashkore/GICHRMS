<?php

# Version 1.0.0
#
# General
$lang['Akola']                   = 'अकोला';
$lang['Nanded']                  = 'नांदेड़';
$lang['Latur']                   = 'लातूर';
$lang['Parbhani']                = 'परभणी';
$lang['Udgir']                   = 'उदगीर';
$lang['Barshi']                  = 'बार्शी';
$lang['Solapur']                 = 'सोलापूर';
$lang['Ausa']                    = 'औसा';
$lang['Ambejogai']               = 'अंबेजोगाई';
$lang['Khamgaon']                = 'खामगांव';
$lang['Hinganghat']              = 'हिंगांघाट';
$lang['Omerga']                  = 'ओमरगा';
$lang['Bijapur']                 = 'बिजापूर';
$lang['Gulbarga']                = 'गुलबर्ग';
$lang['Bidar']                   = 'बिदर';
$lang['Bailhongal']              = 'बेलहोंगल';

$lang['Bajra']              = 'बाजरा';
$lang['Channa']             = 'चन्ना';
$lang['Toor']               = 'तूर';
$lang['Sunflower']          = 'सूर्यफूल';
$lang['Soybean']            = 'सोयाबीन';
$lang['Massor']             = 'मासर';
$lang['Moong']              = 'मूग';
$lang['Safflower']          = 'केशर';
$lang['Udad']               = 'उडाड';
$lang['Maize']              = 'मका';

