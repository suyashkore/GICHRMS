<?php

# Version 1.0.0
#
# General
$lang['Nanded']                   = 'नांदेड';
