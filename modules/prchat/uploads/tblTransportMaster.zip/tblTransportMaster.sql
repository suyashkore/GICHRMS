-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Feb 14, 2024 at 06:22 PM
-- Server version: 5.7.44
-- PHP Version: 8.1.27

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `kirti2ginf9_erp_db_k`
--

-- --------------------------------------------------------

--
-- Table structure for table `tblTransportMaster`
--

CREATE TABLE `tblTransportMaster` (
  `id` int(11) NOT NULL,
  `TransportID` varchar(20) NOT NULL,
  `TransportName` varchar(200) DEFAULT NULL,
  `country_id` int(11) NOT NULL,
  `state` varchar(20) NOT NULL,
  `city` varchar(20) NOT NULL,
  `address` varchar(500) DEFAULT NULL,
  `PAN` varchar(50) DEFAULT NULL,
  `bank` varchar(500) DEFAULT NULL,
  `account_type` varchar(20) DEFAULT NULL,
  `account_number` varchar(50) DEFAULT NULL,
  `ifsc_code` varchar(30) DEFAULT NULL,
  `PAN_Card_image` text,
  `gst_certification_image` text,
  `aadhaar_image` text,
  `shop_act_image` text,
  `transport_permit` text,
  `cancel_cheque` text,
  `ownership_photo` text,
  `address_proof` text
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblTransportMaster`
--

INSERT INTO `tblTransportMaster` (`id`, `TransportID`, `TransportName`, `country_id`, `state`, `city`, `address`, `PAN`, `bank`, `account_type`, `account_number`, `ifsc_code`, `PAN_Card_image`, `gst_certification_image`, `aadhaar_image`, `shop_act_image`, `transport_permit`, `cancel_cheque`, `ownership_photo`, `address_proof`) VALUES
(1, 'T0001', 'S.R.TRANSPORT COMPANY', 1, 'MH', '537', 'Akola', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(2, 'T0002', 'OM GANESH ROADLINES', 1, 'MH', '551', 'Latur', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tblTransportMaster`
--
ALTER TABLE `tblTransportMaster`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tblTransportMaster`
--
ALTER TABLE `tblTransportMaster`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
