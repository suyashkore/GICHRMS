import { ComponentFixture, TestBed } from '@angular/core/testing';

import { GltfCupComponent } from './gltf-cup.component';

describe('GltfCupComponent', () => {
  let component: GltfCupComponent;
  let fixture: ComponentFixture<GltfCupComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [GltfCupComponent]
    });
    fixture = TestBed.createComponent(GltfCupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
