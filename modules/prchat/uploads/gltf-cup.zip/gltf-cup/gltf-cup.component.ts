//import { Component, OnInit } from '@angular/core';
import * as THREE from 'three';
//import  GLTFLoader  from 'three-gltf-loader';
import { Component, ElementRef, NgZone, OnInit, ViewChild } from '@angular/core';
import { GLTFLoader } from 'three/examples/jsm/loaders/GLTFLoader';
//import  OrbitControls  from 'three-orbitcontrols'; 
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls';



//import { GLTFLoader } from 'three-gltf-loader';


@Component({
  selector: 'app-gltf-cup',
  templateUrl: './gltf-cup.component.html',
  styleUrls: ['./gltf-cup.component.css']
})
export class GltfCupComponent implements OnInit  {

  // scene: THREE.Scene;
  // camera: THREE.PerspectiveCamera;
  // renderer: THREE.WebGLRenderer;
  // loader: GLTFLoader;

  // constructor() {}

  // ngOnInit() {
  //   // Create the scene
  //   this.scene = new THREE.Scene();

  //   // Create the camera
  //   this.camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 1000);
  //   this.camera.position.set(0, 0, 5); // Adjusted camera position

  //   // Create the renderer
  //   this.renderer = new THREE.WebGLRenderer();
  //   this.renderer.setSize(window.innerWidth, window.innerHeight);
  //   document.body.appendChild(this.renderer.domElement);

  //   // Add an ambient light
  //   const ambientLight = new THREE.AmbientLight(0x404040);
  //   this.scene.add(ambientLight);

  //   // Add a directional light
  //   const directionalLight = new THREE.DirectionalLight(0xffffff);
  //   directionalLight.position.set(1, 1, 1);
  //   this.scene.add(directionalLight);

  //   // Create the GLTFLoader
  //   this.loader = new GLTFLoader();
  //   this.loader.load('/assets/iron_man_mark_85.glb', (gltf) => {
  //     const model = gltf.scene;
  //     this.scene.add(model);
  //   });

  //   this.animate();
  // }

  // animate() {
  //   requestAnimationFrame(() => this.animate());
  //   this.renderer.render(this.scene, this.camera);
  // }


  //orbit controll

  scene: THREE.Scene;
  camera: THREE.PerspectiveCamera;
  renderer: THREE.WebGLRenderer;
  loader: GLTFLoader;
  controls: OrbitControls; // Add controls

  constructor() {}

  ngOnInit() {
    // Create the scene
    this.scene = new THREE.Scene();

    // Create the camera
    this.camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 1000);
    this.camera.position.set(0, 0, 5);

    // Create the renderer
    this.renderer = new THREE.WebGLRenderer();
    this.renderer.setSize(window.innerWidth, window.innerHeight);
    document.body.appendChild(this.renderer.domElement);

    // Add an ambient light
    const ambientLight = new THREE.AmbientLight(0x404040);
    this.scene.add(ambientLight);

    // Add a directional light
    const directionalLight = new THREE.DirectionalLight(0xffffff);
    directionalLight.position.set(1, 1, 1);
    this.scene.add(directionalLight);

    // Create the GLTFLoader
    this.loader = new GLTFLoader();
    this.loader.load('/assets/adamHead.gltf', (gltf) => {
      const model = gltf.scene;
      this.scene.add(model);
    });

    // Add OrbitControls
    this.controls = new OrbitControls(this.camera, this.renderer.domElement);
    this.controls.addEventListener('change', this.renderScene);

    this.animate();
  }

  animate() {
    requestAnimationFrame(() => this.animate());
    this.controls.update(); // Update controls
    this.renderer.render(this.scene, this.camera);
  }

  renderScene = () => {
    this.renderer.render(this.scene, this.camera);
  };
}
