-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Sep 02, 2023 at 06:40 PM
-- Server version: 5.7.43
-- PHP Version: 8.1.16

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `t5e3s4tgi_demo_erp`
--

-- --------------------------------------------------------

--
-- Table structure for table `tblsalesmaster_audit`
--

CREATE TABLE `tblsalesmaster_audit` (
  `PlantID` int(11) NOT NULL,
  `FY` varchar(2) NOT NULL,
  `BT` varchar(1) NOT NULL,
  `SalesID` varchar(11) NOT NULL,
  `Transdate` datetime(6) NOT NULL,
  `OrderID` varchar(11) DEFAULT NULL,
  `ChallanID` varchar(11) DEFAULT NULL,
  `AccountID` varchar(50) NOT NULL,
  `Tin` varchar(15) DEFAULT NULL,
  `gstno` varchar(15) DEFAULT NULL,
  `PayType` varchar(1) NOT NULL,
  `SaleAmt` decimal(16,2) NOT NULL,
  `DiscAmt` decimal(16,2) DEFAULT NULL,
  `sgstamt` decimal(16,2) DEFAULT NULL,
  `cgstamt` decimal(16,2) DEFAULT NULL,
  `igstamt` decimal(16,2) DEFAULT NULL,
  `BillAmt` decimal(16,2) NOT NULL,
  `RndAmt` bigint(20) NOT NULL,
  `ItCount` int(11) NOT NULL,
  `UserID` varchar(50) DEFAULT NULL,
  `ewayno` varchar(20) DEFAULT NULL,
  `AccountID2` varchar(50) DEFAULT NULL,
  `gstin2` varchar(15) DEFAULT NULL,
  `cnfid` varchar(50) NOT NULL,
  `tcs` decimal(9,4) DEFAULT NULL,
  `tcsAmt` decimal(12,2) DEFAULT NULL,
  `irn` varchar(1000) CHARACTER SET utf8mb4 DEFAULT NULL,
  `Qrcode` varchar(4000) CHARACTER SET utf8mb4 DEFAULT NULL,
  `QRImg` longblob,
  `ackno` varchar(20) DEFAULT NULL,
  `ackdate` datetime(6) DEFAULT NULL,
  `QRfilename` varchar(100) DEFAULT NULL,
  `ewbno` varchar(20) DEFAULT NULL,
  `QRLupdate` datetime(6) DEFAULT NULL,
  `QRUserID` varchar(50) DEFAULT NULL,
  `UserID2` varchar(50) DEFAULT NULL,
  `Lupdate` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tblsalesmaster_audit`
--
ALTER TABLE `tblsalesmaster_audit`
  ADD PRIMARY KEY (`PlantID`,`FY`,`BT`,`SalesID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
