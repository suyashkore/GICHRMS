-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Sep 02, 2023 at 06:37 PM
-- Server version: 5.7.43
-- PHP Version: 8.1.16

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `t5e3s4tgi_demo_erp`
--

-- --------------------------------------------------------

--
-- Table structure for table `tblordermaster_audit`
--

CREATE TABLE `tblordermaster_audit` (
  `PlantID` int(11) NOT NULL,
  `FY` varchar(2) NOT NULL,
  `OrderID` varchar(11) NOT NULL,
  `ChallanID` varchar(11) DEFAULT NULL,
  `SalesID` varchar(11) DEFAULT NULL,
  `Transdate` datetime(6) NOT NULL,
  `AccountID` varchar(50) NOT NULL,
  `GSTNO` varchar(15) DEFAULT NULL,
  `OrderAmt` decimal(16,2) NOT NULL,
  `Crates` bigint(20) DEFAULT NULL,
  `Cases` bigint(20) DEFAULT NULL,
  `OrderStatus` varchar(1) DEFAULT NULL,
  `OrderType` varchar(50) NOT NULL,
  `Variation` decimal(16,2) DEFAULT NULL,
  `UserID` varchar(50) NOT NULL,
  `AccountID2` varchar(50) DEFAULT NULL,
  `Gstin2` varchar(15) DEFAULT NULL,
  `cnfid` varchar(50) NOT NULL,
  `UserID2` varchar(50) DEFAULT NULL,
  `Lupdate` datetime(6) DEFAULT NULL,
  `WebOrderID` int(11) DEFAULT NULL,
  `isedited` int(11) DEFAULT NULL,
  `reason` text,
  `subtotal` decimal(16,2) DEFAULT NULL,
  `total_tax` decimal(16,2) DEFAULT NULL,
  `order_type` varchar(50) DEFAULT NULL,
  `currency` int(11) NOT NULL DEFAULT '3',
  `remark` varchar(1500) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tblordermaster_audit`
--
ALTER TABLE `tblordermaster_audit`
  ADD PRIMARY KEY (`PlantID`,`FY`,`OrderID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
