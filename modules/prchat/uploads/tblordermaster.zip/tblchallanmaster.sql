-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Sep 02, 2023 at 06:39 PM
-- Server version: 5.7.43
-- PHP Version: 8.1.16

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `t5e3s4tgi_demo_erp`
--

-- --------------------------------------------------------

--
-- Table structure for table `tblchallanmaster_audit`
--

CREATE TABLE `tblchallanmaster_audit` (
  `PlantID` int(11) NOT NULL,
  `FY` varchar(2) NOT NULL,
  `ChallanID` varchar(11) NOT NULL,
  `cnfid` varchar(50) NOT NULL,
  `Transdate` datetime(6) NOT NULL,
  `RouteID` int(50) NOT NULL,
  `VehicleID` varchar(15) NOT NULL,
  `DriverID` varchar(50) DEFAULT NULL,
  `LoaderID` varchar(50) DEFAULT NULL,
  `SalesmanID` varchar(50) DEFAULT NULL,
  `Crates` bigint(20) DEFAULT NULL,
  `Cases` bigint(20) DEFAULT NULL,
  `ChallanAmt` decimal(16,2) NOT NULL,
  `GetPassTime` datetime(6) DEFAULT NULL,
  `gatepasstime` datetime(6) DEFAULT NULL,
  `Gatepassuserid` varchar(50) DEFAULT NULL,
  `UserID` varchar(50) DEFAULT NULL,
  `UserID2` varchar(50) DEFAULT NULL,
  `Lupdate` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tblchallanmaster_audit`
--
ALTER TABLE `tblchallanmaster_audit`
  ADD PRIMARY KEY (`PlantID`,`ChallanID`,`FY`),
  ADD KEY `RouteID` (`RouteID`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `tblchallanmaster_audit`
--
ALTER TABLE `tblchallanmaster_audit`
  ADD CONSTRAINT `RouteID` FOREIGN KEY (`RouteID`) REFERENCES `tblroute` (`RouteID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
