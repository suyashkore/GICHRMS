<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>
<div class="modal-header">
    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span
            aria-hidden="true">&times;</span></button>
    <h4 class="modal-title">
        <?php if (isset($lead)) {
    if (!empty($lead->name)) {
        $name = $lead->name;
    } elseif (!empty($lead->company)) {
        $name = $lead->company;
    } else {
        $name = _l('lead');
    }
    echo '#' . $lead->id . ' - ' . $name;
} else {
    echo _l('add_new', _l('lead_lowercase'));
}

if (isset($lead)) {
    echo '<div class="tw-ml-4 -tw-mt-2 tw-inline-block">';
    if ($lead->lost == 1) {
        echo '<span class="label label-danger">' . _l('lead_lost') . '</span>';
    } elseif ($lead->junk == 1) {
        echo '<span class="label label-warning">' . _l('lead_junk') . '</span>';
    } else {
        if (total_rows(db_prefix() . 'clients', [
          'leadid' => $lead->id, ])) {
            echo '<span class="label label-success">' . _l('lead_is_client') . '</span>';
        }
    }
    echo '</div>';
}
?>
    </h4>
</div>
<div class="modal-body">
    <div class="row">
        <div class="col-md-12">
            <?php if (isset($lead)) {
    echo form_hidden('leadid', $lead->id);
} ?>
            <div class="top-lead-menu">
                <?php if (isset($lead)) { ?>
                <div class="horizontal-scrollable-tabs preview-tabs-top panel-full-width-tabs mbot20">
                    <div class="scroller arrow-left"><i class="fa fa-angle-left"></i></div>
                    <div class="scroller arrow-right"><i class="fa fa-angle-right"></i></div>
                    <div class="horizontal-tabs">
                        <ul class="nav-tabs-horizontal nav nav-tabs<?php if (!isset($lead)) {
    echo ' lead-new';
} ?>" role="tablist">
                            <li role="presentation" class="active">
                                <a href="#tab_lead_profile" aria-controls="tab_lead_profile" role="tab"
                                    data-toggle="tab">
                                    <?php echo _l('lead_profile'); ?>
                                </a>
                            </li>
                            <?php if (isset($lead)) { ?>
                            <?php if (count($mail_activity) > 0 || isset($show_email_activity) && $show_email_activity) { ?>
                            <li role="presentation">
                                <a href="#tab_email_activity" aria-controls="tab_email_activity" role="tab"
                                    data-toggle="tab">
                                    <?php echo hooks()->apply_filters('lead_email_activity_subject', _l('lead_email_activity')); ?>
                                </a>
                            </li>
                            <?php } ?>
                            
                            <!-- <li role="presentation">
              <a href="#tab_lead_profile1" aria-controls="tab_lead_profile1" role="tab" data-toggle="tab">
                Send Email
              </a>
           </li>-->
            <li role="presentation">
                <a href="#tab_lead_profile111" aria-controls="tab_lead_profile111" role="tab" data-toggle="tab">GIC Profile
                </a>
            </li>
            
            <li role="presentation">
                <a href="#tab_send_product_brochure" aria-controls="tab_send_product_brochure" role="tab" data-toggle="tab">Product Brochure
                </a>
            </li>
           
            <li role="presentation">
                                <a href="#tab_proposals_leads"
                                    onclick="initDataTable('.table-proposals-lead', admin_url + 'proposals/proposal_relations/' + <?php echo $lead->id; ?> + '/lead','undefined', 'undefined','undefined',[6,'desc']);"
                                    aria-controls="tab_proposals_leads" role="tab" data-toggle="tab">
                                    <?php echo _l('proposals');
                        if ($total_proposals > 0) {
                            echo ' <span class="badge">' . $total_proposals . '</span>';
                        }
                        ?>
                                </a>
                            </li>
                            <li role="presentation">
                                <a href="#tab_tasks_leads"
                                    onclick="init_rel_tasks_table(<?php echo $lead->id; ?>,'lead','.table-rel-tasks-leads');"
                                    aria-controls="tab_tasks_leads" role="tab" data-toggle="tab">
                                    <?php echo _l('tasks');
                        if ($total_tasks > 0) {
                            echo ' <span class="badge">' . $total_tasks . '</span>';
                        }
                        ?>
                                </a>
                            </li>
                            <li role="presentation">
                                <a href="#attachments" aria-controls="attachments" role="tab" data-toggle="tab">
                                    <?php echo _l('lead_attachments');
                        if ($total_attachments > 0) {
                            echo ' <span class="badge">' . $total_attachments . '</span>';
                        }
                        ?>
                                </a>
                            </li>
                            <li role="presentation">
                                <a href="#lead_reminders"
                                    onclick="initDataTable('.table-reminders-leads', admin_url + 'misc/get_reminders/' + <?php echo $lead->id; ?> + '/' + 'lead', undefined, undefined,undefined,[1, 'asc']);"
                                    aria-controls="lead_reminders" role="tab" data-toggle="tab">
                                    <?php echo _l('leads_reminders_tab');
                           if ($total_reminders > 0) {
                               echo ' <span class="badge">' . $total_reminders . '</span>';
                           }
                           ?>
                                </a>
                            </li>
                            <li role="presentation">
                                <a href="#lead_notes" aria-controls="lead_notes" role="tab" data-toggle="tab">
                                    <?php echo _l('lead_add_edit_notes');
                        if ($total_notes > 0) {
                            echo ' <span class="badge">' . $total_notes . '</span>';
                        }
                        ?>
                                </a>
                            </li>
                            <li role="presentation">
                                <a href="#lead_activity" aria-controls="lead_activity" role="tab" data-toggle="tab">
                                    <?php echo _l('lead_add_edit_activity'); ?>
                                </a>
                            </li>
                            <?php if (is_gdpr() && (get_option('gdpr_enable_lead_public_form') == '1' || get_option('gdpr_enable_consent_for_leads') == '1')) { ?>
                            <li role="presentation">
                                <a href="#gdpr" aria-controls="gdpr" role="tab" data-toggle="tab">
                                    <?php echo _l('gdpr_short'); ?>
                                </a>
                            </li>
                            <?php } ?>
                            <?php } ?>
                            <?php hooks()->do_action('after_lead_lead_tabs', $lead ?? null); ?>
                        </ul>
                    </div>
                </div>
                <?php } ?>
            </div>
            <!-- Tab panes -->
            <div class="tab-content">
                <!-- from leads modal -->
                <div role="tabpanel" class="tab-pane active" id="tab_lead_profile">
                    <?php $this->load->view('admin/leads/profile'); ?>
                </div>
                
                
                <!-- custom code start -->
            
            <div role="tabpanel" class="tab-pane" id="tab_lead_profile1">
            <div class="row">
      <div class="col-md-12 col-lg-12">
      <?php echo form_open_multipart('admin/emails/send_mail_for_lead'); ?>
        <?php //print_r($project);
        
$login_email = get_staff_full_name1();
//echo $login_email;
$pos1 = strpos($login_email,"(");
$email = substr($login_email,$pos1+1,-1);
//echo $email;
?>
                  <div class="col-xs-6 col-sm-6 col-md-6">
                    <label>Email From</label>
                    <div class="form-group">
                      <input type="text" name="email_from" id="email_from" class="form-control input-sm" value="<?php echo $email; ?>" readonly>
                    </div>
                  </div>
                  
                  <div class="col-xs-6 col-sm-6 col-md-6">
                    <label>Email To</label>
                    
                    <div class="form-group">
                      <input type="text" name="email_to" id="email_to" class="form-control input-sm" value="<?php echo $lead->email; ?>" readonly>
                    </div>
                  
                  </div>
                  <div class="col-xs-6 col-sm-6 col-md-6">
                    <label>Subject</label>
                    <div class="form-group">
                      <input type="text" name="Subject" id="Subject" class="form-control input-sm" placeholder="Subject" value="<?php echo $lead->name; ?>">
                    </div>
                  </div>
                  <div class="col-xs-6 col-sm-6 col-md-6">
                    <label>Cc</label>
                    <div class="form-group">
                      <textarea name="cc" id="cc" class="form-control input-sm" placeholder="Cc"><?php foreach($secondery_user as $key => $value) { echo $value.',';} ?></textarea>
                      <!-- <span>CC To: <?php foreach($secondery_user as $key => $value) { echo $value.', ';} ?></span> -->
                      <input type="hidden" name="hiddencc" id="hiddencc" value="<?php foreach($secondery_user as $key => $value) { echo $value.',';} ?>">
                    </div>
                  </div>
                  <div class="col-xs-6 col-sm-6 col-md-6">
                    <label>Bcc</label>
                    <div class="form-group">
                      <input type="text" name="bcc" id="bcc" class="form-control input-sm" value="gic.crm1@gmail.com" readonly="">
                    </div>
                  </div>
                  
                  
                  
                  <div class="col-xs-12 col-sm-12 col-md-12">
                    <label>Message Body</label>
                    
                    <div class="form-group">
                      <!-- <textarea rows="6" cols="150" class="form-control" id="Message" class="Message" placeholder="Message..">
                    </textarea> -->
                    
                    <?php echo render_textarea('message','','',array(),array(),'','tinymce'); ?>
                    
                    </div>
                  </div>
 
                    
        
                  <div class="panel-footer attachments_area">
            <div class="row attachments">
               <div class="attachment">
                  <div class="col-md-6 col-md-offset-3"> 
                     <div class="form-group">
                        <label for="attachment" class="control-label"><?php echo _l('clients_ticket_attachments'); ?></label>
                        <div class="input-group">
                           <input type="file" extension="<?php echo str_replace('.','',get_option('ticket_attachments_file_extensions')); ?>" filesize="<?php echo file_upload_max_size(); ?>" class="form-control" name="attachments[0]" accept="<?php echo get_ticket_form_accepted_mimes(); ?>">
                           <span class="input-group-btn">
                           <button class="btn btn-success add_more_attachments p8-half" data-ticket="true" type="button"><i class="fa fa-plus"></i></button>
                           </span>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
                  <!--<input type="text" name="hidden_feild" value="<?php echo $lead->id; ?>">-->
                  <input type="hidden" name="Comment_mail" id="Comment_mail" class="form-control input-sm">
                  <button class="btn btn-warning send" type="submit" id="send">Send</button>
                <?php echo form_close(); ?>
        
      </div>
      
    </div>
      </div>
            
<!--=======================  Send GIC Profile ===============================-->  

    <div role="tabpanel" class="tab-pane" id="tab_lead_profile111">
      <?php echo form_open('admin/emails/company_profile_mail',array('id'=>'lead_form')); ?>
        <?php 
            $login_email = get_staff_full_name1();
            $pos1 = strpos($login_email,"(");
            $email = substr($login_email,$pos1+1,-1);
        ?>
        <div class="col-xs-6 col-sm-6 col-md-6">
            <label>Email From</label>
            <div class="form-group">
                <input type="text" name="email_from" id="email_from" class="form-control input-sm" value="bd@support.globalinfocloud.com" readonly>
            </div>
        </div>
            <input type="hidden" name="lead_id" value="<?php echo $lead->id; ?>">
        <div class="col-xs-6 col-sm-6 col-md-6">
            <label>Email To</label>
            <div class="form-group">
                <input type="text" name="email_to" id="email_to" class="form-control input-sm" value="<?php echo $lead->email; ?>">
            </div>
        </div>
        <div class="clearfix"></div>

        <div class="col-xs-6 col-sm-6 col-md-6">
            <label>Subject</label>
            <div class="form-group">
                <input type="text" name="Subject" id="Subject" class="form-control input-sm" placeholder="Subject" value="Global Infocloud Pvt Ltd Company Profile">
            </div>
        </div>
        <div class="col-xs-6 col-sm-6 col-md-6">
            <label>Cc</label>
            <div class="form-group">
                <input type="text" name="cc" id="cc" value="<?php echo $email; ?>;sales@globalinfocloud.com" readonly class="form-control input-sm" placeholder="Cc">
            </div>
        </div>
        <div class="clearfix"></div>
        <div class="col-xs-6 col-sm-6 col-md-6">
            <label>Bcc</label>
            <div class="form-group">
                <input type="text" name="bcc" id="bcc" class="form-control input-sm" value="sales.globalinfocloud@gmail.com" readonly="">
            </div>
        </div>
                  
        <div class="col-xs-6 col-sm-6 col-md-6">
            <label>&nbsp;</label>
            <div class="form-group">
                <button class="btn btn-warning send" type="submit" id="send">Send Email</button>
            </div>
        </div>
                  
        <div class="clearfix"></div>
                  
        <div class="col-xs-12 col-sm-12 col-md-12">
            <label><strong>Message Body</strong></label>
            <br>
            <!-- <p style="text-align: justify;"><b>Please have a look to our </b><a href="https://support.globalinfocloud.com/uploads/GIC-Company-Profile_6_23.pdf" target="_blank"><b>Company Profile Here</b></a></p>
            <p>Anticipating for great business together!</p>
                    
                    <p>Thanks!</p>
                    -->
            <div class="form-group">
                <?php
                    $body1 = '<p>Dear '.$name.',</p>
                    <p>Greetings!</p>
                    <p class="whowe" style="text-align: justify;">I hope this email finds you well. I wanted to introduce Global Infocloud Pvt Ltd, a dynamic team of IT, Marketing & Design experts dedicated to helping businesses like yours thrive.</p>
                    <p style="text-align: justify;" class="whowe">At Global Infocloud, we specialize in comprehensive, cost-effective, and efficient Digital Business Automation, Marketing & Design Solutions. Our mission is to simplify your business complexities and maximize its value, while working closely with you to adapt our services to your unique needs.</p>
                    <p style="text-align: justify;">With a track record of successfully serving startups, SMEs, and Fortune companies worldwide, we have built a solid reputation as a trusted advisor and a workhorse for the complete business ecosystem. Our 100+ members combine their expertise to deliver exceptional results.</p>
                    
                    
                    <p style="text-align: justify;">To learn more about our services and expertise, I invite you to visit our website at <a href="https://www.globalinfocloud.com/" target="_blank">https://www.globalinfocloud.com/</a>. Also, attaching here our company profile for your perusal. </p>
                    
                    <p style="text-align: justify;"><b>Please have a look to our </b><a href="https://support.globalinfocloud.com/uploads/GIC-Company-Profile_6_23.pdf" target="_blank"><b>Company Profile</b></a></p>
                    
                    
                    <p style="text-align: justify;">I would love to discuss how Global Infocloud can support your business growth and success. Please let me know your availability, and I will be more than happy to schedule a meeting at your convenience.</p>
                    
                    
                    <p>Thank you for considering Global Infocloud Pvt Ltd. I look forward to the opportunity of working together and unlocking the full potential of your business.</p>
                    
                    <p>Best regards,</p>';
                    if($email=="vaibhav@globalinfocloud.com") {
                        $body1.= '<img src="https://support.globalinfocloud.com/uploads/e_sign/vaibhav-sinha.jpeg" style="width: auto; height: 220px;">';
                    }  
                    if($email=="syed.nazeer@globalinfocloud.com"){
                    $body1.= '<img src="https://support.globalinfocloud.com/uploads/e_sign/syed-ansar.jpeg" style="width: auto; height: 220px;">';
                    }
                    if($email=="naqya.ali@globalinfocloud.com"){
                    $body1.= '<img src="https://support.globalinfocloud.com/uploads/e_sign/naqua-ali.jpeg" style="width: auto; height: 220px;">';
                    }
                    if($email=="pradnya.kothavade@globalinfocloud.com"){
                    $body1.= '<img src="https://support.globalinfocloud.com/uploads/e_sign/pradnya-kothavade.jpeg" style="width: auto; height: 220px;">';
                    }
                    if($email=="ajinkya.bhalerao@globalinfocloud.com"){
                    $body1.= '<img src="https://support.globalinfocloud.com/uploads/e_sign/ajinkya-bhalerao.jpeg" style="width: auto; height: 220px;">';
                    }
                    if($email=="sayali.mahajan@globalinfocloud.com"){
                    $body1.= '<img src="https://support.globalinfocloud.com/uploads/e_sign/sayali-mahajan.jpeg" style="width: auto; height: 220px;">';
                    }
                    if($email=="aman.pandey@globalinfocloud.com"){
                    $body1.= '<img src="https://support.globalinfocloud.com/uploads/e_sign/aman-pandey.jpeg" style="width: auto; height: 220px;">';
                    }
                    if($email=="durga.naik@globalinfocloud.com"){
                    $body1.= '<img src="https://support.globalinfocloud.com/uploads/e_sign/durga-naik.jpeg" style="width: auto; height: 220px;">';
                    }
                    if($email=="nidhi@globalinfocloud.com"){
                    $body1.= '<img src="https://support.globalinfocloud.com/uploads/e_sign/nidhi-jalan.jpeg" style="width: auto; height: 220px;">';
                    }
                    $body1 .='<p>&nbsp;</p>
                    <p>&nbsp;</p>
                    <p text-align="justify" style="color: #018697; text-align: justify;"><strong> CONFIDENTIALITY NOTICE:</strong> The contents of this email message and any attachments are intended solely for the addressee(s) and may contain confidential and/or privileged information and may be legally protected from disclosure. If you are not the intended recipient of this message or their agent, or if this message has been addressed to you in error, please immediately alert the sender by reply email and then delete this message and any attachments. If you are not the intended recipient, you are hereby notified that any use, dissemination, copying, or storage of this message or its attachments is strictly prohibited.</p>';
                ?>
                   
                <textarea name="message" style="display:none;"><?php echo $body1; ?></textarea>
                    <?php echo $body1; ?>
                   
            </div>
        </div>
 
        <div class="clearfix"></div>
            <input type="hidden" name="mobno" id="mobno" value="<?php echo $lead->phonenumber; ?>" class="form-control input-sm">
                  
        <?php echo form_close(); ?>
        
    </div>    
<!--==================== Send Product Brochure ==============================-->    

    <div role="tabpanel" class="tab-pane" id="tab_send_product_brochure">
      <?php echo form_open('admin/emails/SendProductBrochure',array('id'=>'lead_form')); ?>
        <?php 
            $login_email = get_staff_full_name1();
            $pos1 = strpos($login_email,"(");
            $email = substr($login_email,$pos1+1,-1);
        ?>
        <input type="hidden" name="lead_id" value="<?php echo $lead->id; ?>">
        <input type="hidden" name="ind_for" value="<?php echo $lead->ind_for; ?>">
        <div class="col-xs-6 col-sm-6 col-md-6">
            <label>Email From</label>
            <div class="form-group">
                <input type="text" name="email_from" id="email_from" class="form-control input-sm" value="bd@support.globalinfocloud.com" readonly>
            </div>
        </div>
            
        <div class="col-xs-6 col-sm-6 col-md-6">
            <label>Email To</label>
            <div class="form-group">
                <input type="text" name="email_to" id="email_to" class="form-control input-sm" value="<?php echo $lead->email; ?>">
            </div>
        </div>
        <div class="clearfix"></div>

        <div class="col-xs-6 col-sm-6 col-md-6">
            <label>Subject</label>
            <div class="form-group">
                <input type="text" name="Subject" id="Subject" class="form-control input-sm" placeholder="Subject" value="Introducing Our Cutting-Edge Solution for <?php echo $lead->ind_for; ?>">
            </div>
        </div>
        <div class="col-xs-6 col-sm-6 col-md-6">
            <label>Cc</label>
            <div class="form-group">
                <input type="text" name="cc" id="cc" value="<?php echo $email; ?>;sales@globalinfocloud.com" readonly class="form-control input-sm" placeholder="Cc">
            </div>
        </div>
        <div class="clearfix"></div>
        <div class="col-xs-6 col-sm-6 col-md-6">
            <label>Bcc</label>
            <div class="form-group">
                <input type="text" name="bcc" id="bcc" class="form-control input-sm" value="sales.globalinfocloud@gmail.com" readonly="">
            </div>
        </div>
                  
        <div class="col-xs-6 col-sm-6 col-md-6">
            <label>&nbsp;</label>
            <div class="form-group">
                <button class="btn btn-warning send" type="submit" id="send">Send Product Brochure</button>
            </div>
        </div>
                  
        <div class="clearfix"></div>
                  
        <div class="col-xs-12 col-sm-12 col-md-12">
            <label><strong>Message Body</strong></label>
            <br>
            <div class="form-group">
                <?php
                    $Brochure_url = '';
                    $video_link = '';
                    if($lead->ind_for == "Hospital"){
                        $Brochure_url = 'https://support.globalinfocloud.com/uploads/GIC-Company-Profile_6_23.pdf';
                    }else if($lead->ind_for == "School / Institute"){
                        $Brochure_url = 'https://support.globalinfocloud.com/uploads/product_brochures/GIC-School-Managment-Solution.pdf';
                    }else if($lead->ind_for == "Manufacturing"){
                        $Brochure_url = 'https://support.globalinfocloud.com/uploads/GIC-Company-Profile_6_23.pdf';
                    }else if($lead->ind_for == "Flour and Rolling Mills"){
                        $Brochure_url = 'https://support.globalinfocloud.com/uploads/product_brochures/ERP_for_Rolling_Flour_Mills.pdf';
                        $video_link = 'https://youtu.be/jpDhEkZuCCc';
                    }else if($lead->ind_for == "Warehousing"){
                        $Brochure_url = 'https://support.globalinfocloud.com/uploads/GIC-Company-Profile_6_23.pdf';
                    }else if($lead->ind_for == "Recording Studio"){
                        $Brochure_url = 'https://support.globalinfocloud.com/uploads/GIC-Company-Profile_6_23.pdf';
                    }else if($lead->ind_for == "Online Shopping"){
                        $Brochure_url = 'https://support.globalinfocloud.com/uploads/GIC-Company-Profile_6_23.pdf';
                    }else if($lead->ind_for == "Agricultural Products"){
                        $Brochure_url = 'https://support.globalinfocloud.com/uploads/GIC-Company-Profile_6_23.pdf';
                    }
                    else if($lead->ind_for == "Digital Marketing"){
                        $Brochure_url = 'https://support.globalinfocloud.com/uploads/product_brochures/GIC_DM_SubscriptionPlan.pdf';
                    }
                    else{
                        $Brochure_url = 'https://support.globalinfocloud.com/uploads/GIC-Company-Profile_6_23.pdf';
                    }
    $body1 = "<p>Dear $name,</p>
    <p>Greetings of the day!</p>
    <p class='whowe' style='text-align: justify;'>I hope this email finds you well. I am writing to introduce our innovative ERP solution designed specifically for flour and rolling mills. With our comprehensive 360-degree approach, we offer a tailored solution that addresses all your mill's requirements, streamlining your operations and maximizing efficiency.</p>
    
    <p class='whowe' style='text-align: justify;'>To give you a deeper understanding of our ERP solution, I invite you to explore our brochure and watch our informative video by clicking on the following links:</p>
    
    <p style='text-align: justify;'><b>Brochure: </b><a href=$Brochure_url target='_blank'><b>Click here to view brochure</b></a></p>";
     if($video_link !== ''){ 
    $body1 .="<p style='text-align: justify;'><b>Video: </b><a href=$video_link target='_blank'><b>Click here to view video</b></a></p>";
     } 
    $body1 .="<p class='whowe' style='text-align: justify;'>Our ERP system utilizes advanced algorithms to revolutionize the way you manage your mill's operations. By implementing our solution, you not only mitigate the risk of human error but also gain the ability to plan your business requirements in advance. This foresight empowers you to optimize your resources, save on human resources, and significantly reduce time wastage.</p>
    
    <p class='whowe' style='text-align: justify;'>Key benefits of our ERP solution for flour and rolling mills include:</p>
    
    <p class='whowe' style='text-align: justify;'><b>Seamless Integration</b>: Our ERP seamlessly integrates with your existing systems, ensuring a smooth transition and eliminating the need for manual data entry.</p>
    <p class='whowe' style='text-align: justify;'><b>Enhanced Efficiency</b>: With automated processes and real-time insights, our solution enables you to improve overall productivity, reduce downtime, and make informed decisions promptly.</p>
    <p class='whowe' style='text-align: justify;'><b>Inventory Optimization</b>: Our ERP's advanced algorithms optimize inventory management, reducing excess stock, minimizing waste, and ensuring optimal resource utilization.</p>
    <p class='whowe' style='text-align: justify;'><b>Predictive Maintenance</b>: By leveraging our solution's predictive maintenance capabilities, you can proactively address potential equipment failures, preventing costly downtime and maximizing equipment lifespan.</p>
    <p class='whowe' style='text-align: justify;'><b>Streamlined Financial Management</b>: Our ERP provides comprehensive financial management tools, offering precise cost tracking, accurate forecasting, and streamlined reporting for better financial decision-making.</p>
    
    <p class='whowe' style='text-align: justify;'>We believe that our ERP solution can significantly enhance your mill's operations, drive growth, and boost profitability. Please take the time to review our brochure and watch our video to gain a comprehensive understanding of how our solution can benefit your business.</p>
    
    <p class='whowe' style='text-align: justify;'>Should you have any questions or require further information, please don't hesitate to reach out to us. We would be delighted to schedule a personalized demonstration of our ERP solution tailored to your mill's specific needs.</p>
    
    <p class='whowe' style='text-align: justify;'>Thank you for your time, and we look forward to the opportunity of partnering with you to revolutionize your mill's operations.</p>
    
                    
                    <p class='whowe' style='text-align: justify;'>Thanks!</p>
                    <p class='whowe' style='text-align: justify;'>Best,</p>";
                    if($email=="vaibhav@globalinfocloud.com") {
                        $body1.= '<img src="https://support.globalinfocloud.com/uploads/e_sign/vaibhav-sinha.jpeg" style="width: auto; height: 220px;">';
                    }  
                    if($email=="syed.nazeer@globalinfocloud.com"){
                    $body1.= '<img src="https://support.globalinfocloud.com/uploads/e_sign/syed-ansar.jpeg" style="width: auto; height: 220px;">';
                    }
                    if($email=="naqya.ali@globalinfocloud.com"){
                    $body1.= '<img src="https://support.globalinfocloud.com/uploads/e_sign/naqua-ali.jpeg" style="width: auto; height: 220px;">';
                    }
                    if($email=="pradnya.kothavade@globalinfocloud.com"){
                    $body1.= '<img src="https://support.globalinfocloud.com/uploads/e_sign/pradnya-kothavade.jpeg" style="width: auto; height: 220px;">';
                    }
                    if($email=="ajinkya.bhalerao@globalinfocloud.com"){
                    $body1.= '<img src="https://support.globalinfocloud.com/uploads/e_sign/ajinkya-bhalerao.jpeg" style="width: auto; height: 220px;">';
                    }
                    if($email=="sayali.mahajan@globalinfocloud.com"){
                    $body1.= '<img src="https://support.globalinfocloud.com/uploads/e_sign/sayali-mahajan.jpeg" style="width: auto; height: 220px;">';
                    }
                    if($email=="aman.pandey@globalinfocloud.com"){
                    $body1.= '<img src="https://support.globalinfocloud.com/uploads/e_sign/aman-pandey.jpeg" style="width: auto; height: 220px;">';
                    }
                    if($email=="durga.naik@globalinfocloud.com"){
                    $body1.= '<img src="https://support.globalinfocloud.com/uploads/e_sign/durga-naik.jpeg" style="width: auto; height: 220px;">';
                    }
                    if($email=="nidhi@globalinfocloud.com"){
                    $body1.= '<img src="https://support.globalinfocloud.com/uploads/e_sign/nidhi-jalan.jpeg" style="width: auto; height: 220px;">';
                    }
                    $body1 .='<p>&nbsp;</p>
                    <p>&nbsp;</p>
                    <p text-align="justify" style="color: #018697; text-align: justify;"><strong> CONFIDENTIALITY NOTICE:</strong> The contents of this email message and any attachments are intended solely for the addressee(s) and may contain confidential and/or privileged information and may be legally protected from disclosure. If you are not the intended recipient of this message or their agent, or if this message has been addressed to you in error, please immediately alert the sender by reply email and then delete this message and any attachments. If you are not the intended recipient, you are hereby notified that any use, dissemination, copying, or storage of this message or its attachments is strictly prohibited.</p>';
                ?>
                   
                <textarea name="message" style="display:none;"><?php echo $body1; ?></textarea>
                    <?php echo $body1; ?>
                   
            </div>
        </div>
 
        <div class="clearfix"></div>
            <input type="hidden" name="mobno" id="mobno" value="<?php echo $lead->phonenumber; ?>" class="form-control input-sm">
                  
        <?php echo form_close(); ?>
        
    </div> 
    <!-- custom code end -->
            
            
                <?php if (isset($lead)) { ?>
                <?php if (count($mail_activity) > 0 || isset($show_email_activity) && $show_email_activity) { ?>
                <div role="tabpanel" class="tab-pane" id="tab_email_activity">
                    <?php hooks()->do_action('before_lead_email_activity', ['lead' => $lead, 'email_activity' => $mail_activity]); ?>
                    <?php foreach ($mail_activity as $_mail_activity) { ?>
                    <div class="lead-email-activity">
                        <div class="media-left">
                            <i class="fa-regular fa-envelope"></i>
                        </div>
                        <div class="media-body">
                            <h4 class="bold no-margin lead-mail-activity-subject">
                                <?php echo $_mail_activity['subject']; ?>
                                <br />
                                <small
                                    class="text-muted display-block mtop5 font-medium-xs"><?php echo _dt($_mail_activity['dateadded']); ?></small>
                            </h4>
                            <div class="lead-mail-activity-body">
                                <hr />
                                <?php echo $_mail_activity['body']; ?>
                            </div>
                            <hr />
                        </div>
                    </div>
                    <div class="clearfix"></div>
                    <?php } ?>
                    <?php hooks()->do_action('after_lead_email_activity', ['lead_id' => $lead->id, 'emails' => $mail_activity]); ?>
                </div>
                <?php } ?>
                <?php if (is_gdpr() && (get_option('gdpr_enable_lead_public_form') == '1' || get_option('gdpr_enable_consent_for_leads') == '1' || (get_option('gdpr_data_portability_leads') == '1') && is_admin())) { ?>
                <div role="tabpanel" class="tab-pane" id="gdpr">
                    <?php if (get_option('gdpr_enable_lead_public_form') == '1') { ?>
                    <a href="<?php echo $lead->public_url; ?>" target="_blank" class="mtop5">
                        <?php echo _l('view_public_form'); ?>
                    </a>
                    <?php } ?>
                    <?php if (get_option('gdpr_data_portability_leads') == '1' && is_admin()) { ?>
                    <?php
                  if (get_option('gdpr_enable_lead_public_form') == '1') {
                      echo ' | ';
                  }
                  ?>
                    <a href="<?php echo admin_url('leads/export/' . $lead->id); ?>">
                        <?php echo _l('dt_button_export'); ?>
                    </a>
                    <?php } ?>
                    <?php if (get_option('gdpr_enable_lead_public_form') == '1' || (get_option('gdpr_data_portability_leads') == '1' && is_admin())) { ?>
                    <hr class="-tw-mx-3.5" />
                    <?php } ?>
                    <?php if (get_option('gdpr_enable_consent_for_leads') == '1') { ?>
                    <h4 class="no-mbot">
                        <?php echo _l('gdpr_consent'); ?>
                    </h4>
                    <?php $this->load->view('admin/gdpr/lead_consent'); ?>
                    <hr />
                    <?php } ?>
                </div>
                <?php } ?>
                <div role="tabpanel" class="tab-pane" id="lead_activity">
                    <div>
                        <div class="activity-feed">
                            <?php foreach ($activity_log as $log) { ?>
                            <div class="feed-item">
                                <div class="date">
                                    <span class="text-has-action" data-toggle="tooltip"
                                        data-title="<?php echo _dt($log['date']); ?>">
                                        <?php echo time_ago($log['date']); ?>
                                    </span>
                                </div>
                                <div class="text">
                                    <?php if ($log['staffid'] != 0) { ?>
                                    <a href="<?php echo admin_url('profile/' . $log['staffid']); ?>">
                                        <?php echo staff_profile_image($log['staffid'], ['staff-profile-xs-image pull-left mright5']);
                              ?>
                                    </a>
                                    <?php
                              }
                              $additional_data = '';
                              if (!empty($log['additional_data'])) {
                                  $additional_data = unserialize($log['additional_data']);
                                  echo ($log['staffid'] == 0) ? _l($log['description'], $additional_data) : $log['full_name'] . ' - ' . _l($log['description'], $additional_data);
                              } else {
                                  echo $log['full_name'] . ' - ';
                                  if ($log['custom_activity'] == 0) {
                                      echo _l($log['description']);
                                  } else {
                                      echo _l($log['description'], '', false);
                                  }
                              }
                              ?>
                                </div>
                            </div>
                            <?php } ?>
                        </div>
                        <div class="col-md-12">
                            <?php echo render_textarea('lead_activity_textarea', '', '', ['placeholder' => _l('enter_activity')], [], 'mtop15'); ?>
                            <div class="text-right">
                                <button id="lead_enter_activity"
                                    class="btn btn-primary"><?php echo _l('submit'); ?></button>
                            </div>
                        </div>
                        <div class="clearfix"></div>
                    </div>
                </div>
                <div role="tabpanel" class="tab-pane" id="tab_proposals_leads">
                    <?php if (has_permission('proposals', '', 'create')) { ?>
                    <a href="<?php echo admin_url('proposals/proposal?rel_type=lead&rel_id=' . $lead->id); ?>"
                        class="btn btn-primary mbot25"><?php echo _l('new_proposal'); ?></a>
                    <?php } ?>
                    <?php if (total_rows(db_prefix() . 'proposals', ['rel_type' => 'lead', 'rel_id' => $lead->id]) > 0 && (has_permission('proposals', '', 'create') || has_permission('proposals', '', 'edit'))) { ?>
                    <a href="#" class="btn btn-primary mbot25" data-toggle="modal"
                        data-target="#sync_data_proposal_data"><?php echo _l('sync_data'); ?></a>
                    <?php $this->load->view('admin/proposals/sync_data', ['related' => $lead, 'rel_id' => $lead->id, 'rel_type' => 'lead']); ?>
                    <?php } ?>
                    <?php
                  $table_data = [
                   _l('proposal') . ' #',
                   _l('proposal_subject'),
                   _l('proposal_total'),
                   _l('proposal_date'),
                   _l('proposal_open_till'),
                   _l('tags'),
                   _l('proposal_date_created'),
                   _l('proposal_status'), ];
                  $custom_fields = get_custom_fields('proposal', ['show_on_table' => 1]);
                  foreach ($custom_fields as $field) {
                      array_push($table_data, [
                       'name'     => $field['name'],
                       'th_attrs' => ['data-type' => $field['type'], 'data-custom-field' => 1],
                    ]);
                  }
                  $table_data = hooks()->apply_filters('proposals_relation_table_columns', $table_data);
                  render_datatable($table_data, 'proposals-lead', [], [
                      'data-last-order-identifier' => 'proposals-relation',
                      'data-default-order'         => get_table_last_order('proposals-relation'),
                  ]);
                  ?>
                </div>
                <div role="tabpanel" class="tab-pane" id="tab_tasks_leads">
                    <?php init_relation_tasks_table(['data-new-rel-id' => $lead->id, 'data-new-rel-type' => 'lead']); ?>
                </div>
                <div role="tabpanel" class="tab-pane" id="lead_reminders">
                    <a href="#" data-toggle="modal" class="btn btn-default"
                        data-target=".reminder-modal-lead-<?php echo $lead->id; ?>"><i class="fa-regular fa-bell"></i>
                        <?php echo _l('lead_set_reminder_title'); ?></a>
                    <hr />
                    <?php render_datatable([ _l('reminder_description'), _l('reminder_date'), _l('reminder_staff'), _l('reminder_is_notified')], 'reminders-leads'); ?>
                </div>
                <div role="tabpanel" class="tab-pane" id="attachments">
                    <?php echo form_open('admin/leads/add_lead_attachment', ['class' => 'dropzone mtop15 mbot15', 'id' => 'lead-attachment-upload']); ?>
                    <?php echo form_close(); ?>
                    <?php if (get_option('dropbox_app_key') != '') { ?>
                    <hr />
                    <div class=" pull-left">
                        <?php if (count($lead->attachments) > 0) { ?>
                        <a href="<?php echo admin_url('leads/download_files/' . $lead->id); ?>" class="bold">
                            <?php echo _l('download_all'); ?> (.zip)
                        </a>
                        <?php } ?>
                    </div>
                    <div class="tw-flex tw-justify-end tw-items-center tw-space-x-2">
                        <button class="gpicker">
                            <i class="fa-brands fa-google" aria-hidden="true"></i>
                            <?php echo _l('choose_from_google_drive'); ?>
                        </button>
                        <div id="dropbox-chooser-lead"></div>
                    </div>
                    <div class=" clearfix"></div>
                    <?php } ?>
                    <?php if (count($lead->attachments) > 0) { ?>
                    <div class="mtop20" id="lead_attachments">
                        <?php $this->load->view('admin/leads/leads_attachments_template', ['attachments' => $lead->attachments]); ?>
                    </div>
                    <?php } ?>
                </div>
                <div role="tabpanel" class="tab-pane" id="lead_notes">
                    <?php echo form_open(admin_url('leads/add_note/' . $lead->id), ['id' => 'lead-notes']); ?>
                    <div class="form-group">
                        <textarea id="lead_note_description" name="lead_note_description" class="form-control"
                            rows="4"></textarea>
                    </div>
                    <div class="lead-select-date-contacted hide">
                        <?php echo render_datetime_input('custom_contact_date', 'lead_add_edit_datecontacted', '', ['data-date-end-date' => date('Y-m-d')]); ?>
                    </div>
                    <div class="radio radio-primary">
                        <input type="radio" name="contacted_indicator" id="contacted_indicator_yes" value="yes">
                        <label
                            for="contacted_indicator_yes"><?php echo _l('lead_add_edit_contacted_this_lead'); ?></label>
                    </div>
                    <div class="radio radio-primary">
                        <input type="radio" name="contacted_indicator" id="contacted_indicator_no" value="no" checked>
                        <label for="contacted_indicator_no"><?php echo _l('lead_not_contacted'); ?></label>
                    </div>
                    <button type="submit"
                        class="btn btn-primary pull-right"><?php echo _l('lead_add_edit_add_note'); ?></button>
                    <?php echo form_close(); ?>
                    <div class="clearfix"></div>
                    <hr />
                    <?php
                     $len = count($notes);
                     $i   = 0;
                     foreach ($notes as $note) { ?>
                    <div class="media lead-note">
                        <a href="<?php echo admin_url('profile/' . $note['addedfrom']); ?>" target="_blank">
                            <?php echo staff_profile_image($note['addedfrom'], ['staff-profile-image-small', 'pull-left mright10']); ?>
                        </a>
                        <div class="media-body">
                            <?php if ($note['addedfrom'] == get_staff_user_id() || is_admin()) { ?>
                            <a href="#" class="pull-right text-danger"
                                onclick="delete_lead_note(this,<?php echo $note['id']; ?>, <?php echo $lead->id; ?>);return false;">

                                <i class="fa fa fa-times"></i></a>
                            <a href="#" class="pull-right mright5"
                                onclick="toggle_edit_note(<?php echo $note['id']; ?>);return false;">
                                <i class="fa-regular fa-pen-to-square"></i>
                                <?php } ?>

                                <a href="<?php echo admin_url('profile/' . $note['addedfrom']); ?>" target="_blank">
                                    <h5 class="media-heading tw-font-semibold tw-mb-0">
                                        <?php if (!empty($note['date_contacted'])) { ?>
                                        <span data-toggle="tooltip"
                                            data-title="<?php echo _dt($note['date_contacted']); ?>">
                                            <i class="fa fa-phone-square text-success" aria-hidden="true"></i>
                                        </span>
                                        <?php } ?>
                                        <?php echo get_staff_full_name($note['addedfrom']); ?>
                                    </h5>
                                    <span class="tw-text-sm tw-text-neutral-500">
                                        <?php echo _l('lead_note_date_added', _dt($note['dateadded'])); ?>
                                    </span>
                                </a>

                                <div data-note-description="<?php echo $note['id']; ?>" class="text-muted mtop10">
                                    <?php echo check_for_links(app_happy_text($note['description'])); ?>
                                </div>
                                <div data-note-edit-textarea="<?php echo $note['id']; ?>" class="hide mtop15">
                                    <?php echo render_textarea('note', '', $note['description']); ?>
                                    <div class="text-right">
                                        <button type="button" class="btn btn-default"
                                            onclick="toggle_edit_note(<?php echo $note['id']; ?>);return false;"><?php echo _l('cancel'); ?></button>
                                        <button type="button" class="btn btn-primary"
                                            onclick="edit_note(<?php echo $note['id']; ?>);"><?php echo _l('update_note'); ?></button>
                                    </div>
                                </div>
                        </div>
                        <?php if ($i >= 0 && $i != $len - 1) {
                         echo '<hr />';
                     }
                        ?>
                    </div>
                    <?php $i++; } ?>
                </div>
                <?php } ?>
                <?php hooks()->do_action('after_lead_tabs_content', $lead ?? null); ?>
            </div>
        </div>
    </div>
</div>
<?php hooks()->do_action('lead_modal_profile_bottom', (isset($lead) ? $lead->id : '')); ?>